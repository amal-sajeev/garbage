# Evaluation Service — Upgrades and Changes

This document describes all changes made in the API-call, document-handling, and
config-driven-metrics upgrade.

---

## Summary

The evaluation service was upgraded to:
1. Call any AI agent service via a **config-driven HTTP adapter** (no Python needed).
2. Handle **document outputs** (PDF, DOCX, Markdown, JSON) with automatic text
   extraction so all existing scorers work on documents.
3. Define **custom evaluation metrics from config files** (text/regex, JSON,
   document-structure, and a custom LLM rubric judge) — no Python needed.
4. Ship **3 demo agents** (custom LangChain, hostable standalone) showcasing
   all upgrades end-to-end.
5. Fix several existing issues (missing `field_match`, unused `spec.config`,
   `json_field_match` doc gap).

---

## New files

### Core

| File | Purpose |
|------|---------|
| `src/eval_service/adapters/http_adapter.py` | Config-driven HTTP adapter + `@register_adapter` escape hatch |
| `src/eval_service/adapters/documents.py` | Document text extraction (PDF/DOCX/MD/JSON) + structural parsers |
| `src/eval_service/scorers/configurable.py` | All config-driven scorers (4 families, 11 scorers) |

### Demo agents

| File | Purpose |
|------|---------|
| `src/sample_agents/report_writer_agent.py` | Markdown report writer (port 4011) |
| `src/sample_agents/invoice_parser_agent.py` | JSON invoice parser (port 4012) |
| `src/sample_agents/document_qa_agent.py` | DOCX/PDF document generator (port 4013) |
| `src/agents/report_writer/` | Config folder: agent.yaml, dataset.json, metrics_stub.json |
| `src/agents/invoice_parser/` | Config folder: agent.yaml, dataset.json, metrics_stub.json |
| `src/agents/document_qa/` | Config folder: agent.yaml, dataset.json, metrics_stub.json |
| `scripts/run_report_writer_agent.ps1` | Launcher for the report writer sample |
| `scripts/run_invoice_parser_agent.ps1` | Launcher for the invoice parser sample |
| `scripts/run_document_qa_agent.ps1` | Launcher for the document QA sample |

### Tests

| File | Purpose |
|------|---------|
| `tests/test_configurable_scorers.py` | Tests for all config-driven scorers (positive/negative/edge) |
| `tests/test_http_adapter.py` | Tests for request building, response mapping, auth, error handling |
| `tests/test_documents.py` | Tests for content-type detection, text extraction, section parsing |

### Docs

| File | Purpose |
|------|---------|
| `docs/AGENT_CONFIG_GUIDE.md` | Engineer tutorial: how to create agent configs for the eval service |
| `docs/UPGRADES_AND_CHANGES.md` | This document |

---

## Changed files

| File | Change |
|------|--------|
| `src/eval_service/models.py` | Extended `TargetSpec` (method, headers, auth, params, body, response mapping, timeout, trust_env, retries); added `ResponseMapping` model; extended `GoldenCase` (`golden_file`, `content_type`) |
| `src/eval_service/adapters/__init__.py` | Exports `HttpAdapter`, `register_adapter`, `extract_text`, `detect_content_type` |
| `src/eval_service/adapters/target_agent.py` | `build_target_adapter` now handles `http` adapter + `@register_adapter` custom adapters |
| `src/eval_service/scorers/__init__.py` | Imports `configurable` module (registers all config-driven scorers) |
| `src/eval_service/scorers/output_text.py` | `render_output_text` now handles bytes (lazy document extraction fallback) |
| `src/eval_service/scorers/similarity.py` | Docstring fixed (`json_field_match` → `field_match` in configurable.py); `json_schema_valid` enhanced version in configurable.py supersedes the simpler one here |
| `src/eval_service/runner.py` | `_JUDGE_SCORERS` now includes `rubric` (UI flag + offline-skip awareness) |
| `requirements.txt` | Added `pypdf==5.1.0`, `python-docx==1.1.2` |

---

## New config-driven scorers (11 total)

### Text / regex (4)

| Scorer | config keys | What it checks |
|--------|-------------|----------------|
| `contains` | `terms`, `case_sensitive`, `min_count` | Required terms must appear in output text |
| `regex_match` | `patterns: [{pattern, required, flags}]` | Regex patterns must match output text |
| `length_range` | `min`, `max`, `unit` (words/chars) | Output length within range |
| `keyword_count` | `terms`, `case_sensitive` | Count of keyword occurrences (raw value) |

### JSON (3)

| Scorer | config keys | What it checks |
|--------|-------------|----------------|
| `json_path` | `path`, `op`, `value` | Dotted-path value in JSON output (equals/contains/exists/regex) |
| `field_match` | `fields: [{name, op, value, required}]` | Required JSON fields with value operators (==/!=/contains/regex/in/type) |
| `json_schema_valid` | `schema` (JSON Schema) or `required`+`types` | Output matches a JSON schema |

### Document structure (3)

| Scorer | config keys | What it checks |
|--------|-------------|----------------|
| `section_present` | `sections: [str]` | Required section headings present in document |
| `heading_count` | `min`, `max` | Number of headings within range |
| `docx_table_has` | `tables: [{required_headers, min_rows}]` | DOCX tables with required headers + min rows |

### Custom LLM rubric (1)

| Scorer | config keys | What it checks |
|--------|-------------|----------------|
| `rubric` | `rubric` (text), `uses_golden`, `bias_guard`, `examples` | Custom LLM judge criterion from config (Vertex; skips offline) |

---

## The config-driven HTTP adapter

The `http` adapter (`adapter: "http"` in `dataset.json`) replaces the need to
write Python target adapters. It supports:

- **Any HTTP method**: GET, POST, PUT, PATCH, DELETE
- **Headers**: static or templated (`${env.VAR}`, `${input.path}`)
- **Auth**: bearer, basic, api_key_header, api_key_query — secrets from env only
- **Query params**: templated from `case.input`
- **Body**: JSON (default), form, text, raw — templated from `case.input`
- **Response mapping**: dotted-path extraction into the Observation envelope
- **Content types**: auto-detect or explicit (text, json, markdown, pdf, docx)
- **Document handling**: base64/bytes/URL output kinds with text extraction
- **Per-adapter overrides**: timeout, trust_env, retries

The existing `agent_eval_hook` and `scoping_analytics` adapters remain for
backward compatibility.

### Python escape hatch

`@register_adapter("id")` decorator in `custom_tests.py` for agents that can't
be called via HTTP (direct SDK, gRPC, local functions).

---

## Document handling

The `adapters/documents.py` module extracts text from PDF (pypdf), DOCX
(python-docx), Markdown (stdlib regex), and JSON (stdlib). Key design:

- Extraction happens **once** in the HTTP adapter; extracted text is stored in
  `observation.metadata["extracted_text"]` and `observation.output` is replaced
  with the text for document types.
- Raw bytes are preserved in `observation.metadata["raw_output"]` for
  document-structure scorers (e.g., `docx_table_has`).
- **All existing scorers** (token overlap, edit/embedding similarity, LLM
  judges) work on extracted document text with zero changes.
- Document scorers **skip cleanly** (MetricSkipped) when the parsing library
  is absent — same contract as Vertex-offline.

---

## New dependencies

| Package | Version | Purpose |
|---------|---------|---------|
| `pypdf` | 5.1.0 | PDF text extraction |
| `python-docx` | 1.1.2 | DOCX text + table extraction |

Both are imported lazily; if absent, document scorers skip cleanly.

---

## Backward compatibility

- Existing agents (`scope_extraction`, `scoping_summary`) are **unchanged** and
  continue to work with their existing `agent_eval_hook` / `scoping_analytics`
  adapters.
- The default `TargetSpec` fields all have backward-compatible defaults; an
  existing `dataset.json` with only `adapter` and `endpoint` still works.
- The `json_schema_valid` scorer in `configurable.py` is a superset of the
  original in `similarity.py` (handles both `schema` and `required`+`types`).
- No persistence schema changes; no migration needed.

---

## Issues fixed

1. **`MetricSpec.config` was plumbed but almost unused** — only
   `json_schema_valid` read it. Now 11 config-driven scorers use it.
2. **`json_field_match` was documented but not implemented** (doc/code gap in
   `similarity.py`). Now implemented as `field_match` in `configurable.py`.
3. **Only 2 hard-coded Python adapters** — `AgentEvalHookAdapter` required a
   bespoke `Observation` envelope. Now the config-driven `http` adapter handles
   any HTTP endpoint with response mapping.
4. **No document handling** — the pipeline assumed JSON-serialisable output.
   Now PDF/DOCX/Markdown are extracted to text and all scorers work on them.
5. **LLM rubric dimensions were hard-coded** — engineers couldn't define new
   judge criteria without Python. Now the `rubric` scorer takes the criterion
   text from `config`.

---

## Round 2 — Performance, API, and operational upgrades

### New config env vars

| Variable | Default | Meaning |
|----------|---------|---------|
| `EVAL_CASE_CONCURRENCY` | `1` | How many golden cases to process in parallel (1 = serial) |
| `EVAL_RUN_RETENTION_DAYS` | `0` | Delete runs older than N days on startup (0 = keep forever) |
| `EVAL_WEBHOOK_TIMEOUT` | `30` | Timeout (seconds) for webhook callbacks on async evaluate |

### New API endpoints

| Method / Path | Purpose |
|---------------|---------|
| `GET /api/runs/compare?a=X&b=Y` | Compare two runs side-by-side (per-case scores, deltas, improved/regressed) |
| `POST /api/baselines/promote/{run_id}` | Promote a run's per-metric mean scores as the new baseline |
| `POST /api/evaluate/async` | Start an evaluation in the background with optional webhook callback |
| `POST /api/evaluate/ab` | Run two agents against the same dataset and compare results |
| `GET /api/runs/{run_id}/export?format=csv` | Export run detail as CSV |
| `GET /api/runs/{run_id}/export?format=pdf` | Export run detail as PDF |
| `GET /api/runs?before=<cursor>` | Cursor-based pagination (pass `created_at` of last run) |

### Changed files (Round 2)

| File | Change |
|------|--------|
| `src/eval_service/config.py` | Added `CASE_CONCURRENCY`, `RUN_RETENTION_DAYS`, `WEBHOOK_TIMEOUT` |
| `src/eval_service/logging.py` | **New.** Structured JSON logging with per-run trace IDs |
| `src/eval_service/runner.py` | Case-level concurrency (bounded by `CASE_CONCURRENCY`); global judge semaphore; per-agent metrics source override; structured logging |
| `src/eval_service/models.py` | Added `metrics_source` to `AgentConfig`; `AsyncEvaluateRequest`, `ABCompareRequest` |
| `src/eval_service/registry/__init__.py` | `validate()` — pre-flight check that all scorer names are registered + datasets have cases |
| `src/eval_service/repository/base.py` | Added `delete_old_runs()`; `list_runs` now accepts `before` cursor |
| `src/eval_service/repository/sqlite_repo.py` | Implemented `delete_old_runs()` + cursor pagination |
| `src/eval_service/repository/postgres_repo.py` | Implemented `delete_old_runs()` + cursor pagination |
| `src/eval_service/adapters/metrics_api.py` | `build_metrics_client` accepts per-agent `source_override` |
| `src/eval_service/scorers/configurable.py` | Added `rubric_multi` (N criteria in one Vertex call) + `pdf_table_has` |
| `src/eval_service/scorers/vertex.py` | Added `MultiRubricVerdict` + `RubricCriterionScore` models |
| `src/eval_service/main.py` | Run retention on startup; cursor pagination; compare/promote/async/ab/export endpoints; logging |
| `src/eval_service/static/run_detail.js` | Document preview (markdown rendering, JSON pretty-print, PDF/DOCX extracted text) |
| `src/eval_service/static/styles.css` | CSS for document preview, markdown rendering |
| `requirements.txt` | Added optional `pdfplumber` (commented out) |
| `tests/test_upgrades.py` | **New.** 19 tests for all round-2 features |
| `tests/test_runner.py` | Fixed mock to accept `source_override` parameter |

### New scorers (Round 2)

| Scorer | Family | What it checks |
|--------|--------|----------------|
| `rubric_multi` | llm_judge | Scores N criteria in ONE Vertex call (cost saver); config: `criteria: [{name, rubric}]` |
| `pdf_table_has` | document | PDF tables with required headers + min rows (needs pdfplumber; skips if absent) |

### New features summary

1. **Case-level concurrency** — `EVAL_CASE_CONCURRENCY` controls parallel case processing; the judge semaphore is now global across all cases.
2. **Dataset validation at startup** — `Registry.validate()` checks all scorer names are registered and datasets have cases; raises a clear error at startup instead of failing at the first run.
3. **Run comparison API** — `GET /api/runs/compare?a=X&b=Y` returns a per-case side-by-side comparison with improved/regressed flags.
4. **Baseline promotion API** — `POST /api/baselines/promote/{run_id}` computes per-metric mean scores and stores them as the new blessed baseline.
5. **Structured logging** — per-run trace IDs in JSON log lines to stderr; every run, case, and error is correlated.
6. **Multi-criteria rubric** — `rubric_multi` scorer scores N criteria in one Vertex call, halving judge costs for agents with 5+ custom rubrics.
7. **Per-agent METRICS_SOURCE** — `agent.yaml` can override the global `METRICS_SOURCE` with a `metrics_source` field.
8. **Run retention + pagination** — `EVAL_RUN_RETENTION_DAYS` cleans up old runs on startup; `GET /api/runs?before=<cursor>` for cursor-based pagination.
9. **Webhook on run completion** — `POST /api/evaluate/async` starts a background run with an optional `webhook_url` that receives the completed run record.
10. **A/B run comparison** — `POST /api/evaluate/ab` runs two agents against the same dataset and returns a per-case comparison with an overall winner.
11. **Run export** — `GET /api/runs/{run_id}/export?format=csv|pdf` exports the full run detail for audit/compliance.
12. **PDF table extraction** — `pdf_table_has` scorer using pdfplumber (optional; skips cleanly if not installed).
13. **Frontend document preview** — the run detail page renders Markdown as HTML, JSON pretty-printed, and PDF/DOCX extracted text in a readable preview.
