# Agent Configuration Guide — How to Add Your Agent to the Evaluation Service

This tutorial teaches AI engineers how to configure their agents for evaluation
by the CTNA Evaluation Service. You will learn how to wire up an HTTP call to
your agent, define custom evaluation metrics entirely from config files, handle
document outputs (PDF, DOCX, Markdown, JSON), and run a full evaluation — all
without writing evaluation code.

**Audience**: AI engineers who have an agent service (or are building one) and
want it scored by the evaluation service.

**Prerequisites**: Basic familiarity with JSON and YAML. Your agent needs an HTTP
endpoint that accepts a request and returns a response. No Python knowledge is
required for the config-driven path.

---

## 1. How the Evaluation Service Calls Your Agent

The evaluation service replays **golden inputs** against your agent's HTTP
endpoint, captures the output, and scores it against **golden outputs** and
**deterministic checks**. The call is configured in your agent's
`dataset.json` — no evaluation-service code changes are needed.

```
┌─────────────────┐     POST/GET      ┌──────────────────┐
│  Eval Service   │ ────────────────> │  Your Agent API  │
│  (runner.py)    │ <──────────────── │  (any framework) │
│                 │    JSON/text/     │                  │
│  scorers run    │    PDF/DOCX       └──────────────────┘
│  on the output  │
└─────────────────┘
```

You create one folder under `src/agents/<your_agent_id>/` containing:

```
src/agents/<your_agent_id>/
  agent.yaml         # Agent metadata + base URL
  dataset.json       # Golden set + target config + metrics config
  metrics_stub.json  # Stubbed metrics (optional; use METRICS_SOURCE=capture instead)
  custom_tests.py    # Custom Python scorers (optional; config-driven scorers cover most needs)
```

The registry auto-discovers your folder at startup. No code changes to the
evaluation service core.

---

## 2. The `agent.yaml` File

This is a simple metadata file:

```yaml
agent_id: my_agent
name: My AI Agent
# base_url: where your agent is hosted. If omitted, falls back to
# AGENT_SERVICE_BASE_URL from the environment.
base_url: http://localhost:5000
dataset_file: dataset.json
metrics_stub_file: metrics_stub.json
# Per-agent metrics source override (optional). Takes precedence over the
# global METRICS_SOURCE env var. Values: capture | http | stub.
metrics_source: capture
```

- `agent_id` must match the folder name.
- `base_url` is the host:port of your agent. Can be overridden per-run by the
  `AGENT_SERVICE_BASE_URL` env var.
- `dataset_file` and `metrics_stub_file` default to `dataset.json` and
  `metrics_stub.json`.

---

## 3. The `dataset.json` File — Target Configuration

The `dataset.json` has three top-level sections: `target` (how to call your
agent), `metrics` (what to score), and `cases` (the golden inputs/outputs).

### 3.1 Target: the config-driven HTTP adapter

Set `adapter: "http"` to use the config-driven HTTP adapter. Everything about
the request and response is described in the `target` block:

```jsonc
{
  "target": {
    "adapter": "http",
    "endpoint": "/api/eval/my-agent",
    "method": "POST",                    // GET, POST, PUT, PATCH (default: POST)
    "headers": {
      "Authorization": "Bearer ${env.MY_AGENT_TOKEN}",
      "Content-Type": "application/json"
    },
    "auth": {                            // Alternative to manual auth headers
      "type": "bearer",                  // bearer | basic | api_key_header | api_key_query
      "token_env": "MY_AGENT_TOKEN"     // Secret from env ONLY — never commit
    },
    "params": {                          // Query parameters (templated from case.input)
      "q": "${input.query}"
    },
    "body": {                            // Request body (templated). Absent = send case.input as JSON
      "query": "${input.query}",
      "max_tokens": "${input.max_tokens}"
    },
    "body_type": "json",                 // json (default) | form | text | raw
    "response": {                        // How to map the response into the Observation
      "output_path": "data.result",      // Dotted path to the agent's output
      "tool_calls_path": "tool_calls",   // Dotted path to tool-call list
      "usage_path": "usage",              // Dotted path to token usage
      "model_path": "model",              // Dotted path to model name
      "latency_path": null,               // Dotted path to latency (or auto-measured)
      "error_path": "error",              // Dotted path to error message
      "metadata_path": "metadata",        // Dotted path to extra metadata
      "content_type": "auto",             // auto | text | json | markdown | pdf | docx
      "output_kind": "text"               // text | json | base64 | bytes | url
    },
    "timeout": 60,                        // Seconds (default: 120)
    "trust_env": false,                   // false = bypass corporate proxy for localhost
    "retries": 0                          // Retry count (default: 0)
  }
}
```

#### Template syntax

All string values in `headers`, `params`, and `body` support two template
variables:

| Template | Resolves to |
|----------|-------------|
| `${env.VAR_NAME}` | The environment variable `VAR_NAME` |
| `${input.dotted.path}` | A value from the golden case's `input` dict |

Example: if the golden case's `input` is `{"query": "Summarize Q1", "context": "..."}`:

```json
"body": { "prompt": "${input.query}", "context": "${input.context}" }
```

resolves to `{"prompt": "Summarize Q1", "context": "..."}`.

#### Authentication

Secrets (tokens, passwords) are **never committed** in config files. They come
from environment variables, referenced by name:

```jsonc
// Bearer token from env
"auth": { "type": "bearer", "token_env": "MY_AGENT_TOKEN" }

// API key in a custom header
"auth": { "type": "api_key_header", "token_env": "MY_API_KEY", "header": "X-API-Key" }

// Basic auth
"auth": { "type": "basic", "username_env": "AGENT_USER", "password_env": "AGENT_PASS" }

// API key as query parameter (use params, not auth)
"params": { "api_key": "${env.MY_API_KEY}" }
```

#### Content types and document handling

Your agent can return text, JSON, Markdown, PDF, or DOCX. The adapter detects
the type automatically (`content_type: "auto"`) or you can specify it
explicitly:

| `content_type` | `output_kind` | What happens |
|----------------|-------------|--------------|
| `text` | `text` | Output used as-is |
| `json` | `json` | Output kept as parsed JSON; JSON scorers access it structurally |
| `markdown` | `text` | Output kept as-is; `#` headings detected for section scorers |
| `pdf` | `base64` | Text extracted from PDF via pypdf; raw bytes preserved for structure scorers |
| `docx` | `base64` | Text extracted from DOCX via python-docx; raw bytes preserved for table scorers |
| `auto` | `base64` | Magic-byte sniffing: detects PDF vs DOCX vs text automatically |

When the adapter extracts text from a document, **all existing scorers**
(token overlap, edit similarity, embedding similarity, LLM judges) work on
the extracted text automatically. Document-structure scorers
(`section_present`, `heading_count`, `docx_table_has`) access the raw bytes.

**Important**: if `pypdf` or `python-docx` is not installed, document scorers
**skip cleanly** (omitted from the score, not failed) — just like the LLM judge
skips when Vertex is unavailable offline.

---

## 4. The `dataset.json` File — Metrics Configuration

The `metrics` array defines what to score. Each metric references a scorer by
name and can pass parameters via the `config` block:

```jsonc
{
  "metrics": [
    {
      "name": "my_metric_name",         // Display name for this metric
      "type": "deterministic",           // deterministic | llm_judge | reference | trajectory | safety | operational
      "scorer": "contains",              // Registered scorer name (see §5)
      "weight": 2.0,                     // Relative weight in the weighted score
      "threshold": 0.8,                  // Minimum score to pass this metric
      "critical": false,                // If true, failing this metric fails the whole case
      "direction": "higher_is_better",  // higher_is_better | lower_is_better
      "unit": "ratio",                  // ratio | ms | tokens | count | usd ...
      "norm_min": null,                 // For lower_is_better: value at/above scores 0
      "norm_max": null,                 // For lower_is_better: value at/below scores 1
      "config": {                       // Scorer-specific parameters (see §5)
        "terms": ["required", "terms"]
      }
    }
  ]
}
```

The gate logic is: **passed** = (no critical metric failed) AND (all metrics ≥
threshold) AND (weighted score ≥ dataset threshold) AND (no drift beyond
tolerance).

---

## 5. Config-Driven Scorers — Custom Metrics from Config

These scorers are parameterised entirely through the `config` field. You
reference them by `scorer` name and supply parameters — no Python needed.

### 5.1 Text / regex scorers (operate on extracted output text)

#### `contains` — required terms must appear

```jsonc
{
  "name": "key_terms_present",
  "type": "deterministic",
  "scorer": "contains",
  "weight": 2.0,
  "threshold": 0.8,
  "config": {
    "terms": ["$10M", "revenue", "net income"],
    "case_sensitive": false,
    "min_count": 1
  }
}
```

Score = fraction of terms found (each must appear ≥ `min_count` times).

#### `regex_match` — regex patterns must match

```jsonc
{
  "name": "invoice_number_valid",
  "type": "deterministic",
  "scorer": "regex_match",
  "weight": 1.0,
  "threshold": 1.0,
  "config": {
    "patterns": [
      { "pattern": "INV-\\d{4}-\\d{3}", "required": true, "flags": "i" },
      { "pattern": "PO-\\d+", "required": false }
    ]
  }
}
```

`flags`: any combination of `i` (case-insensitive), `m` (multiline), `s`
(dotall), `x` (verbose). Score = required patterns matched / required total.

#### `length_range` — output length within [min, max]

```jsonc
{
  "name": "response_length",
  "type": "deterministic",
  "scorer": "length_range",
  "weight": 0.5,
  "threshold": 0.5,
  "config": {
    "min": 50,
    "max": 1000,
    "unit": "words"           // "words" or "chars"
  }
}
```

Score = 1.0 inside range, linearly decreasing outside. For `lower_is_better`
use `direction: "lower_is_better"` + `norm_min`/`norm_max` on the MetricSpec.

#### `keyword_count` — count keyword occurrences (raw count metric)

```jsonc
{
  "name": "risk_mentions",
  "type": "deterministic",
  "scorer": "keyword_count",
  "weight": 1.0,
  "threshold": 0.3,
  "direction": "lower_is_better",
  "unit": "count",
  "norm_min": 0,
  "norm_max": 20,
  "config": {
    "terms": ["risk", "issue", "concern"],
    "case_sensitive": false
  }
}
```

Returns raw count in `raw_value`; normalise with `direction` + `norm_*`.

### 5.2 JSON scorers (operate on the parsed JSON output)

#### `json_path` — dotted-path value check

```jsonc
{
  "name": "total_correct",
  "type": "deterministic",
  "scorer": "json_path",
  "weight": 3.0,
  "threshold": 1.0,
  "config": {
    "path": "total",
    "op": "equals",         // equals | contains | exists | regex
    "value": 8000           // comparison value for equals/contains/regex
  }
}
```

`path` uses dot notation for nested objects and `.N` for array indices
(e.g., `"line_items.0.amount"`).

#### `field_match` — required fields with value operators

```jsonc
{
  "name": "required_fields",
  "type": "deterministic",
  "scorer": "field_match",
  "weight": 2.0,
  "threshold": 1.0,
  "config": {
    "fields": [
      { "name": "vendor", "op": "exists", "required": true },
      { "name": "total", "op": "type", "value": "number", "required": true },
      { "name": "currency", "op": "==", "value": "USD", "required": true },
      { "name": "discount", "op": "!=", "value": 0, "required": false }
    ]
  }
}
```

Operators: `exists`, `==`, `!=`, `contains`, `regex`, `in`, `type`.

#### `json_schema_valid` — output matches a JSON Schema

```jsonc
{
  "name": "schema_valid",
  "type": "deterministic",
  "scorer": "json_schema_valid",
  "weight": 2.0,
  "threshold": 1.0,
  "config": {
    "schema": {
      "type": "object",
      "required": ["vendor", "total", "line_items"],
      "properties": {
        "vendor": { "type": "string" },
        "total": { "type": "number" },
        "line_items": {
          "type": "array",
          "items": {
            "type": "object",
            "required": ["description", "amount"],
            "properties": {
              "description": { "type": "string" },
              "amount": { "type": "number" }
            }
          }
        }
      }
    }
  }
}
```

Supports a subset of JSON Schema draft-07: `type`, `required`, `properties`,
`items`, `additionalProperties`.

Shortcut form (no full schema):

```jsonc
"config": {
  "required": ["vendor", "total"],
  "types": { "total": "number" }
}
```

### 5.3 Document-structure scorers (PDF / DOCX / Markdown)

These skip cleanly when the parsing library is absent.

#### `section_present` — required section headings must appear

```jsonc
{
  "name": "report_sections",
  "type": "deterministic",
  "scorer": "section_present",
  "weight": 3.0,
  "threshold": 0.8,
  "config": {
    "sections": ["Executive Summary", "Key Findings", "Recommendations"]
  }
}
```

Works on Markdown (`# Heading`), extracted PDF/DOCX text, and plain text.

#### `heading_count` — number of headings within [min, max]

```jsonc
{
  "name": "heading_count",
  "type": "deterministic",
  "scorer": "heading_count",
  "weight": 1.0,
  "threshold": 0.5,
  "config": {
    "min": 3,
    "max": 15
  }
}
```

#### `docx_table_has` — DOCX tables with required headers and rows

```jsonc
{
  "name": "summary_table",
  "type": "deterministic",
  "scorer": "docx_table_has",
  "weight": 2.0,
  "threshold": 1.0,
  "config": {
    "tables": [
      { "required_headers": ["Metric", "Value", "Status"], "min_rows": 3 }
    ]
  }
}
```

Requires `python-docx`. The scorer checks that at least one table in the
document has all required headers in its first row and at least `min_rows` rows.

#### `pdf_table_has` — PDF tables with required headers and rows

```jsonc
{
  "name": "summary_table_pdf",
  "type": "deterministic",
  "scorer": "pdf_table_has",
  "weight": 2.0,
  "threshold": 1.0,
  "config": {
    "tables": [
      { "required_headers": ["Metric", "Value", "Status"], "min_rows": 3 }
    ]
  }
}
```

Requires `pdfplumber` (optional; install with `pip install pdfplumber`). Skips
cleanly if not installed. Same interface as `docx_table_has` but for PDF tables.

### 5.4 Custom LLM rubric judge from config

This is the key feature: define a brand-new LLM evaluation criterion **from
config alone**. The scorer reuses the Vertex AI judge (Gemini) with
self-consistency sampling. It skips cleanly when Vertex is unavailable.

```jsonc
{
  "name": "professional_tone",
  "type": "llm_judge",
  "scorer": "rubric",
  "weight": 2.0,
  "threshold": 0.7,
  "config": {
    "rubric": "whether the output maintains a professional banking tone, avoids informal language, and presents information clearly and concisely. The language should be suitable for a regulatory submission.",
    "uses_golden": false,
    "bias_guard": true,
    "examples": "Score 1.0: 'The analysis indicates a 12% reduction in operational risk...'  Score 0.3: 'So yeah basically risk went down a lot lol...'"
  }
}
```

Config fields:

| Field | Default | Meaning |
|-------|---------|---------|
| `rubric` | (required) | The evaluation criterion text — what the judge should score |
| `uses_golden` | `false` | If `true`, include the golden_output in the prompt (skips if golden is missing) |
| `bias_guard` | `true` | Add the standard bias guard (ignore length, position) |
| `examples` | `""` | Optional few-shot examples appended to the prompt |

The judge returns a score 0..1, a rationale, and evidence strings. With
`judge_repetitions > 1`, multiple samples are averaged and the variance is
recorded (high variance flags an unstable verdict).

#### `rubric_multi` — Multi-criteria rubric in one judge call (cost saver)

Score N criteria in a **single** Vertex call instead of N separate `rubric`
metrics. The scorer returns the mean; per-criterion breakdown is in evidence.

```jsonc
{
  "name": "doc_quality",
  "type": "llm_judge",
  "scorer": "rubric_multi",
  "weight": 3.0,
  "threshold": 0.7,
  "config": {
    "criteria": [
      { "name": "professional_tone", "rubric": "maintains a professional banking tone" },
      { "name": "factual_accuracy", "rubric": "all claims are factually correct" },
      { "name": "completeness", "rubric": "covers all required topics" },
      { "name": "clarity", "rubric": "clear and concise language" }
    ],
    "uses_golden": false,
    "bias_guard": true
  }
}
```

This halves judge costs for agents with 5+ custom rubrics: one call returns
all criterion scores. Skips cleanly when Vertex is unavailable.

---

## 6. Built-in scorers also available

These are always available — reference them by name in your `scorer` field:

| Scorer | Family | What it measures |
|--------|--------|------------------|
| `tool_selection` | trajectory | Did the agent call the expected tool? |
| `tool_error_free` | trajectory | No tool raised an error (critical) |
| `token_overlap_f1` | reference | Token-level F1 vs golden output |
| `edit_similarity` | reference | Normalised Levenshtein similarity vs golden |
| `embedding_similarity` | reference | Vertex embedding cosine similarity vs golden |
| `faithfulness` | llm_judge | Factual correctness vs golden (Vertex; skips offline) |
| `relevance` | llm_judge | How directly the output answers the input |
| `completeness` | llm_judge | Whether output covers all golden info |
| `coherence` | llm_judge | Logical structure / internal consistency |
| `conciseness` | llm_judge | Avoids redundancy |
| `instruction_following` | llm_judge | Obeys explicit input instructions |
| `groundedness` | safety | Claims grounded in source context (Vertex; skips offline) |
| `no_pii_leakage` | safety | No un-redacted PII patterns (critical) |
| `prompt_injection_safe` | safety | No injection-signal phrases |
| `refusal_appropriate` | safety | Refuses when it should, answers when it should |
| `latency_slo` | operational | End-to-end latency vs SLO (lower_is_better) |
| `token_cost_budget` | operational | Token usage vs budget (lower_is_better) |
| `response_success` | operational | Agent returned a usable response (critical) |
| `rubric` | llm_judge | Custom LLM criterion from config (Vertex; skips offline) |
| `rubric_multi` | llm_judge | N criteria in ONE Vertex call (cost saver) |
| `pdf_table_has` | document | PDF tables with required headers (needs pdfplumber) |

---

## 7. The Python escape hatch: `@register_adapter`

If your agent can't be called via HTTP (e.g. direct SDK, gRPC, a local
function), you can write a custom adapter in Python. Put it in your agent's
`custom_tests.py`:

```python
from eval_service.adapters import register_adapter
from eval_service.models import GoldenCase, Observation
import time

@register_adapter("my_custom_agent")
class MyCustomAdapter:
    def __init__(self, base_url, endpoint, target=None):
        self._base_url = base_url
        self._endpoint = endpoint

    async def run_case(self, case: GoldenCase) -> Observation:
        start = time.perf_counter()
        # Call your agent however you want...
        result = my_agent_sdk.run(case.input)
        return Observation(
            target_id=case.id,
            output=result.text,
            tool_calls=result.tool_calls,
            latency_ms=int((time.perf_counter() - start) * 1000),
            model="my-agent-v1",
            metadata={"ai_confidence": result.confidence},
        )
```

Then reference it in `dataset.json`:

```json
{ "target": { "adapter": "my_custom_agent", "endpoint": "/any" } }
```

The registry auto-imports `custom_tests.py` at startup, so the adapter is
registered before the first run. You can also add custom Python scorers in the
same file:

```python
from eval_service.scorers.base import scorer

@scorer("my_custom_check")
def my_check(*, observation, case, **_):
    # Your custom logic here
    return 1.0, "passed", ["evidence line"]
```

---

## 8. Worked examples

Three complete demo agents ship with the service under `src/agents/`:

### 8.1 `report_writer` — Markdown output with section + rubric scorers

- Sample agent: `src/sample_agents/report_writer_agent.py` (port 4011)
- Config: `src/agents/report_writer/dataset.json`
- Demonstrates: `http` adapter, `content_type: markdown`, `section_present`,
  `contains`, `heading_count`, `length_range`, custom `rubric` judge

Run it:
```powershell
.\scripts\run_report_writer_agent.ps1    # start the sample agent
.\scripts\run_eval_service.ps1           # start the eval service
# In another terminal:
curl -X POST http://localhost:4002/api/evaluate -H "Content-Type: application/json" -d '{"agent_id":"report_writer"}'
```

### 8.2 `invoice_parser` — JSON output with structural + field scorers

- Sample agent: `src/sample_agents/invoice_parser_agent.py` (port 4012)
- Config: `src/agents/invoice_parser/dataset.json`
- Demonstrates: `http` adapter, `content_type: json`, `json_path`,
  `field_match`, `json_schema_valid`, custom `rubric` judge

### 8.3 `document_qa` — DOCX and PDF output with document-structure scorers

- Sample agent: `src/sample_agents/document_qa_agent.py` (port 4013)
- Config: `src/agents/document_qa/dataset.json`
- Demonstrates: `http` adapter, `content_type: auto`, `output_kind: base64`,
  `section_present`, `docx_table_has`, `heading_count`, custom `rubric` judge

---

## 9. Quick checklist: adding a new agent

1. Create `src/agents/<agent_id>/` with:
   - `agent.yaml` (agent_id, name, base_url)
   - `dataset.json` (target, metrics, cases)
   - `metrics_stub.json` (optional; or use `METRICS_SOURCE=capture`)

2. In `dataset.json`:
   - Set `target.adapter: "http"` and configure the endpoint, auth, body, and
     response mapping.
   - Define metrics referencing config-driven scorers by name.
   - Write golden cases with `input`, `golden_output`, `expected`, and
     `baseline_metrics`.

3. Start your agent and the eval service:
   ```powershell
   # Start your agent (or the matching sample agent)
   # Start the eval service:
   .\scripts\run_eval_service.ps1
   ```

4. Trigger an evaluation:
   ```powershell
   curl -X POST http://localhost:4002/api/evaluate `
     -H "Content-Type: application/json" `
     -d '{"agent_id":"<your_agent_id>"}'
   ```

5. Check `GET /api/health` for credential/Vertex status.
6. Open `http://localhost:4002` for the dashboard.

---

## 10. API reference — new endpoints

Beyond the core `POST /api/evaluate` and `GET /api/runs/{id}`, the service now
provides these operational endpoints:

### Run comparison
```powershell
# Compare two runs side-by-side
curl "http://localhost:4002/api/runs/compare?a=<run_id_a>&b=<run_id_b>"
```
Returns per-case scores, deltas, and improved/regressed flags.

### Baseline promotion
```powershell
# Promote a run's mean per-metric scores as the new baseline
curl -X POST "http://localhost:4002/api/baselines/promote/<run_id>"
```
Computes the mean score per metric across all cases and stores it as the blessed
baseline — used for delta tracking and drift detection on future runs.

### Async evaluate with webhook
```powershell
# Start a run in the background; POST the result to a webhook when done
curl -X POST http://localhost:4002/api/evaluate/async `
  -H "Content-Type: application/json" `
  -d '{"agent_id":"my_agent","webhook_url":"https://my-ci.example.com/hook"}'
```
Returns immediately with a `stream_id`. The service POSTs the completed run
record to the `webhook_url` when the run finishes.

### A/B comparison
```powershell
# Run two agents against the same dataset and compare
curl -X POST http://localhost:4002/api/evaluate/ab `
  -H "Content-Type: application/json" `
  -d '{"agent_a":"my_agent_v1","agent_b":"my_agent_v2"}'
```
Returns a per-case comparison with an overall winner.

### Run export
```powershell
# Export a run as CSV (for audit/compliance)
curl "http://localhost:4002/api/runs/<run_id>/export?format=csv" -o run.csv

# Export a run as PDF
curl "http://localhost:4002/api/runs/<run_id>/export?format=pdf" -o run.pdf
```

### Cursor pagination
```powershell
# First page
curl "http://localhost:4002/api/runs?limit=20"
# Response includes next_cursor; use it for the next page:
curl "http://localhost:4002/api/runs?limit=20&before=<next_cursor>"
```

---

## 11. Troubleshooting

| Symptom | Fix |
|---------|-----|
| `Unknown scorer 'X'` | Caught at startup by `Registry.validate()`. Check the scorer name in `dataset.json` matches a registered scorer (see §5-6) |
| All LLM judge metrics skipped | Vertex is unavailable. Set `PROJECT_NAME` + run `gcloud auth application-default login` (or WIF) |
| `docx_table_has` skipped | `python-docx` not installed. Run `pip install python-docx` |
| `pdf_table_has` skipped | `pdfplumber` not installed. Run `pip install pdfplumber` (optional) |
| `rubric_multi` skipped | Vertex unavailable (check `PROJECT_NAME`/ADC), or no `config.criteria` defined |
| PDF text extraction empty | `pypdf` not installed, or the PDF has no extractable text (scanned images) |
| `HTTP 407` on agent call | Corporate proxy intercepting localhost. Set `trust_env: false` in the target config |
| Agent returns 500 | Check your agent's logs; the eval service captures the error in `observation.error` |
| `output_path` not found | Check the dotted path matches your agent's actual response JSON structure |
| Old runs not deleted | Set `EVAL_RUN_RETENTION_DAYS > 0` in `.env`; cleanup runs on startup |
