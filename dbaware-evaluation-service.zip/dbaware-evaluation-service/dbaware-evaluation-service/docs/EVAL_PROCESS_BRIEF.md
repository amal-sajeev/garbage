# CTNA Evaluation Process — Technical Brief

This is a quick technical walkthrough of how one evaluation run works in this repo.

## 1) Entry points

- API server: `src/eval_service/main.py`
- Main endpoint: `POST /api/evaluate`
- Runner: `src/eval_service/runner.py` (`Runner.evaluate`)

A run can be triggered from:
- UI (`/`) 
- CI gate script: `scripts/ci_gate.py`

## 2) End-to-end execution flow

For one `POST /api/evaluate` request:

1. `main.py` validates request and calls `Runner.evaluate(...)`.
2. Runner loads the registered agent + dataset from `src/agents/<agent_id>/`.
3. For each golden case in `dataset.json`:
   - Calls target adapter (`adapters/target_agent.py`) to replay case input against the agent endpoint (typically `/api/eval/data-extraction-agent`) and capture an `Observation`.
   - Calls metrics adapter (`adapters/metrics_api.py`) to obtain a CTA-style metrics payload (`capture`, `http`, or `stub` source), then flattens it to scalar metrics.
   - Executes each scorer from the scorer registry (`scorers/base.py`) via `get_scorer(spec.scorer)`.
4. Runner builds per-metric `Score` objects (normalised score, threshold pass/fail, baseline, delta, rationale/evidence, critical flag).
5. `aggregation.gate(...)` computes:
   - weighted score
   - weighted delta vs baseline
   - case pass/fail with critical veto rules
6. Runner aggregates case results into a `RunRecord`, computes run statistics, and persists through repository layer.

## 3) Scoring model (important)

Each metric has a `MetricSpec` in dataset config:
- `weight`
- `threshold`
- optional `critical`
- direction/normalisation bounds for raw operational metrics

### Weighted score

\[
S = \frac{\sum_i s_i w_i}{\sum_i w_i}
\]

### Weighted delta vs baseline

\[
\Delta = \frac{\sum_i (s_i - b_i) w_i}{\sum_i w_i}
\]

### Gate logic

Run/case fails if any of the following fail:
- any `critical` metric fails
- any metric score below threshold
- dataset-level score below threshold
- regression exceeds tolerance

If a scorer cannot run in the current environment (for example Vertex unavailable), it raises `MetricSkipped`; that metric is omitted, not treated as hard failure.

## 4) Persistence behavior

Repository is selected by `EVAL_DB_URL`:
- `sqlite:///...` → local/offline SQLite
- `postgresql://` → CloudSQL Postgres (`CloudSqlRepository`)

Current production-style setup in this workspace uses Postgres via local Cloud SQL Auth Proxy (`DB_HOST=127.0.0.1`, `DB_PORT=5432`) and persists:
- `runs`
- `baselines`
- `labels`

## 5) Vertex judge path (WIF/ADC)

Judge/LLM metrics use `ChatGoogleGenerativeAI` in `scorers/vertex.py`.

Key conventions:
- `project=Config.PROJECT_NAME` is the Vertex routing switch.
- Auth is ADC/WIF (`GOOGLE_APPLICATION_CREDENTIALS` to WIF config), no API key.
- Fail-fast credential guard runs before client creation.
- Structured output (`JudgeVerdict`) is parsed and pass/fail is re-applied in code.

Operationally on corp network:
- proxy env vars must be present (`HTTP(S)_PROXY`)
- CA bundle must be set for TLS interception (`SSL_CERT_FILE`, `REQUESTS_CA_BUNDLE`)

## 6) Practical run modes

### Offline-fast validation
- Agent target: local sample agent (`scripts/run_sample_agent.ps1`, port 4010)
- `METRICS_SOURCE=capture`
- Vertex metrics may skip if credentials unavailable

### Full judge run (meeting/demo realistic)
- Eval service with WIF + proxy + CA bundle configured
- CloudSQL persistence enabled
- Trigger from UI or `scripts/ci_gate.py`
- Expect longer run times because judge calls are serial per case/metric

## 7) Useful endpoints

- `GET /api/health` — reports config + resolved credential class
- `GET /api/runs` — run summaries
- `GET /api/runs/{run_id}` — full detailed run
- `GET /api/captures` — captured CTA-style metrics (capture mode)

## 8) Typical failure signatures

- `HTTP 407` on localhost calls: local request accidentally routed through corporate proxy.
- `SSL CERTIFICATE_VERIFY_FAILED`: CA bundle not configured for proxy TLS interception.
- `PERMISSION_DENIED aiplatform.endpoints.predict`: identity lacks Vertex IAM permission in selected project/region.
- Judge metrics all skipped: Vertex credentials/project unavailable.

---

For full details, see:
- `docs/EVAL_SERVICE_DESIGN.md`
- `docs/VERTEX_INTEGRATION.md`
