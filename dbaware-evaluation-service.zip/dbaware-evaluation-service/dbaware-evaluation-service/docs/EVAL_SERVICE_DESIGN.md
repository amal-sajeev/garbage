# CTNA Evaluation Service — Technical Design

A standalone, separately-hosted **agent evaluation service** ("LLM-as-a-judge")
that scores production agents against a versioned **golden set** using both
**objective (deterministic)** checks and **LLM-based** judges, aggregates a
weighted pass/fail gate, tracks metric drift over time via a **weighted delta**,
and persists everything to a SQL store.

It can be driven two ways:

1. **Directly by a human** through a browser dashboard (served by the service).
2. **By a CI/CD pipeline** as an automated quality gate (single REST call, a
   non-zero process/HTTP status when the gate fails).

> Companion doc: [VERTEX_INTEGRATION.md](VERTEX_INTEGRATION.md) is the source of
> truth for the single Vertex call pattern this service reuses for its judge.

---

## 1. Goals & non-goals

**Goals**
- One REST surface (`/evaluate`, `/runs`) that both a human UI and a CI gate call.
- Objective + LLM scoring against a golden set of *(input, ideal output,
  baseline metrics)* triples.
- Re-run the **same golden inputs** against the live evaluation target through
  its **production APIs**, and fetch the **same metrics** from a separate
  metrics API.
- A weighted aggregate score, a threshold/baseline **gate**, and a **weighted
  delta** to trend metric change over time.
- Trivially **modular**: adding a new agent = drop in a config + dataset +
  optional custom tests, with no core code changes.
- Swappable persistence: **SQLite** for local dev, **CloudSQL** in production.

**Non-goals (for this iteration)**
- Training/fine-tuning models. This service only *evaluates*.
- Owning the metrics computation — metrics arrive from an external API
  (stubbed from a supplied JSON until that API is available).
- Hosting production agents — a separate agent service stands in as the target
  until real production endpoints exist.

---

## 2. Architecture

Component map matches the design diagram.

```mermaid
flowchart LR
    subgraph clients [Clients]
      human[Human · Web UI]
      ci[CI · Pipeline gate]
    end

    subgraph svc [CTNA Evaluation Service · FastAPI]
      api[API / Service<br/>/evaluate · /runs · /health]
      runner[Evaluation Runner<br/>load · orchestrate · state]
      adapters[Target Adapters<br/>Agent / MCP / custom]
      registry[Metric Registry<br/>deterministic · LLM judges]
      gate[Aggregation & Gate<br/>weighted score · delta · pass/fail]
      repo[(Evaluation Repository<br/>SQLite now · CloudSQL later)]
    end

    human -->|HTTPS| api
    ci -->|HTTPS| api
    api --> runner --> adapters
    runner --> registry
    registry --> gate --> repo
    runner --> repo

    adapters -->|/api/eval/*| target[Agent Service · :4000]
    adapters -->|metrics API| metrics[Metrics API · stubbed]
    registry -->|judge · project= · T=0| vertex[(Vertex AI · Gemini)]
    vertex --> iam[Google Cloud IAM · ADC/WIF]
```

| Component | Responsibility | Module |
|-----------|----------------|--------|
| API / Service | REST endpoints + static UI mount | `eval_service/main.py` |
| Evaluation Runner | Load evaluation, orchestrate a run, manage state | `eval_service/runner.py` |
| Target Adapters | Invoke the agent under test + fetch metrics | `eval_service/adapters/` |
| Metric Registry | Resolve deterministic + LLM scorers per metric | `eval_service/registry/` + `scorers/` |
| Aggregation & Gate | Weighted score, weighted delta, pass/fail vs baseline/threshold | `eval_service/aggregation.py` |
| Evaluation Repository | Persist runs, baselines, versioned datasets | `eval_service/repository/` |

---

## 3. Data flow (one `/evaluate` call)

1. Client `POST /evaluate {agent_id, dataset_version?, ...}`.
2. Runner loads the **agent target config** and its **golden dataset** from the
   registry/repository.
3. For each golden case:
   a. **Target Adapter** replays the case `input` against the agent's production
      API (`agent-service` `/api/eval/*`) → an **Observation** (output + tool
      trace + latency + usage).
   b. **Metrics Adapter** fetches the live metrics for that case from the
      metrics API (stubbed) → a metrics dict.
   c. **Scorers** run: deterministic checks compare output/metrics to the case's
      `expected`; the **LLM judge** compares output to `golden_output`.
4. **Aggregation & Gate** computes the weighted score, the weighted delta vs the
   case/dataset **baseline**, and the pass/fail decision.
5. Runner writes a **run record** (scores, deltas, pass/fail, raw observations)
   to the repository and returns it. CI maps `passed=false` → non-zero exit.

---

## 4. Golden-set schema

A dataset is a **versioned** JSON document owned by one agent. Each case is an
*(input, ideal output, baseline metrics)* triple plus expectation assertions.
The shape generalises existing golden-set patterns (see `src/agents/scope_extraction/dataset.json` for a worked example).

```jsonc
{
  "dataset_id": "scope_extraction",
  "version": "2026-08-12",              // bump to create a new immutable version
  "description": "...",
  "target": {                            // how to reach the agent for this set
    "adapter": "agent_eval_hook",
    "endpoint": "/api/eval/data-extraction-agent"
  },
  "metrics": [                           // metric registry entries + weights
    { "name": "tool_selection", "type": "deterministic",
      "scorer": "tool_selection", "weight": 2.0, "threshold": 1.0 },
    { "name": "faithfulness",   "type": "llm_judge",
      "scorer": "faithfulness",  "weight": 3.0, "threshold": 0.9 }
  ],
  "cases": [
    {
      "id": "app_single_unit",
      "input": { "query": "Get the AppCatalog application data for AU-10001 at Acme Corp." },
      "golden_output": "…the ideal answer text…",     // for LLM judge
      "expected": {                                    // deterministic assertions
        "expected_tool": "get_application_data",
        "expected_values": ["AU-10001", "Acme Corp"]
      },
      "baseline_metrics": {                            // per-case baseline to delta against
        "tool_selection": 1.0,
        "faithfulness": 0.95
      }
    }
  ]
}
```

- **inputs** → `case.input` (replayed through the production API).
- **expected ideal output** → `case.golden_output` (LLM judge reference).
- **baseline metrics** → `case.baseline_metrics` (per pair) and/or a
  dataset-level baseline stored in the repository from a prior blessed run.
- Assertions are **additive**: new cases/metrics are picked up automatically.

---

## 5. External metrics API contract (CTA_ACTION)

Until the real metrics service exists, the Metrics Adapter reads a supplied JSON
but behaves *as if* the data came from a live API. The metrics API returns a
**`CTA_ACTION`** record — a logged AI action whose `payload` carries the model
config, self-reported confidence, token counts, tool calls, and execution
timestamps:

```jsonc
// GET {METRICS_API_BASE}/metrics?case_id=app_single_unit   (stub: metrics_stub.json)
{
  "CTA_ACTION": {
    "action_id": "31fdf9ad-…",
    "plan_review_item_id": "app_single_unit",
    "timestamp": "2026-08-13 09:15:02:000000",
    "actor_type": "AI_AGENT",
    "action_type": "TOOL_LOOKUP",
    "target_entity_type": "assessment_unit",
    "target_entity_id": "AU-10001",
    "payload": {
      "Agent_Name": "scope_extraction",
      "Activity_Type": "Preliminary_Research",
      "AI_Model_Name": "gemini-2.5-pro",
      "AI_Model_Version": "2.5",
      "AI_Model_Config_Setting": { "model_temperature": "0.0", "model_top_p": "0.5",
                                   "model_top_k": "32", "seed": "42", "thinking_budget": "8192" },
      "Prompt_Version": { "prompt_1": "1.0" },
      "AI_Rationale": "…free-text rationale…",
      "AI_Confidence_Score": 0.94,
      "Token_Input_Count": "1820",
      "Token_Output_Count": "540",
      "Tool_Calls": [ { "Tool_Id": "get_application_data", "Call_Count": "1",
                        "Tool_Param": "AU-10001;Acme Corp", "Tool_Latency": "820", "Tool_Errors": [""] } ],
      "Response_Code": "200",
      "Execution_Start_Time": "2026-08-13 09:15:02:000000",
      "Execution_End_Time": "2026-08-13 09:15:03:820000"
    }
  }
}
```

The adapter **flattens** one CTA_ACTION into the numeric metric map the scorers
and gate consume, deriving aggregates from the raw fields:

| Derived metric | Source |
|----------------|--------|
| `ai_confidence_score` | `payload.AI_Confidence_Score` |
| `token_input_count` / `token_output_count` / `token_total_count` | `Token_Input_Count`, `Token_Output_Count` (sum) |
| `response_code` | `payload.Response_Code` |
| `execution_latency_ms` | `Execution_End_Time − Execution_Start_Time` |
| `tool_call_count` / `tool_latency_total` / `tool_error_count` | summed over `Tool_Calls[]` |

The adapter is a single interface (`MetricsClient.fetch(case_id, observation) -> dict`)
with three implementations selected by `METRICS_SOURCE`:

- **`capture`** — `CaptureMetricsClient` derives a `CTA_ACTION` from each **live
  agent Observation** (tool calls, token usage, latency, model, error →
  confidence) and holds it in an in-memory `CaptureStore`. This lets the sample
  agents be run and the whole service exercised **without a database or the
  external metrics API**; captured records are exposed at `GET /api/captures`.
- **`http`** — `HttpMetricsClient` hits the real `CTA_ACTION` API (`METRICS_API_BASE`).
- **`stub`** — `StubMetricsClient` reads the agent's `metrics_stub.json`.

All three feed the identical `derive_metrics` flattening, so scorers and the gate
are unchanged across sources.

### 5a. Offline runnable stack (sample agent + capture)

A bundled **sample LangChain agent** (`src/sample_agents/data_extraction_agent.py`,
real LangChain `@tool` + `Runnable`, deterministic router in place of a hosted
LLM) serves the same `/api/eval/data-extraction-agent` contract on `:4010`. With
`AGENT_SERVICE_BASE_URL=http://localhost:4010` and `METRICS_SOURCE=capture`, the
service runs a full evaluation with no Vertex and no DB. The LLM judge metric is
**skipped** (via `MetricSkipped`) when no ADC credentials are present, rather than
failing the run.

---

## 6. Scoring

Scorers are registered via a `@scorer("name")` decorator into a central registry
(`get_scorer`, `all_scorers`). A scorer is a function
`(observation, expected, metrics, *, spec) -> float | (float, extras)` where
`extras` may carry `raw_value` (pre-normalisation, for audit) and `variance`
(judge self-consistency). A scorer may raise `MetricSkipped` to omit itself
cleanly (e.g. a Vertex-dependent metric when no ADC credentials are present),
so the same dataset runs both offline and in production. Every metric declares a
`MetricSpec` with `weight`, `threshold`, `critical`, `direction`
(`higher_is_better` / `lower_is_better`), `unit`, and `norm_min` / `norm_max`
normalisation bounds. **27 scorers** ship across the families below.

### 6.1 Objective (deterministic) scorers
Pure functions over the captured trajectory and output:
- `tool_selection` — did the agent call `expected_tool` and pass through
  `expected_values` (substring match on serialised args)? Score = fraction correct.
- `assertions` — verbatim presence/absence of required strings and regex patterns.
- `metric_threshold` — a supplied CTA-derived metric value ≥ its threshold.
- `ai_confidence` — uses the CTA_ACTION `AI_Confidence_Score` (0..1) directly.

### 6.2 Reference-similarity scorers
How close the output is to the golden ideal answer:
- `token_overlap_f1` — token-level precision/recall F1 vs the expected output.
- `edit_similarity` — normalised Levenshtein similarity.
- `json_schema_valid` — structured output conforms to the expected schema.
- `embedding_similarity` — cosine similarity of Vertex embeddings
  (`text-embedding-004`); **skips offline** (no ADC).

### 6.3 Trajectory / tool-use scorers
Did the agent *act* correctly, not just answer correctly:
- `tool_order_correct` — tools invoked in the expected order.
- `no_redundant_calls` — penalises duplicate/redundant tool calls.
- `tool_arg_accuracy` — arguments passed to each tool match expectations.
- `tool_error_free` — **critical**; no tool raised an error.
- `step_efficiency` — steps taken vs an expected budget.

### 6.4 Safety / compliance scorers (critical vetoes)
All marked `critical: true` — a single failure **fails the whole case**
regardless of weighted score (see §7):
- `no_pii_leakage` — output contains no un-redacted PII patterns.
- `prompt_injection_safe` — agent did not follow injected instructions.
- `refusal_appropriate` — refused when it should, answered when it should.
- `groundedness` — LLM check that claims are grounded in retrieved context;
  **skips offline**.

### 6.5 Operational SLO scorers
Latency and cost, normalised via `direction: lower_is_better` + `norm_min/max`;
each returns the `raw_value` in `extras` for audit:
- `latency_slo` — end-to-end latency vs SLO (ms).
- `tool_latency_slo` — per-tool latency vs SLO.
- `token_cost_budget` — token usage vs a budget.
- `response_success` — **critical**; the agent returned a usable response.

### 6.6 LLM judge (rubric + self-consistency)
Reuses the **one Vertex pattern** from [VERTEX_INTEGRATION.md](VERTEX_INTEGRATION.md):

```python
ChatGoogleGenerativeAI(
    model=Config.JUDGE_MODEL,          # gemini-2.5-pro
    project=Config.PROJECT_NAME,       # project= is the switch → Vertex
    location=Config.PROJECT_LOCATION,
    temperature=Config.JUDGE_TEMPERATURE,   # 0
    max_retries=Config.JUDGE_MAX_RETRIES,   # 2
).with_structured_output(JudgeVerdict)
```

- `JudgeVerdict = { score: float, passed: bool, rationale: str, evidence: list[str] }`.
- Beyond `faithfulness`, the judge scores five rubric dimensions via a shared
  factory: `relevance`, `completeness`, `coherence`, `conciseness`,
  `instruction_following`. All judge metrics **skip offline**.
- **Self-consistency**: each judge metric is sampled `EVAL_JUDGE_SAMPLES` times;
  the mean is the score and the **variance** is recorded in `extras` (surfaced on
  the `Score`) as a reliability signal — high variance flags an unstable verdict.
- Fail-fast ADC guard **before** constructing the client (`PROJECT_NAME` +
  `google.auth.default()`), to avoid the misleading
  `'BaseApiClient' object has no attribute '_async_httpx_client'` error.
- `passed` is **re-applied in code** (`verdict.passed = verdict.score >= threshold`),
  never trusted from the model. `.invoke()` runs via `asyncio.to_thread`.

---

## 7. Aggregation, gate & weighted delta

Given per-metric scores $s_i$, baselines $b_i$, weights $w_i$, thresholds $t_i$:

- **Normalisation**: each raw scorer value is mapped to $[0,1]$ using its
  `MetricSpec` (`direction` + `norm_min` / `norm_max`). For
  `lower_is_better` metrics (latency, cost) the mapping is inverted, so a low
  raw value yields a high normalised score. The pre-normalisation `raw_value` is
  retained on the `Score` for audit.
- **Weighted score** (overall quality of this run):
  $$S = \frac{\sum_i s_i \cdot w_i}{\sum_i w_i}$$
- **Weighted delta** (drift vs baseline, tracked over time):
  $$\Delta = \frac{\sum_i (s_i - b_i) \cdot w_i}{\sum_i w_i}$$
  Computed per-case and aggregated per-run, then trended across historical runs
  in the repository. $\Delta < 0$ is a regression, $\Delta > 0$ an improvement;
  a configurable regression tolerance can fail the gate on drift even when
  absolute thresholds pass.
- **Critical veto**: any metric with `critical: true` that fails **fails the
  whole case**, irrespective of $S$. This is the banking-grade safety net —
  a strong average can never mask a PII leak, prompt-injection breach, tool
  error, or empty response.
- **Gate**: `passed = (no critical metric failed) AND (all metrics s_i ≥ t_i) AND (S ≥ dataset_threshold) AND (Δ ≥ -regression_tolerance)`.

### 7.1 Dataset-level statistics (`RunStats`)

Beyond per-case gating, each run carries a `RunStats` block (`aggregation.run_statistics`)
that quantifies confidence across the whole golden set. CIs and the drift test
use a normal (z) approximation so the service stays dependency-free; for small
$n$ they are indicative and a Student-t correction applies when a stats backend
is added.

- **Pass rate** and **mean score** with a **95% confidence interval**
  $\bar S \pm z_{.975}\,\sigma/\sqrt{n}$ — reports how tightly the run's quality
  is estimated, not just a point number.
- **Drift significance**: a two-sided z-test on the per-case deltas. A regression
  is flagged (`drift_significant = true`) only when the mean delta is negative
  **and** $p < 0.05$ — statistically real degradation, not sampling noise.
- **Judge-vs-human calibration** (populated when human labels exist for the run's
  cases): treats the gate's per-case pass/fail as the *prediction* and the human
  label as *truth*, yielding **precision / recall / F1** and **Cohen's κ**
  (chance-corrected agreement). This tells you whether the automated gate can be
  trusted for a banking release, and surfaces over- or under-strict thresholds.

### 7.2 Human-in-the-loop labels

Experts post verdicts to `POST /api/labels` (`{case_id, verdict: pass|fail,
score?, labeler, note}`), held in an in-memory `LabelStore` (`labels.py`) — a
schema-independent, offline-safe singleton mirroring `capture_store`. The runner
reads `label_store.verdict_map()` as ground truth when building `RunStats`, so
the next run reports calibration. A persistent backend can replace the store
later without changing callers.

---

## 8. Persistence (SQLite offline, CloudSQL in production)

A single `EvaluationRepository` interface hides the backend; the runner, scorers
and API never know which is active. `build_repository()` selects one from
`EVAL_DB_URL`:

- `sqlite:///path` → **`SqliteRepository`** (WAL-enabled) — the default, fully
  offline local-dev backend.
- `postgresql://` → **`CloudSqlRepository`** — CloudSQL Postgres via the **Cloud
  SQL Python Connector** (pg8000) + SQLAlchemy.

Tables (identical shape on both backends):

| Table | Key columns |
|-------|-------------|
| `runs` | `run_id`, `agent_id`, `dataset_id`, `dataset_version`, `weighted_score`, `weighted_delta`, `passed`, `created_at`, `detail_json` (full `RunRecord`, incl. per-case results + `RunStats`) |
| `baselines` | `agent_id`, `dataset_version`, `metric`, `baseline_value` (the blessed reference) |
| `labels` | `case_id`, `verdict`, `score`, `labeler`, `note`, `run_id`, `created_at` (durable human-in-the-loop ground truth) |

Baselines can be seeded from the dataset's `baseline_metrics` or promoted from a
chosen "golden" run. Human labels are persisted here so expert verdicts survive
restarts (they seed the in-memory `label_store` at startup and back every
`POST /api/labels`).

### 8.1 CloudSQL connection & auth

`CloudSqlRepository` connects to a configured Cloud SQL instance and database,
through the Cloud SQL Connector — there is **no direct SSL/IP wiring**. Auth is
**IAM/ADC**, the *same credential chain as the Vertex judge*
([VERTEX_INTEGRATION.md](VERTEX_INTEGRATION.md)): `gcloud auth
application-default login` locally, Workload Identity Federation in GKE. A
**fail-fast ADC guard** (`google.auth.default()`) runs before the engine is
built, turning opaque connector errors into clear credential guidance.

Two **least-privilege roles** are used:

- `eval_owner` (`DB_OWNER_USER`) — runs the one-time `CREATE TABLE IF NOT
  EXISTS` DDL in `init_schema()`.
- `eval_user` (`DB_USER`) — the runtime account for all reads/writes.

**Passwords are never committed.** They come from env (`DB_PASSWORD`,
`DB_OWNER_PASSWORD`) for local dev, or Google Secret Manager
(`DB_PASSWORD_SECRET`) in production, resolved lazily by `Config.resolve_secret`.
SQL is portable: writes use Postgres `INSERT … ON CONFLICT … DO UPDATE`
(the equivalent of SQLite's `INSERT OR REPLACE`).

---

## 9. Modularity — adding a new agent

Everything for one agent lives in `src/agents/<agent_id>/`:

```
src/agents/scope_extraction/
  agent.yaml         # id, name, base_url, adapter, default dataset, judge settings
  dataset.json       # the golden set (section 4)
  metrics_stub.json  # stubbed metrics API response (section 5)
  custom_tests.py    # optional agent-specific deterministic scorers
```

The **registry** auto-discovers these folders at startup. `custom_tests.py`
registers extra scorers via a decorator (`@scorer("my_check")`) that the dataset
then references by name. No core edits required to onboard an agent, its dataset,
its standard tests, or its bespoke tests.

---

## 10. API surface

| Method / Path | Purpose |
|---------------|---------|
| `POST /evaluate` | Start (and await) an evaluation run; body `{agent_id, dataset_version?, judge_repetitions?}`. Returns the run record. |
| `GET /runs` | List run summaries (for the dashboard + history). |
| `GET /runs/{run_id}` | Full run detail incl. per-case results. |
| `GET /agents` | List registered agents + datasets. |
| `GET /api/health` | Config + ADC probe; reports resolved **credential class name** (`Credentials` = gcloud; `IdentityPoolCredentials`/`ExternalAccountCredentials` = WIF). |
| `GET /` | HTML dashboard (static, served by FastAPI). |

**CI/CD usage**: pipeline calls `POST /evaluate`, reads `passed`; a thin wrapper
script exits non-zero when `passed=false`, failing the build.

---

## 11. Configuration / env

Follows [VERTEX_INTEGRATION.md](VERTEX_INTEGRATION.md) §7. The code path that
reaches Vertex uses `PROJECT_NAME` / `PROJECT_LOCATION` (not `GOOGLE_CLOUD_*`).

| Variable | Default | Meaning |
|----------|---------|---------|
| `PROJECT_NAME` | *(none)* | GCP project id; presence selects the Vertex backend |
| `PROJECT_LOCATION` | `us-central1` | Vertex region |
| `EVAL_JUDGE_MODEL` | `gemini-2.5-pro` | Judge model |
| `EVAL_JUDGE_TEMPERATURE` | `0` | Judge temperature |
| `EVAL_JUDGE_MAX_RETRIES` | `2` | Judge client retries |
| `GOOGLE_APPLICATION_CREDENTIALS` | *(none)* | ADC file / WIF credential config |
| `EVAL_JUDGE_SAMPLES` | `1` | Judge self-consistency samples; mean scored, variance recorded |
| `EVAL_EMBEDDING_MODEL` | `text-embedding-004` | Vertex model for `embedding_similarity` |
| `METRICS_SOURCE` | `stub` | Metrics backend: `capture` \| `http` \| `stub` |
| `EVAL_SERVICE_PORT` | `4002` | Service port (siblings use 4000/4001/8000) |
| `EVAL_DB_URL` | `sqlite:///./eval_service.db` | Persistence switch: `sqlite:///…` (offline) or `postgresql://` (CloudSQL) |
| `DB_INSTANCE_CONNECTION_NAME` | *(none)* | Cloud SQL instance (project:region:instance) |
| `DB_NAME` | `evaldb` | Target Postgres database |
| `DB_SCHEMA` | `public` | Postgres schema for the tables |
| `DB_IP_TYPE` | `PUBLIC` | Connector IP type: `PUBLIC` (workstation) \| `PRIVATE` (GKE) |
| `DB_USER` | `eval_user` | Runtime least-privilege role |
| `DB_PASSWORD` / `DB_PASSWORD_SECRET` | *(none)* | Runtime password from env or GSM (never committed) |
| `DB_OWNER_USER` | `eval_owner` | Role for the one-time DDL/init step |
| `DB_OWNER_PASSWORD` / `DB_OWNER_PASSWORD_SECRET` | *(none)* | Owner password from env or GSM (never committed) |
| `AGENT_SERVICE_BASE_URL` | `http://localhost:4000` | Evaluation target base |
| `METRICS_API_BASE` | *(stub)* | Metrics API base; unset → stub JSON |

If your environment requires a private package index, configure `pip` or pass
`--index-url` as needed (see [python use examples](python%20use%20examples));
new deps are pinned in `requirements.txt`.

---

## 12. Local verification plan

1. Start the target agent: the sample agent-service on `:4000` (or the bundled
   sample agent on `:4010`).
2. Start this service on `:4002`; check `GET /api/health` reports a credential
   class (Vertex/ADC wired).
3. `POST /evaluate {agent_id: "scope_extraction"}`; confirm a run record with
   weighted score, weighted delta, per-case results, and a pass/fail gate.
4. Open `/` and inspect the run in the dashboard; re-run to see the delta trend.
