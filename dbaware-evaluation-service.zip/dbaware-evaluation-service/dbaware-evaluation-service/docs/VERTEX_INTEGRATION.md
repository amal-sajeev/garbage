# How the CTNA Project Calls Vertex AI

A technical reference describing every place the CTNA project talks to
Google Vertex AI, how the backend is selected, how it authenticates, and how the
configuration flows through the code.

---

## 1. Summary

The project never uses a Gemini **API key**. Every model call goes to **Vertex
AI** (`aiplatform.googleapis.com`) and authenticates with **Google Cloud IAM**
via **Application Default Credentials (ADC)** — either a local `gcloud` login or
**Workload Identity Federation (WIF)** in GKE.

All Vertex traffic flows through a single library, `langchain-google-genai`
(4.x), using its `ChatGoogleGenerativeAI` client. There is no direct use of the
`vertexai` SDK or `google-generativeai`.

There are **two independent call sites**:

| Call site | Purpose | Model | File |
|-----------|---------|-------|------|
| Agent service | The scoping/data-extraction agent LLM | `gemini-2.5-pro` | `agent-service/src/main/utils/vertexai_connection.py` |
| Evaluation service | LLM-as-a-judge scoring | `gemini-2.5-pro` (T=0) | `src/eval_service/scorers/vertex.py` |

Both construct the client the same way and rely on the same credential chain.

---

## 2. Backend selection: why this is Vertex and not the Developer API

`langchain-google-genai` 4.x can target two different backends:

- **Gemini Developer API** — `generativelanguage.googleapis.com`, authenticated
  with `GOOGLE_API_KEY`.
- **Vertex AI** — `aiplatform.googleapis.com`, authenticated with Google Cloud
  IAM.

It picks the backend automatically, in this order:

1. `GOOGLE_GENAI_USE_VERTEXAI` env var, if set.
2. Vertex, if a `credentials` object was passed.
3. **Vertex, if a `project=` was passed** — *this is the branch the project takes.*
4. Otherwise, the Gemini Developer API.

The code never sets `vertexai=True`; it simply passes `project=` and `location=`
to the constructor, which is sufficient to switch the whole library to Vertex:

```python
llm = ChatGoogleGenerativeAI(
    model=Config.MODEL_NAME,
    project=Config.PROJECT_NAME,
    location=Config.PROJECT_LOCATION,
    ...
)
```

**Consequence:** if `PROJECT_NAME` / `PROJECT_LOCATION` is empty, the library
silently falls back to the Developer API and then fails with a confusing
"no API key" error rather than a credentials error. Both call sites guard
against this explicitly (see §5).

---

## 3. Call site A — the agent service

File: `agent-service/src/main/utils/vertexai_connection.py`

```python
def initialize_gemini_model() -> ChatGoogleGenerativeAI:
    _require_vertex_credentials()
    llm = ChatGoogleGenerativeAI(
        model=Config.MODEL_NAME,                                 # gemini-2.5-pro
        project=Config.PROJECT_NAME,                             # -> selects Vertex
        location=Config.PROJECT_LOCATION,                        # e.g. us-central1
        temperature=Config.GENERATION_CONFIG["temperature"],     # 0.0
        top_p=Config.GENERATION_CONFIG["top_p"],                 # 0.5
        top_k=Config.GENERATION_CONFIG.get("top_k"),             # 32
        safety_settings=Config.SAFETY_CONFIG["safety_settings"],
    )
    return llm
```

Configuration comes from the agent service `config.py`:

- `MODEL_NAME = "gemini-2.5-pro"` (hard-coded)
- `GENERATION_CONFIG` — `temperature=0.0`, `top_p=0.5`, `top_k=32`
- `SAFETY_CONFIG` — all four HARM categories set to `BLOCK_MEDIUM_AND_ABOVE`
- `PROJECT_NAME = os.getenv("PROJECT_NAME")`
- `PROJECT_LOCATION = os.getenv("PROJECT_LOCATION")`

The returned `llm` is a standard LangChain chat model that the agent then binds
to its MCP tools and invokes in its workflow.

---

## 4. Call site B — the evaluation judge

File: `src/eval_service/scorers/vertex.py` (this repo)

```python
def _model():
    if not Config.PROJECT_NAME:
        raise RuntimeError("PROJECT_NAME is not set; the evaluation judge requires Vertex AI.")
    try:
        google.auth.default()
    except Exception as exc:
        raise RuntimeError("No Application Default Credentials are available ...") from exc
    return ChatGoogleGenerativeAI(
        model=Config.JUDGE_MODEL,               # gemini-2.5-pro
        project=Config.PROJECT_NAME,            # -> selects Vertex
        location=Config.PROJECT_LOCATION,       # us-central1 (default)
        temperature=Config.JUDGE_TEMPERATURE,   # 0.0
        max_retries=Config.JUDGE_MAX_RETRIES,   # 2
    ).with_structured_output(JudgeVerdict)
```

Notable specifics for the judge:

- `.with_structured_output(JudgeVerdict)` forces the model to return a typed
  Pydantic object (`score`, `passed`, `rationale`, `evidence[]`) rather than
  free text.
- Temperature is **0** for determinism; the numeric threshold is re-applied in
  code (`verdict.passed = verdict.score >= metric_threshold`) rather than
  trusted from the model.
- The synchronous `.invoke()` is dispatched via `asyncio.to_thread`, and can be
  repeated (`judge_repetitions`, capped 1–5) with scores averaged and variance
  recorded.

Configuration from [`src/eval_service/config.py`](../src/eval_service/config.py):

- `PROJECT_NAME = os.getenv("PROJECT_NAME")`
- `PROJECT_LOCATION = os.getenv("PROJECT_LOCATION", "us-central1")`
- `JUDGE_MODEL = os.getenv("EVAL_JUDGE_MODEL", "gemini-2.5-pro")`
- `JUDGE_TEMPERATURE = float(os.getenv("EVAL_JUDGE_TEMPERATURE", "0"))`
- `JUDGE_MAX_RETRIES = int(os.getenv("EVAL_JUDGE_MAX_RETRIES", "2"))`

The eval service deliberately reuses the **same project, region and ADC
credentials** as the agent service, so both halves of a run exercise the same
Vertex path.

---

## 5. Authentication — Application Default Credentials

Having selected Vertex, the SDK authenticates with **ADC**. ADC is a search
order, tried top to bottom:

1. `GOOGLE_APPLICATION_CREDENTIALS` pointing at a credential file.
2. The gcloud user credentials from `gcloud auth application-default login`.
3. The attached service account of the compute environment (GCE, GKE, Cloud Run).

### Workload Identity Federation (production / GKE)

WIF is item 1 with a specific kind of file: instead of a long-lived
service-account key, the file is a **credential configuration** that instructs
the auth library to:

1. read a token from a local path (in GKE, a projected Kubernetes
   service-account JWT),
2. exchange it at Google's STS endpoint for a federated access token,
3. optionally impersonate a target service account.

No code in the project knows any of this — `google.auth.default()` reads the
config file and performs the exchange. No long-lived key material ever exists.

### Local development

Supply item 2 instead:

```powershell
gcloud auth application-default login
gcloud auth application-default set-quota-project <your-project-id>
```

---

## 6. Fail-fast credential guards

Both call sites call `google.auth.default()` **before** constructing the client.
This is intentional. `google-genai` resolves credentials early in
`BaseApiClient.__init__` but assigns `_async_httpx_client` late. A credentials
failure therefore leaves a half-built object, whose `__del__` schedules an
`aclose()` that raises a misleading:

```
AttributeError: 'BaseApiClient' object has no attribute '_async_httpx_client'
```

By checking `PROJECT_NAME` and calling `google.auth.default()` up front, the code
raises a clear, actionable `RuntimeError` instead:

```
RuntimeError: No Application Default Credentials available for Vertex AI.
Locally, run: gcloud auth application-default login. In GKE, check that the
Workload Identity Federation credential config is mounted and
GOOGLE_APPLICATION_CREDENTIALS points at it.
```

### Health endpoint

The agent(-test) service exposes a `/api/health` check
(the service's `GET /api/health` endpoint)
that verifies both halves — configuration then credentials — and reports the
resolved **credential class name**, which tells you which ADC branch is active:

- `Credentials` → gcloud user creds
- `IdentityPoolCredentials` / `ExternalAccountCredentials` → WIF

---

## 7. Configuration reference

| Variable | Used by | Default | Meaning |
|----------|---------|---------|---------|
| `PROJECT_NAME` | agent + eval | *(none)* | GCP project id; presence selects the Vertex backend |
| `PROJECT_LOCATION` | agent + eval | `us-central1` (eval) | Vertex region |
| `EVAL_JUDGE_MODEL` | eval | `gemini-2.5-pro` | Judge model |
| `EVAL_JUDGE_TEMPERATURE` | eval | `0` | Judge sampling temperature |
| `EVAL_JUDGE_MAX_RETRIES` | eval | `2` | Judge client retries |
| `GOOGLE_APPLICATION_CREDENTIALS` | auth | *(none)* | ADC file / WIF credential config path |
| `GOOGLE_GENAI_USE_VERTEXAI` | library | *(none)* | Optional explicit backend override |

> Note: the agent service reads `PROJECT_NAME`/`PROJECT_LOCATION` from env with
> no default, whereas the README/copilot docs also reference
> `GOOGLE_CLOUD_PROJECT` / `GOOGLE_CLOUD_LOCATION`. The **code path** that
> actually reaches Vertex uses `PROJECT_NAME` / `PROJECT_LOCATION`.

---

## 8. End-to-end request flow

```mermaid
flowchart LR
    client -->|/evaluate| eval[Evaluation Service]
    eval -->|invoke agent| agent[Agent Service]
    agent -->|ChatGoogleGenerativeAI project=| V[(Vertex AI · Gemini)]
    agent -->|MCP tools| mcp[MCP Server]
    eval -->|LLM-as-judge project=| V
    V -->|ADC: gcloud creds or WIF| iam[Google Cloud IAM]
```

1. A client posts to `/evaluate` on the eval service.
2. The eval service drives the agent service, which calls Vertex to run the
   scoping/extraction agent (and MCP tools).
3. The eval service then calls Vertex again as an LLM judge to score the output.
4. Every Vertex call authenticates through ADC → IAM (gcloud creds locally, WIF
   in GKE). No API keys are involved.

---

## 9. Key takeaways

- **One library, one pattern:** `ChatGoogleGenerativeAI(project=..., location=...)`
  is the entire Vertex integration surface.
- **`project=` is the switch** that routes to Vertex; there is no `vertexai=True`.
- **No API keys** — authentication is IAM/ADC, with WIF in production.
- **Fail-fast guards** turn opaque SDK errors into clear credential guidance.
- **Agent and judge share the same project/region/credentials**, so evaluation
  runs the exact same Vertex path as production.
