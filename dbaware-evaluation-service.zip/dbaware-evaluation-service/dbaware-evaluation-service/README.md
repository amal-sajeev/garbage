# CTNA Evaluation Service

A separately-hosted **agent evaluation service** (LLM-as-a-judge). It scores
production agents against a versioned **golden set** using both **objective
(deterministic)** checks and **LLM-based** judges, computes a weighted pass/fail
gate plus a **weighted delta** to trend metric drift over time, and persists runs
to SQL. It can be driven directly by a human (browser dashboard) or by a CI/CD
pipeline (one REST call, non-zero exit on failure).

See [docs/EVAL_SERVICE_DESIGN.md](docs/EVAL_SERVICE_DESIGN.md) for the full design
and [docs/VERTEX_INTEGRATION.md](docs/VERTEX_INTEGRATION.md) for the Vertex judge
pattern.

## Layout

```
src/eval_service/      FastAPI app, runner, scorers, adapters, repository, UI
src/agents/<id>/       one folder per evaluated agent (config + golden set + tests)
scripts/               run_eval_service.ps1, ci_gate.py
```

## Setup

Create a virtual environment and install dependencies:

```bat
python -m venv .venv
.venv\Scripts\python.exe -m pip install -r requirements.txt
```

If your environment requires a private package index, configure `pip` or pass
`--index-url` per your organisation's standards.

Copy `.env.example` to `.env` and set `PROJECT_NAME` / `PROJECT_LOCATION`, then:

```powershell
gcloud auth application-default login
```

## Run

1. Start the evaluation target agent on `:4000`.
2. Start this service:

   ```powershell
   .\scripts\run_eval_service.ps1
   ```

3. Open http://localhost:4002 for the dashboard, or check wiring:

   ```powershell
   curl http://localhost:4002/api/health
   ```

## Run fully offline (sample agent + capture service, no DB, no Vertex)

To exercise the whole pipeline without the production agent, the metrics API, or
Google Cloud credentials, use the bundled **sample LangChain agent** and the
**capture service** (which derives a `CTA_ACTION` from each live agent run and
holds it in memory):

```powershell
# 1. Start the sample agent on :4010
.\scripts\run_sample_agent.ps1

# 2. In another terminal, point the eval service at it in capture mode
$env:AGENT_SERVICE_BASE_URL = "http://localhost:4010"
$env:METRICS_SOURCE = "capture"
.\scripts\run_eval_service.ps1

# 3. Evaluate, then inspect the captured CTA_ACTIONs
Invoke-RestMethod http://localhost:4002/api/evaluate -Method Post `
  -Body '{"agent_id":"scope_extraction"}' -ContentType 'application/json'
Invoke-RestMethod http://localhost:4002/api/captures
```

`METRICS_SOURCE` selects where metrics come from: `capture` (live, in-memory),
`http` (the real `CTA_ACTION` API via `METRICS_API_BASE`), or `stub` (the
agent's `metrics_stub.json`). The LLM judge metric is skipped automatically when
no Vertex credentials are present, so the run still completes offline.


## CI/CD gate

```powershell
.venv\Scripts\python.exe scripts\ci_gate.py --agent scope_extraction
```

Exits non-zero when the gate fails (regression or below threshold), failing the
pipeline step.

## Add a new agent

Create `src/agents/<agent_id>/` with:

- `agent.yaml` — id, name, base_url, dataset/metrics files
- `dataset.json` — the golden set (inputs, ideal outputs, baseline metrics)
- `metrics_stub.json` — stubbed metrics-API response (until the real API exists)
- `custom_tests.py` — optional bespoke scorers via `@scorer("name")`

The registry auto-discovers it at startup — no core code changes.

**Config-driven agent calls**: set `target.adapter: "http"` in `dataset.json`
to call any agent HTTP endpoint (GET/POST/PUT, auth, params, body, response
mapping) without writing Python. Supports document outputs (PDF, DOCX,
Markdown, JSON) with automatic text extraction.

**Config-driven metrics**: 11 scorers parameterised via `MetricSpec.config`
(text/regex: `contains`, `regex_match`, `length_range`, `keyword_count`; JSON:
`json_path`, `field_match`, `json_schema_valid`; document: `section_present`,
`heading_count`, `docx_table_has`; custom LLM: `rubric`). No Python needed.

See [docs/AGENT_CONFIG_GUIDE.md](docs/AGENT_CONFIG_GUIDE.md) for a complete
engineer tutorial and [docs/UPGRADES_AND_CHANGES.md](docs/UPGRADES_AND_CHANGES.md)
for the full changelog.

## Demo agents

Three sample LangChain agents (hostable standalone) demonstrate the upgrades:

```powershell
.\scripts\run_report_writer_agent.ps1    # Markdown reports  (port 4011)
.\scripts\run_invoice_parser_agent.ps1    # JSON invoices    (port 4012)
.\scripts\run_document_qa_agent.ps1      # DOCX + PDF docs  (port 4013)
```

Evaluate any of them:
```powershell
Invoke-RestMethod http://localhost:4002/api/evaluate -Method Post `
  -Body '{"agent_id":"report_writer"}' -ContentType 'application/json'
```

## Notes

- **Persistence:** SQLite today (`EVAL_DB_URL=sqlite:///...`). A `CloudSqlRepository`
  slots into `build_repository()` when CloudSQL connection details arrive.
- **Metrics API:** stubbed from each agent's `metrics_stub.json`; set
  `METRICS_API_BASE` to switch to the live API with no scorer changes.
