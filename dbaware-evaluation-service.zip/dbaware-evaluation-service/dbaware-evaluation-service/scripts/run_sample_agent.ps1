# Starts the local sample LangChain agent on :4010 (no Vertex / no DB needed).
# Point the eval service at it with AGENT_SERVICE_BASE_URL=http://localhost:4010
# and METRICS_SOURCE=capture.
$ErrorActionPreference = "Stop"
$root = Split-Path -Parent $PSScriptRoot
$repoRoot = Split-Path -Parent $root
$py = Join-Path $root ".venv\Scripts\python.exe"
if (-not (Test-Path $py)) { $py = Join-Path $repoRoot ".venv\Scripts\python.exe" }
if (-not (Test-Path $py)) { $py = "python" }

$env:PYTHONPATH = Join-Path $root "src"
& $py (Join-Path $root "src\sample_agents\data_extraction_agent.py")
