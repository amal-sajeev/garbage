"""CI/CD gate wrapper.

Calls the running evaluation service, prints a summary, and exits non-zero when
the gate fails — so a pipeline step fails the build on a regression.

Usage:
    python scripts/ci_gate.py --agent scope_extraction [--base http://localhost:4002]
"""

from __future__ import annotations

import argparse
import sys

import httpx


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--agent", required=True)
    ap.add_argument("--base", default="http://localhost:4002")
    ap.add_argument("--reps", type=int, default=1)
    args = ap.parse_args()

    resp = httpx.post(
        f"{args.base.rstrip('/')}/api/evaluate",
        json={"agent_id": args.agent, "judge_repetitions": args.reps},
        timeout=600.0,
    )
    if resp.status_code != 200:
        print(f"evaluate failed: HTTP {resp.status_code}: {resp.text}", file=sys.stderr)
        return 2

    run = resp.json()
    print(
        f"run {run['run_id'][:8]} · {run['agent_id']} v{run['dataset_version']} · "
        f"score={run['weighted_score']:.3f} delta={run['weighted_delta']:+.3f} · "
        f"{'PASS' if run['passed'] else 'FAIL'}"
    )
    for c in run["case_results"]:
        flags = ",".join(f"{s['metric']}={s['score']:.2f}" for s in c["scores"])
        print(f"  {'PASS' if c['passed'] else 'FAIL'} {c['case_id']}: {flags}")

    return 0 if run["passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
