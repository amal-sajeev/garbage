# Starts the Report Writer sample agent on :4011 (no Vertex / no DB needed).
$ErrorActionPreference = "Stop"
$root = Split-Path -Parent $PSScriptRoot
$repoRoot = Split-Path -Parent $root
$py = Join-Path $root ".venv\Scripts\python.exe"
if (-not (Test-Path $py)) { $py = Join-Path $repoRoot ".venv\Scripts\python.exe" }
if (-not (Test-Path $py)) { $py = "python" }

$env:PYTHONPATH = Join-Path $root "src"
& $py (Join-Path $root "src\sample_agents\report_writer_agent.py")
