"""Live CloudSQL connection smoke test.

Run AFTER `gcloud auth application-default login` has written ADC. It:
  1. checks ADC is resolvable (google.auth.default),
  2. builds the CloudSqlRepository (Cloud SQL Connector + pg8000),
  3. verifies the Liquibase-managed schema exists (init_schema),
  4. writes a throwaway HumanLabel and reads it back,
  5. reports the resolved ADC credential class (Credentials = gcloud user,
     IdentityPoolCredentials/ExternalAccountCredentials = WIF).

Secrets are read from the environment only — nothing is committed. Required env:
  DB_INSTANCE_CONNECTION_NAME, DB_NAME, DB_USER, DB_PASSWORD
  (optional) DB_OWNER_USER, DB_OWNER_PASSWORD, DB_SCHEMA, DB_IP_TYPE
  EVAL_DB_URL=postgresql://   (backend switch)

Usage (PowerShell):
  $env:HTTPS_PROXY="http://sdod3-proxy.intranet.db.com:8080"
  $env:HTTP_PROXY=$env:HTTPS_PROXY
  $env:NO_PROXY="*.db.com,localhost,127.0.0.1,10.*"
  $env:EVAL_DB_URL="postgresql://"
  $env:DB_INSTANCE_CONNECTION_NAME="db-dev-46jr-mp-cta-analytics:europe-west3:cta-db"
  $env:DB_NAME="cta-postgresql01"
  $env:DB_USER="DBAWARE_EVAL_USER";  $env:DB_PASSWORD="***"
  $env:DB_OWNER_USER="DBAWARE_EVAL_OWNER"; $env:DB_OWNER_PASSWORD="***"
  python scripts/db_smoke.py
"""

from __future__ import annotations

import datetime as _dt
import sys
from pathlib import Path

# Make src/ importable when run from the repo root.
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))


def main() -> int:
    print("== CloudSQL live smoke test ==")

    # 1) ADC visible?
    try:
        import google.auth

        creds, project = google.auth.default()
        print(f"[ok] ADC resolved: {type(creds).__name__} (project={project})")
    except Exception as exc:
        print(f"[FAIL] ADC not available: {exc}")
        print("       Run: gcloud auth application-default login (with proxy env set)")
        return 2

    # 2) Build the repository (Cloud SQL Connector).
    try:
        from eval_service.repository import build_repository

        repo = build_repository()
        print(f"[ok] repository built: {type(repo).__name__}")
    except Exception as exc:
        print(f"[FAIL] could not build repository: {exc!r}")
        return 3

    # 3) Schema init (owner role, idempotent).
    try:
        repo.init_schema()
        print("[ok] init_schema() succeeded (tables present)")
    except Exception as exc:
        print(f"[FAIL] init_schema failed: {exc!r}")
        return 4

    # 4) Write + read a throwaway label.
    try:
        from eval_service.models import HumanLabel

        marker = "smoke_" + _dt.datetime.utcnow().strftime("%Y%m%d%H%M%S")
        label = HumanLabel(
            case_id=marker,
            verdict="pass",
            score=1.0,
            labeler="db_smoke",
            note="live connection smoke test",
            run_id=None,
            created_at=_dt.datetime.utcnow().isoformat(),
        )
        repo.save_label(label)
        rows = {l.case_id for l in repo.list_labels()}
        if marker in rows:
            print(f"[ok] round-trip write/read verified (case_id={marker})")
        else:
            print("[FAIL] wrote a label but could not read it back")
            return 5
    except Exception as exc:
        print(f"[FAIL] write/read failed: {exc!r}")
        return 6

    print("\nSUCCESS — the evaluation service is live against CloudSQL.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
