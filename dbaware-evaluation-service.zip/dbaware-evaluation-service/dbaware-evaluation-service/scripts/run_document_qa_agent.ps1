# Starts the Document QA sample agent on :4013 (no Vertex / no DB needed).
# Requires python-docx for DOCX generation. PDF is generated with stdlib only.
$ErrorActionPreference = "Stop"
$root = Split-Path -Parent $PSScriptRoot
$repoRoot = Split-Path -Parent $root
$py = Join-Path $root ".venv\Scripts\python.exe"
if (-not (Test-Path $py)) { $py = Join-Path $repoRoot ".venv\Scripts\python.exe" }
if (-not (Test-Path $py)) { $py = "python" }

$env:PYTHONPATH = Join-Path $root "src"
& $py (Join-Path $root "src\sample_agents\document_qa_agent.py")
