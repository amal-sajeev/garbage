﻿"""Runnable sample LangChain agent â€” a report writer that returns Markdown.

Hostable standalone on :4011. Demonstrates the config-driven ``http`` adapter
with ``content_type: markdown`` and config-driven scorers
(``section_present``, ``contains``, ``rubric``).

    POST /api/eval/report-writer  { "topic": "..." }
    -> { "output": "# Report ...\\n## Section ...", "model": ..., "tool_calls": [...], "usage": {...} }

Run:  python src/sample_agents/report_writer_agent.py
"""

from __future__ import annotations

import time
import uvicorn
from fastapi import FastAPI
from langchain_core.runnables import RunnableLambda
from langchain_core.tools import tool
from pydantic import BaseModel, Field


@tool
def generate_section(title: str, key_points: list[str]) -> str:
    """Generate a Markdown section with a heading and bullet points."""
    lines = [f"## {title}", ""]
    for point in key_points:
        lines.append(f"- {point}")
    return "\n".join(lines)


@tool
def generate_summary(topic: str) -> str:
    """Generate an executive summary heading for a report topic."""
    return f"# {topic}\n\nThis report covers {topic}."


TOOLS = {t.name: t for t in (generate_section, generate_summary)}


_REPORTS = {
    "Q1 Financial Summary": {
        "sections": [
            ("Revenue Analysis", ["Total revenue: $10M", "Growth: 15% YoY", "Top segment: Enterprise"]),
            ("Expense Breakdown", ["Total expenses: $4M", "Operating costs: $2.5M", "Marketing: $1.5M"]),
            ("Net Income", ["Net income: $6M", "Margin: 60%", "Ahead of forecast by 8%"]),
        ],
    },
    "Risk Assessment Report": {
        "sections": [
            ("Risk Identification", ["5 risks identified", "2 high priority", "3 medium priority"]),
            ("Mitigation Plan", ["Controls mapped to each risk", "Owner assigned", "Review quarterly"]),
            ("Residual Risk", ["All high risks mitigated", "Medium risks monitored", "No critical gaps"]),
        ],
    },
    "Compliance Review": {
        "sections": [
            ("Regulatory Scope", [" Dodd-Frank Act", "MiFID II", "EMIR"],
             "The compliance scope covers three major regulatory frameworks."),
            ("Gap Analysis", ["2 gaps identified", "Remediation in progress", "ETA: Q3 2025"]),
            ("Recommendations", ["Enhance monitoring controls", "Update policies", "Staff training"]),
        ],
    },
}


def _agent_fn(payload: dict) -> dict:
    topic = payload.get("topic", "Q1 Financial Summary")
    spec = _REPORTS.get(topic, _REPORTS["Q1 Financial Summary"])

    tool_calls = []
    parts = [generate_summary.invoke({"topic": topic})]
    tool_calls.append({"name": "generate_summary", "args": {"topic": topic}, "latency_ms": 5})

    for title, points in spec["sections"]:
        section_md = generate_section.invoke({"title": title, "key_points": points})
        parts.append(section_md)
        tool_calls.append({"name": "generate_section", "args": {"title": title}, "latency_ms": 8})

    output = "\n\n".join(parts)
    in_tok = max(1, len(topic) // 4)
    out_tok = max(1, len(output) // 4)
    return {
        "output": output,
        "tool_calls": tool_calls,
        "usage": {"input_tokens": in_tok, "output_tokens": out_tok,
                  "total_tokens": in_tok + out_tok},
    }


agent_runnable = RunnableLambda(_agent_fn)

app = FastAPI(title="Sample Report Writer Agent", version="0.1.0")


class ReportRequest(BaseModel):
    topic: str = Field(default="Q1 Financial Summary", min_length=1)


@app.post("/api/eval/report-writer")
def evaluate_report(request: ReportRequest):
    started = time.perf_counter()
    result = agent_runnable.invoke({"topic": request.topic})
    return {
        "target_id": "report_writer",
        "output": result["output"],
        "tool_calls": result["tool_calls"],
        "stage_trace": [],
        "source_context": {"topic": request.topic},
        "latency_ms": int((time.perf_counter() - started) * 1000),
        "usage": result["usage"],
        "model": "report-writer-langchain-v1",
        "metadata": {"ai_confidence": 0.90},
        "error": None,
    }


@app.get("/api/health")
def health():
    return {"status": "ok", "tools": sorted(TOOLS)}


if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=4011)
