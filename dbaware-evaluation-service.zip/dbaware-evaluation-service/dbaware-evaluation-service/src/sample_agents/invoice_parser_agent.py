﻿"""Runnable sample LangChain agent â€” an invoice parser that returns structured JSON.

Hostable standalone on :4012. Demonstrates the config-driven ``http`` adapter
with ``content_type: json`` and config-driven JSON scorers
(``json_path``, ``field_match``, ``json_schema_valid``, ``rubric``).

    POST /api/eval/invoice-parser  { "invoice_text": "..." }
    -> { "invoice": { "vendor": ..., "total": ..., "items": [...] }, ... }

Run:  python src/sample_agents/invoice_parser_agent.py
"""

from __future__ import annotations

import re
import time
import uvicorn
from fastapi import FastAPI
from langchain_core.runnables import RunnableLambda
from langchain_core.tools import tool
from pydantic import BaseModel, Field


@tool
def extract_vendor(text: str) -> str:
    """Extract the vendor name from invoice text."""
    m = re.search(r"(?:From|Vendor|Supplier):\s*(.+)", text, re.I)
    return m.group(1).strip() if m else "Unknown Vendor"


@tool
def extract_total(text: str) -> float:
    """Extract the total amount from invoice text."""
    m = re.search(r"(?:Total|Amount Due|Balance Due):\s*\$?([\d,]+\.?\d*)", text, re.I)
    if m:
        return float(m.group(1).replace(",", ""))
    return 0.0


@tool
def extract_line_items(text: str) -> list[dict]:
    """Extract line items from invoice text."""
    items = []
    for m in re.finditer(r"-\s+(.+?)\s+:\s+\$?([\d,]+\.?\d*)", text):
        items.append({"description": m.group(1).strip(), "amount": float(m.group(2).replace(",", ""))})
    return items


@tool
def extract_invoice_number(text: str) -> str:
    """Extract the invoice number."""
    m = re.search(r"(?:Invoice|Inv)\s*(?:#|No\.?|Number)[:\s]*([A-Z0-9-]+)", text, re.I)
    return m.group(1) if m else "UNKNOWN"


TOOLS = {t.name: t for t in (extract_vendor, extract_total, extract_line_items, extract_invoice_number)}


_INVOICES = {
    "acme_q1": """Invoice #INV-2025-001
From: Acme Corp
Date: 2025-01-15

Line Items:
- Cloud Services : $5,000
- Support Package : $2,000
- Training : $1,000

Total: $8,000
""",
    "globex_annual": """Invoice #INV-2025-042
Vendor: Globex Industries
Date: 2025-03-20

Line Items:
- Annual License : $12,000
- Premium Support : $3,500
- Implementation : $4,500

Total: $20,000
""",
    "initech_quarterly": """Invoice No. INV-Q3-009
From: Initech Consulting
Date: 2025-07-01

Line Items:
- Audit Services : $7,500
- Risk Assessment : $3,000
- Remediation : $2,500

Amount Due: $13,000
""",
}


def _agent_fn(payload: dict) -> dict:
    invoice_key = payload.get("invoice_text", payload.get("invoice_id", "acme_q1"))
    text = _INVOICES.get(invoice_key, _INVOICES["acme_q1"]) if invoice_key in _INVOICES else invoice_key

    vendor = extract_vendor.invoke({"text": text})
    total = extract_total.invoke({"text": text})
    items = extract_line_items.invoke({"text": text})
    inv_num = extract_invoice_number.invoke({"text": text})

    invoice = {
        "vendor": vendor,
        "invoice_number": inv_num,
        "total": total,
        "currency": "USD",
        "line_items": items,
        "item_count": len(items),
    }
    tool_calls = [
        {"name": "extract_vendor", "args": {"text": text[:50]}, "latency_ms": 3},
        {"name": "extract_total", "args": {}, "latency_ms": 2},
        {"name": "extract_line_items", "args": {}, "latency_ms": 5},
        {"name": "extract_invoice_number", "args": {}, "latency_ms": 2},
    ]
    in_tok = max(1, len(text) // 4)
    out_tok = max(1, len(str(invoice)) // 4)
    return {
        "invoice": invoice,
        "tool_calls": tool_calls,
        "usage": {"input_tokens": in_tok, "output_tokens": out_tok,
                  "total_tokens": in_tok + out_tok},
    }


agent_runnable = RunnableLambda(_agent_fn)

app = FastAPI(title="Sample Invoice Parser Agent", version="0.1.0")


class InvoiceRequest(BaseModel):
    invoice_text: str = Field(default="acme_q1", min_length=1)


@app.post("/api/eval/invoice-parser")
def evaluate_invoice(request: InvoiceRequest):
    started = time.perf_counter()
    result = agent_runnable.invoke({"invoice_text": request.invoice_text})
    return {
        "target_id": "invoice_parser",
        "output": result["invoice"],
        "tool_calls": result["tool_calls"],
        "stage_trace": [],
        "source_context": {"invoice_text": request.invoice_text},
        "latency_ms": int((time.perf_counter() - started) * 1000),
        "usage": result["usage"],
        "model": "invoice-parser-langchain-v1",
        "metadata": {"ai_confidence": 0.93},
        "error": None,
    }


@app.get("/api/health")
def health():
    return {"status": "ok", "tools": sorted(TOOLS)}


if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=4012)
