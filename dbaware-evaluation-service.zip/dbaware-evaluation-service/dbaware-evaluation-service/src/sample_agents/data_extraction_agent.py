﻿"""Runnable sample langchain agent â€” a local stand-in for a hosted
data-extraction agent, so the evaluation service can be exercised end-to-end with
no Vertex credentials and no database.

It uses real LangChain primitives (`@tool` functions composed in a Runnable) but
a deterministic keyword router in place of a hosted LLM, and mirrors the
agent-service eval-hook contract:

    POST /api/eval/data-extraction-agent   { "query": "..." }
    -> the standard Observation envelope { target_id, output, tool_calls[],
       usage, latency_ms, model, metadata, error }

Run it on :4010 and point the eval service at it:
    AGENT_SERVICE_BASE_URL=http://localhost:4010  METRICS_SOURCE=capture
"""

from __future__ import annotations

import re
import time

import uvicorn
from fastapi import FastAPI
from langchain_core.runnables import RunnableLambda
from langchain_core.tools import tool
from pydantic import BaseModel, Field


# --- Tools (canned data; stand in for the MCP tool suite) --------------------

@tool
def get_application_data(assessment_unit: str, entity: str) -> str:
    """Look up AppCatalog application and process data for an assessment unit/entity."""
    return f"AppCatalog applications and processes for assessment unit {assessment_unit} under entity {entity}."


@tool
def get_financial_data(entity: str, financial_year: str) -> str:
    """Look up FinLedger financial materiality data for an entity and financial year."""
    return f"FinLedger material processes and balances for {entity} in financial year {financial_year}."


@tool
def get_control_data(risk_id: str, external_ref: str, assessment_unit: str) -> str:
    """Look up a ControlRegistry control definition by risk id and external reference."""
    return (
        f"ControlRegistry control definition for risk id {risk_id} "
        f"(external reference {external_ref}) in assessment unit {assessment_unit}."
    )


@tool
def internet_search(query: str) -> str:
    """Grounded internet search for a regulation or topic."""
    return f"Grounded internet search summary for: {query}."


TOOLS = {t.name: t for t in (
    get_application_data, get_financial_data, get_control_data, internet_search
)}


# --- Deterministic router (replaces the hosted LLM's tool choice) ------------

def _route(query: str) -> tuple[str, dict]:
    q = query.lower()
    au = _find(r"au-\d+", query, flags=re.I)
    if "finledger" in q or "financial" in q or "materiality" in q:
        entity = _entity(query)
        year = _find(r"\b20\d{2}\b", query) or ""
        return "get_financial_data", {"entity": entity, "financial_year": year}
    if "control" in q or "controlregistry" in q or _find(r"\br\d+\b", query, flags=re.I):
        risk = (_find(r"\bR\d+\b", query, flags=re.I) or "").upper()
        ext = _find(r"\d{4}_\d{2}-\d{2}", query) or ""
        au_name = _after("assessment unit", query) or _after("in assessment unit", query) or ""
        return "get_control_data", {"risk_id": risk, "external_ref": ext, "assessment_unit": au_name}
    if "search the internet" in q or "search for" in q:
        return "internet_search", {"query": _after("obligations imposed by the", query) or query}
    if "appcatalog" in q or au:
        return "get_application_data", {"assessment_unit": au or "", "entity": _entity(query)}
    return "internet_search", {"query": query}


def _find(pattern: str, text: str, flags: int = 0) -> str | None:
    m = re.search(pattern, text, flags)
    return m.group(0) if m else None


def _entity(text: str) -> str:
    for name in ("Acme Corp", "Globex", "Initech"):
        if name.lower() in text.lower():
            return name
    return ""


def _after(marker: str, text: str) -> str | None:
    idx = text.lower().find(marker.lower())
    if idx < 0:
        return None
    tail = text[idx + len(marker):].strip().strip(".")
    return tail.split(" at ")[0].split(" under ")[0].strip() or None


def _agent_fn(payload: dict) -> dict:
    query = payload["query"]
    tool_name, args = _route(query)
    tool = TOOLS[tool_name]
    output = tool.invoke(args)
    tool_calls = [{"name": tool_name, "args": args, "latency_ms": 5}]
    # Cheap deterministic token estimate so the capture service has usage data.
    in_tok = max(1, len(query) // 4)
    out_tok = max(1, len(output) // 4)
    return {
        "output": output,
        "tool_calls": tool_calls,
        "usage": {"input_tokens": in_tok, "output_tokens": out_tok,
                  "total_tokens": in_tok + out_tok},
        "confidence": round(min(1.0, 0.85 + 0.03 * len(args)), 3),
    }


# A genuine LangChain Runnable wrapping the routed tool call.
agent_runnable = RunnableLambda(_agent_fn)


# --- HTTP surface (mirrors the agent-service eval hook) ----------------------

app = FastAPI(title="Sample LangChain Agent", version="0.1.0")


class DataExtractionRequest(BaseModel):
    query: str = Field(min_length=1)


@app.post("/api/eval/data-extraction-agent")
def evaluate_data_extraction(request: DataExtractionRequest):
    started = time.perf_counter()
    result = agent_runnable.invoke({"query": request.query})
    return {
        "target_id": "data_extraction_agent",
        "output": result["output"],
        "tool_calls": result["tool_calls"],
        "stage_trace": [],
        "source_context": {"query": request.query},
        "latency_ms": int((time.perf_counter() - started) * 1000),
        "usage": result["usage"],
        "model": "sample-langchain-router",
        "metadata": {"ai_confidence": result["confidence"]},
        "error": None,
    }


@app.get("/api/health")
def health():
    return {"status": "ok", "tools": sorted(TOOLS)}


if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=4010)
