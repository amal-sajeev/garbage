﻿"""Runnable sample LangChain agent â€” a document QA agent that returns DOCX and PDF.

Hostable standalone on :4013. Demonstrates the config-driven ``http`` adapter
with ``content_type: docx`` / ``pdf`` and document-structure scorers
(``section_present``, ``docx_table_has``, ``rubric``).

    POST /api/eval/document-qa  { "document_type": "docx"|"pdf", "topic": "..." }
    -> { "document": "<base64-encoded-bytes>", "answer": "...", ... }

The DOCX is generated with python-docx (paragraphs + a table). The PDF is
generated with a minimal stdlib-only PDF writer (no extra dependency).

Run:  python src/sample_agents/document_qa_agent.py
"""

from __future__ import annotations

import base64
import io
import time
import uvicorn
from fastapi import FastAPI
from langchain_core.runnables import RunnableLambda
from langchain_core.tools import tool
from pydantic import BaseModel, Field


# --------------------------------------------------------------------------- #
# Document generation tools (LangChain @tool wrappers)
# --------------------------------------------------------------------------- #

@tool
def generate_docx(topic: str) -> str:
    """Generate a DOCX report with headings, paragraphs, and a summary table."""
    import docx  # lazy import; skip-cleanly if absent

    doc = docx.Document()
    doc.add_heading(f"{topic} Report", level=0)

    doc.add_heading("Executive Summary", level=1)
    doc.add_paragraph(f"This document presents the {topic} findings and recommendations.")

    doc.add_heading("Key Findings", level=1)
    doc.add_paragraph("The analysis identified three primary areas of concern.")

    doc.add_heading("Detailed Analysis", level=1)
    doc.add_paragraph("Finding 1: Revenue exceeded expectations by 12%.")
    doc.add_paragraph("Finding 2: Operating costs were 8% below budget.")
    doc.add_paragraph("Finding 3: Customer satisfaction improved by 15 points.")

    doc.add_heading("Recommendations", level=1)
    doc.add_paragraph("1. Increase investment in high-performing segments.")
    doc.add_paragraph("2. Review cost allocation across business units.")

    doc.add_heading("Summary Table", level=1)
    table = doc.add_table(rows=4, cols=3)
    table.style = "Table Grid"
    headers = table.rows[0].cells
    headers[0].text = "Metric"
    headers[1].text = "Value"
    headers[2].text = "Status"
    data = [
        ("Revenue", "$10M", "Above target"),
        ("Expenses", "$4M", "Below budget"),
        ("Net Income", "$6M", "On track"),
    ]
    for i, (m, v, s) in enumerate(data, 1):
        cells = table.rows[i].cells
        cells[0].text = m
        cells[1].text = v
        cells[2].text = s

    buf = io.BytesIO()
    doc.save(buf)
    return base64.b64encode(buf.getvalue()).decode("ascii")


@tool
def generate_pdf(topic: str) -> str:
    """Generate a minimal PDF report (stdlib-only, no extra dependency)."""
    text_lines = [
        f"{topic} Report",
        "",
        "Executive Summary",
        f"This document presents the {topic} findings.",
        "",
        "Key Findings",
        "Revenue exceeded expectations by 12%.",
        "Operating costs were 8% below budget.",
        "Customer satisfaction improved by 15 points.",
        "",
        "Recommendations",
        "Increase investment in high-performing segments.",
        "Review cost allocation across business units.",
    ]
    pdf_bytes = _build_pdf(text_lines)
    return base64.b64encode(pdf_bytes).decode("ascii")


def _build_pdf(text_lines: list[str]) -> bytes:
    """Build a minimal valid PDF with text (stdlib only)."""
    content_parts = ["BT", "/F1 12 Tf", "72 750 Td"]
    for i, line in enumerate(text_lines):
        if i > 0:
            content_parts.append("0 -18 Td")
        escaped = line.replace("(", r"\(").replace(")", r"\)")
        content_parts.append(f"({escaped}) Tj")
    content_parts.append("ET")
    content = "\n".join(content_parts).encode("latin-1")

    objects = [
        b"<< /Type /Catalog /Pages 2 0 R >>",
        b"<< /Type /Pages /Kids [3 0 R] /Count 1 >>",
        b"<< /Type /Page /MediaBox [0 0 612 792] /Parent 2 0 R /Resources << /Font << /F1 4 0 R >> >> /Contents 5 0 R >>",
        b"<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>",
        f"<< /Length {len(content)} >>".encode("latin-1") + b"\nstream\n" + content + b"\nendstream",
    ]

    pdf = b"%PDF-1.4\n"
    offsets = []
    for i, obj in enumerate(objects, 1):
        offsets.append(len(pdf))
        pdf += f"{i} 0 obj\n".encode("latin-1") + obj + b"\nendobj\n"

    xref_offset = len(pdf)
    pdf += f"xref\n0 {len(objects) + 1}\n".encode("latin-1")
    pdf += b"0000000000 65535 f \n"
    for offset in offsets:
        pdf += f"{offset:010d} 00000 n \n".encode("latin-1")

    pdf += (
        f"trailer\n<< /Size {len(objects) + 1} /Root 1 0 R >>\n"
        f"startxref\n{xref_offset}\n%%EOF"
    ).encode("latin-1")
    return pdf


TOOLS = {t.name: t for t in (generate_docx, generate_pdf)}


_TOPICS = {
    "Risk Assessment": "Risk Assessment",
    "Q1 Financial Summary": "Q1 Financial Summary",
    "Compliance Review": "Compliance Review",
}


def _agent_fn(payload: dict) -> dict:
    doc_type = payload.get("document_type", "docx")
    topic = payload.get("topic", "Risk Assessment")

    if doc_type == "pdf":
        document_b64 = generate_pdf.invoke({"topic": topic})
        tool_name = "generate_pdf"
    else:
        document_b64 = generate_docx.invoke({"topic": topic})
        tool_name = "generate_docx"

    answer = f"Generated a {doc_type.upper()} report for {topic}."
    tool_calls = [{"name": tool_name, "args": {"topic": topic}, "latency_ms": 50}]
    in_tok = max(1, len(topic) // 4)
    out_tok = max(1, len(document_b64) // 4)
    return {
        "document": document_b64,
        "answer": answer,
        "document_type": doc_type,
        "tool_calls": tool_calls,
        "usage": {"input_tokens": in_tok, "output_tokens": out_tok,
                  "total_tokens": in_tok + out_tok},
    }


agent_runnable = RunnableLambda(_agent_fn)

app = FastAPI(title="Sample Document QA Agent", version="0.1.0")


class DocumentQARequest(BaseModel):
    document_type: str = Field(default="docx")
    topic: str = Field(default="Risk Assessment", min_length=1)


@app.post("/api/eval/document-qa")
def evaluate_document(request: DocumentQARequest):
    started = time.perf_counter()
    result = agent_runnable.invoke({"document_type": request.document_type, "topic": request.topic})
    return {
        "target_id": "document_qa",
        "output": result["document"],
        "answer": result["answer"],
        "tool_calls": result["tool_calls"],
        "stage_trace": [],
        "source_context": {"document_type": request.document_type, "topic": request.topic},
        "latency_ms": int((time.perf_counter() - started) * 1000),
        "usage": result["usage"],
        "model": "document-qa-langchain-v1",
        "metadata": {"ai_confidence": 0.88, "document_type": request.document_type},
        "error": None,
    }


@app.get("/api/health")
def health():
    return {"status": "ok", "tools": sorted(TOOLS)}


if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=4013)
