"""Evaluation Runner: orchestrates one evaluation run.

For each golden case: replay input against the target, fetch metrics, run each
metric's scorer, apply the per-metric threshold, then aggregate the weighted
score, weighted delta, and gate. Persists a RunRecord.

Case-level concurrency is controlled by ``EVAL_CASE_CONCURRENCY`` (default 1 =
serial, preserving the original event ordering). When >1, multiple cases are
processed in parallel; events carry ``case_id`` so the frontend can sort them.
The judge semaphore (``EVAL_JUDGE_CONCURRENCY``) is global across all cases so
the total concurrent Vertex calls stay bounded.
"""

from __future__ import annotations

import asyncio
import uuid
from datetime import datetime, UTC
from typing import Any
from collections.abc import Awaitable, Callable

from . import aggregation
from .adapters import build_metrics_client, build_target_adapter
from .config import Config
from .labels import label_store
from .structured_logging import get_logger
from .models import CaseResult, RunRecord, Score
from .registry import RegisteredAgent, Registry
from .repository import EvaluationRepository
from .scorers import get_scorer
from .scorers.base import MetricSkipped
from .scorers.llm_judge import reset_cache as reset_judge_cache

ProgressFn = Callable[[dict[str, Any]], Awaitable[None]]
_log = get_logger("eval_service.runner")

_JUDGE_SCORERS = {
    "faithfulness", "relevance", "completeness", "coherence", "conciseness",
    "instruction_following", "pairwise_vs_golden", "groundedness",
    "embedding_similarity", "rubric", "rubric_multi",
}


class Runner:
    def __init__(self, registry: Registry, repo: EvaluationRepository):
        self._registry = registry
        self._repo = repo

    async def evaluate(
        self,
        agent_id: str,
        dataset_version: str | None = None,
        judge_repetitions: int = 1,
        progress: ProgressFn | None = None,
    ) -> RunRecord:
        trace_id = uuid.uuid4().hex
        log = _log

        async def emit(event: dict[str, Any]) -> None:
            if progress is not None:
                await progress(event)

        agent: RegisteredAgent = self._registry.get(agent_id)
        dataset = agent.dataset
        if dataset_version and dataset_version != dataset.version:
            raise ValueError(
                f"Dataset version '{dataset_version}' not loaded for '{agent_id}' "
                f"(current: '{dataset.version}')."
            )

        target = build_target_adapter(dataset, agent.config.base_url)
        metrics_client = build_metrics_client(
            agent.metrics_stub_path,
            source_override=agent.config.metrics_source,
        )

        reset_judge_cache()

        total_cases = len(dataset.cases)
        log.info("run_started", extra={"trace_id": trace_id, "agent_id": agent_id,
                                       "dataset_id": dataset.dataset_id, "cases": total_cases})
        await emit({
            "type": "run_started",
            "agent_id": agent_id,
            "dataset_id": dataset.dataset_id,
            "dataset_version": dataset.version,
            "total_cases": total_cases,
            "concurrency": Config.JUDGE_CONCURRENCY,
            "case_concurrency": Config.CASE_CONCURRENCY,
            "judge_repetitions": judge_repetitions,
            "metrics": [
                {
                    "name": m.name,
                    "type": m.type,
                    "weight": m.weight,
                    "threshold": m.threshold,
                    "critical": m.critical,
                    "judge": m.scorer in _JUDGE_SCORERS,
                }
                for m in dataset.metrics
            ],
        })

        # Global judge semaphore — bounded across ALL cases, not per-case.
        judge_sem = asyncio.Semaphore(Config.JUDGE_CONCURRENCY)
        case_sem = asyncio.Semaphore(Config.CASE_CONCURRENCY)
        case_results: list[CaseResult | None] = [None] * total_cases

        async def process_case(index: int, case) -> None:
            async with case_sem:
                await emit({
                    "type": "case_started",
                    "case_id": case.id,
                    "index": index,
                    "total": total_cases,
                    "metric_count": len(dataset.metrics),
                })
                log.info("case_started", extra={"trace_id": trace_id,
                                                 "agent_id": agent_id, "case_id": case.id})

                observation = await target.run_case(case)
                metrics = await metrics_client.fetch(case.id, observation)

                if observation.error:
                    log.warning("observation_error", extra={
                        "trace_id": trace_id, "case_id": case.id, "error": observation.error})

                output_preview = observation.output
                if isinstance(output_preview, dict):
                    try:
                        parts = []
                        for key, rep in output_preview.items():
                            if isinstance(rep, dict) and ("paragraphs" in rep or "report_title" in rep):
                                title = rep.get("report_title") or key
                                n = len(rep.get("paragraphs") or [])
                                parts.append(f"{title} ({n} paragraphs)")
                        if parts:
                            output_preview = " · ".join(parts)
                        else:
                            import json as _json
                            output_preview = _json.dumps(output_preview, ensure_ascii=False, default=str)
                    except Exception:
                        output_preview = str(output_preview)
                elif not isinstance(output_preview, str):
                    try:
                        import json as _json
                        output_preview = _json.dumps(output_preview, ensure_ascii=False, default=str)
                    except Exception:
                        output_preview = str(output_preview)
                if len(output_preview) > 600:
                    output_preview = output_preview[:600] + "…"
                await emit({
                    "type": "observation",
                    "case_id": case.id,
                    "latency_ms": observation.latency_ms,
                    "model": observation.model,
                    "tool_calls": len(observation.tool_calls),
                    "error": observation.error,
                    "output_preview": output_preview,
                })

                async def score_one(spec, *, _case=case, _obs=observation, _metrics=metrics):
                    fn = get_scorer(spec.scorer)
                    await emit({
                        "type": "metric_started",
                        "case_id": _case.id,
                        "metric": spec.name,
                        "judge": spec.scorer in _JUDGE_SCORERS,
                    })
                    async with judge_sem:
                        try:
                            result = await asyncio.to_thread(
                                fn,
                                observation=_obs,
                                case=_case,
                                metrics=_metrics,
                                metric_name=spec.name,
                                spec=spec,
                                judge_repetitions=judge_repetitions,
                            )
                        except MetricSkipped as skip:
                            await emit({
                                "type": "metric_skipped",
                                "case_id": _case.id,
                                "metric": spec.name,
                                "reason": str(skip),
                            })
                            return None

                    raw, rationale, evidence = result[0], result[1], result[2]
                    extras = result[3] if len(result) > 3 else {}
                    raw_value = extras.get("raw_value", raw)

                    quality = aggregation.normalise(raw, spec)
                    baseline = self._resolve_baseline(agent_id, dataset.version, spec.name, _case)
                    score = Score(
                        metric=spec.name,
                        score=quality,
                        passed=quality >= spec.threshold,
                        threshold=spec.threshold,
                        weight=spec.weight,
                        baseline=baseline,
                        delta=(quality - baseline) if baseline is not None else None,
                        rationale=rationale,
                        evidence=evidence,
                        critical=spec.critical,
                        raw_value=raw_value,
                        variance=extras.get("variance"),
                        unstable=bool(extras.get("unstable", False)),
                        unit=spec.unit,
                    )
                    await emit({
                        "type": "metric_done",
                        "case_id": _case.id,
                        "metric": score.metric,
                        "score": score.score,
                        "passed": score.passed,
                        "threshold": score.threshold,
                        "weight": score.weight,
                        "critical": score.critical,
                        "delta": score.delta,
                        "variance": score.variance,
                        "unstable": score.unstable,
                        "raw_value": score.raw_value,
                        "unit": score.unit,
                        "rationale": score.rationale,
                        "evidence": score.evidence,
                        "judge": spec.scorer in _JUDGE_SCORERS,
                    })
                    return score

                gathered = await asyncio.gather(*(score_one(spec) for spec in dataset.metrics))
                scores: list[Score] = [s for s in gathered if s is not None]

                passed, wscore, wdelta = aggregation.gate(scores)
                case_results[index] = CaseResult(
                    case_id=case.id,
                    scores=scores,
                    weighted_score=wscore,
                    weighted_delta=wdelta,
                    passed=passed,
                    observation=observation,
                    input=case.input,
                    golden_output=case.golden_output,
                )
                log.info("case_done", extra={
                    "trace_id": trace_id, "case_id": case.id,
                    "passed": passed, "score": round(wscore, 3)})
                await emit({
                    "type": "case_done",
                    "case_id": case.id,
                    "index": index,
                    "total": total_cases,
                    "passed": passed,
                    "weighted_score": wscore,
                    "weighted_delta": wdelta,
                })

        # Process all cases (serial when CASE_CONCURRENCY=1, parallel when >1).
        await asyncio.gather(
            *(process_case(i, c) for i, c in enumerate(dataset.cases))
        )

        # case_results is in index order; replace any None (shouldn't happen).
        final_results: list[CaseResult] = [r for r in case_results if r is not None]

        run = self._build_run(agent_id, dataset, final_results)
        self._repo.save_run(run)
        log.info("run_done", extra={
            "trace_id": trace_id, "run_id": run.run_id,
            "passed": run.passed, "score": round(run.weighted_score, 3)})
        await emit({
            "type": "run_done",
            "run_id": run.run_id,
            "passed": run.passed,
            "weighted_score": run.weighted_score,
            "weighted_delta": run.weighted_delta,
        })
        return run

    def _resolve_baseline(self, agent_id, version, metric, case):
        """Prefer a stored blessed baseline, else the case's baseline_metrics."""
        stored = self._repo.get_baseline(agent_id, version, metric)
        if stored is not None:
            return stored
        return case.baseline_metrics.get(metric)

    def _build_run(self, agent_id, dataset, case_results) -> RunRecord:
        n = len(case_results) or 1
        run_score = sum(c.weighted_score for c in case_results) / n
        run_delta = sum(c.weighted_delta for c in case_results) / n
        run_passed = all(c.passed for c in case_results) if case_results else False
        stats = aggregation.run_statistics(case_results, label_store.verdict_map())
        return RunRecord(
            run_id=uuid.uuid4().hex,
            agent_id=agent_id,
            dataset_id=dataset.dataset_id,
            dataset_version=dataset.version,
            weighted_score=run_score,
            weighted_delta=run_delta,
            passed=run_passed,
            created_at=datetime.now(UTC).isoformat(),
            case_results=case_results,
            stats=stats,
        )
