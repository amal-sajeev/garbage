"""Central configuration for the CTNA Evaluation Service.

Mirrors the Vertex/env conventions in docs/VERTEX_INTEGRATION.md: the code path
that reaches Vertex uses PROJECT_NAME / PROJECT_LOCATION, and `project=` is the
switch that selects the Vertex backend.
"""

from __future__ import annotations

import os
from pathlib import Path

from dotenv import load_dotenv

load_dotenv()

_no_proxy = "localhost,127.0.0.1,::1"
os.environ.setdefault("no_proxy", _no_proxy)
os.environ.setdefault("NO_PROXY", _no_proxy)

_SRC = Path(__file__).resolve().parent.parent
_ROOT = _SRC.parent


class Config:
    PROJECT_NAME = os.getenv("PROJECT_NAME")
    PROJECT_LOCATION = os.getenv("PROJECT_LOCATION", "us-central1")
    JUDGE_MODEL = os.getenv("EVAL_JUDGE_MODEL", "gemini-2.5-pro")
    JUDGE_TEMPERATURE = float(os.getenv("EVAL_JUDGE_TEMPERATURE", "0"))
    JUDGE_MAX_RETRIES = int(os.getenv("EVAL_JUDGE_MAX_RETRIES", "2"))

    PORT = int(os.getenv("EVAL_SERVICE_PORT", "4002"))
    DB_URL = os.getenv("EVAL_DB_URL", f"sqlite:///{(_ROOT / 'eval_service.db').as_posix()}")

    DB_INSTANCE_CONNECTION_NAME = os.getenv(
        "DB_INSTANCE_CONNECTION_NAME", ""
    )
    DB_NAME = os.getenv("DB_NAME", "evaldb")
    DB_SCHEMA = os.getenv("DB_SCHEMA", "public")
    DB_IP_TYPE = os.getenv("DB_IP_TYPE", "PUBLIC")
    DB_HOST = os.getenv("DB_HOST", "")
    DB_PORT = int(os.getenv("DB_PORT", "5432"))
    DB_USER = os.getenv("DB_USER", "eval_user")
    DB_PASSWORD = os.getenv("DB_PASSWORD")
    DB_PASSWORD_SECRET = os.getenv("DB_PASSWORD_SECRET")
    DB_OWNER_USER = os.getenv("DB_OWNER_USER", "eval_owner")
    DB_OWNER_PASSWORD = os.getenv("DB_OWNER_PASSWORD")
    DB_OWNER_PASSWORD_SECRET = os.getenv("DB_OWNER_PASSWORD_SECRET")

    @staticmethod
    def resolve_secret(direct: str | None, secret_name: str | None) -> str | None:
        if direct:
            return direct
        if not secret_name:
            return None
        from google.cloud import secretmanager

        client = secretmanager.SecretManagerServiceClient()
        return client.access_secret_version(name=secret_name).payload.data.decode("utf-8")

    AGENT_SERVICE_BASE_URL = os.getenv("AGENT_SERVICE_BASE_URL", "http://localhost:4000")
    METRICS_API_BASE = os.getenv("METRICS_API_BASE") or None
    METRICS_SOURCE = os.getenv("METRICS_SOURCE", "stub")

    AGENTS_DIR = _SRC / "agents"
    STATIC_DIR = _SRC / "eval_service" / "static"

    REGRESSION_TOLERANCE = float(os.getenv("EVAL_REGRESSION_TOLERANCE", "0.05"))
    DATASET_THRESHOLD = float(os.getenv("EVAL_DATASET_THRESHOLD", "0.8"))

    JUDGE_SAMPLES = int(os.getenv("EVAL_JUDGE_SAMPLES", "1"))
    EMBEDDING_MODEL = os.getenv("EVAL_EMBEDDING_MODEL", "text-embedding-004")

    JUDGE_CONCURRENCY = max(1, int(os.getenv("EVAL_JUDGE_CONCURRENCY", "6")))

    # How many golden cases to process in parallel. 1 = serial (old behaviour).
    # Increase to parallelise agent HTTP calls + scoring across cases.
    CASE_CONCURRENCY = max(1, int(os.getenv("EVAL_CASE_CONCURRENCY", "1")))

    JUDGE_TRANSIENT_RETRIES = max(1, int(os.getenv("EVAL_JUDGE_TRANSIENT_RETRIES", "4")))

    JUDGE_MAX_VARIANCE = float(os.getenv("EVAL_JUDGE_MAX_VARIANCE", "0.05"))
    JUDGE_SWAP_ORDER = os.getenv("EVAL_JUDGE_SWAP_ORDER", "1") not in ("0", "false", "False")

    # Run retention: delete runs older than this many days on startup. 0 = keep forever.
    RUN_RETENTION_DAYS = int(os.getenv("EVAL_RUN_RETENTION_DAYS", "0"))

    # Webhook callback timeout (seconds) for async evaluate.
    WEBHOOK_TIMEOUT = float(os.getenv("EVAL_WEBHOOK_TIMEOUT", "30"))
