"""Structured logging with per-run trace IDs.

Every evaluation run gets a trace_id (the run_id). All log messages emitted
during that run — agent calls, judge calls, scorer results, errors — carry
the same trace_id so they can be correlated in the log output.

Usage:
    from .structured_logging import get_logger
    log = get_logger(__name__)
    log.info("case_started", extra={"trace_id": run_id, "case_id": case_id})

The logger is configured once at import time with a structured formatter that
outputs JSON lines to stderr, so logs are easy to grep and pipe to a log
aggregator.
"""

from __future__ import annotations

import json
import logging
import sys
from datetime import datetime, UTC

_CONFIGURED = False


class StructuredFormatter(logging.Formatter):
    """Emit log records as JSON lines: timestamp, level, logger, message, + extras."""

    def format(self, record: logging.LogRecord) -> str:
        payload: dict[str, object] = {
            "ts": datetime.now(UTC).isoformat(),
            "level": record.levelname,
            "logger": record.name,
            "msg": record.getMessage(),
        }
        # Pull in extra fields the caller attached.
        for key in ("trace_id", "agent_id", "case_id", "metric", "run_id", "error_type"):
            val = getattr(record, key, None)
            if val is not None:
                payload[key] = val
        if record.exc_info:
            payload["exception"] = self.formatException(record.exc_info)
        return json.dumps(payload, default=str, ensure_ascii=False)


def _configure_logging() -> None:
    global _CONFIGURED
    if _CONFIGURED:
        return
    handler = logging.StreamHandler(sys.stderr)
    handler.setFormatter(StructuredFormatter())
    root = logging.getLogger("eval_service")
    root.addHandler(handler)
    root.setLevel(logging.INFO)
    _CONFIGURED = True


def get_logger(name: str = "eval_service") -> logging.Logger:
    _configure_logging()
    return logging.getLogger(name)
