"""Pydantic models shared across the evaluation service."""

from __future__ import annotations

from typing import Any

from pydantic import BaseModel, Field


# --- Golden set / registry ---------------------------------------------------

class MetricSpec(BaseModel):
    name: str
    type: str = Field(description="'deterministic' | 'llm_judge' | 'reference' | 'trajectory' | 'safety' | 'operational'")
    scorer: str = Field(description="registered scorer name")
    weight: float = 1.0
    threshold: float = 0.0
    # Banking-grade controls.
    critical: bool = Field(
        default=False,
        description="If true, a failure vetoes the whole run regardless of the weighted score.",
    )
    direction: str = Field(
        default="higher_is_better",
        description="'higher_is_better' or 'lower_is_better' (e.g. latency, cost, error rate).",
    )
    unit: str = Field(default="ratio", description="ratio | ms | tokens | count | usd ...")
    # Normalisation bound for unbounded 'lower_is_better' metrics: value at/above
    # `norm_max` scores 0, at/below `norm_min` scores 1 (linear in between).
    norm_min: float | None = None
    norm_max: float | None = None
    # Optional config passed through to the scorer (rubric text, schema, budgets).
    config: dict[str, Any] = Field(default_factory=dict)


class TargetSpec(BaseModel):
    """How to reach the agent under test.

    Two families:
    - Python adapters selected by ``adapter`` (``agent_eval_hook``,
      ``scoping_analytics``) — kept for backward compatibility.
    - The config-driven ``http`` adapter: the fields below describe the HTTP
      request and response mapping entirely from config, so an engineer can
      wire up a call to any agent service without writing Python.
    """

    adapter: str = "agent_eval_hook"
    endpoint: str = "/api/eval/data-extraction-agent"

    # --- Config-driven HTTP adapter (adapter == "http") ---
    method: str = "POST"
    # Static or env-templated headers, e.g. {"Authorization": "Bearer ${env.TOKEN}"}.
    headers: dict[str, str] = Field(default_factory=dict)
    # Auth helper — secrets come from env only, never committed in config.
    # {type: bearer|basic|api_key_header|api_key_query, token_env: "MY_TOKEN",
    #  header?: "X-API-Key", username_env?: ..., password_env?: ...}
    auth: dict[str, str] | None = None
    # Query-param templates resolved from case.input dotted paths, e.g. {"q": "${input.query}"}.
    params: dict[str, str] = Field(default_factory=dict)
    # Body template (Jinja-free ${...} substitution from case.input/env); absent =>
    # send case.input verbatim as JSON (backward-compatible default).
    body: Any = None
    # Body type: "json" (default), "form", "text", or "raw"
    body_type: str = "json"
    # Response mapping - dotted paths into the JSON response (or raw response).
    response: "ResponseMapping" = Field(default_factory=lambda: ResponseMapping())

    # Per-adapter overrides (also honoured by the Python adapters when set).
    timeout: float | None = None
    # trust_env=False keeps localhost calls off the corporate proxy (default).
    trust_env: bool = False
    retries: int = 0


class ResponseMapping(BaseModel):
    """Maps an HTTP response into the standard Observation envelope.

    Each ``*_path`` is a dotted path into the parsed JSON body (e.g.
    ``"data.output"``). ``None`` means "not mapped"; the Observation keeps its
    default for that field. ``content_type`` and ``output_kind`` tell the
    document-extraction layer how to interpret ``output_path``.
    """

    output_path: str | None = None
    tool_calls_path: str | None = None
    usage_path: str | None = None
    model_path: str | None = None
    latency_path: str | None = None
    error_path: str | None = None
    metadata_path: str | None = None
    # Content type: "auto" (detect), "text", "json", "markdown", "pdf", or "docx"
    content_type: str = "auto"
    # Output kind: "text" (default), "json", "base64", "bytes", or "url"
    output_kind: str = "text"


# Forward-reference resolution for the nested ResponseMapping on TargetSpec.
TargetSpec.model_rebuild()


class GoldenCase(BaseModel):
    id: str
    input: dict[str, Any]
    golden_output: str | None = None
    # Optional document golden reference: a path relative to the agent folder,
    # or a base64 data URL ("data:<ctype>;base64,..."). Enables document-aware
    # reference scorers without pasting large documents into the JSON.
    golden_file: str | None = None
    # Optional hint for how the agent output should be interpreted.
    # auto | text | json | markdown | pdf | docx
    content_type: str = "auto"
    expected: dict[str, Any] = Field(default_factory=dict)
    baseline_metrics: dict[str, float] = Field(default_factory=dict)


class Dataset(BaseModel):
    dataset_id: str
    version: str
    description: str = ""
    target: TargetSpec = Field(default_factory=TargetSpec)
    metrics: list[MetricSpec] = Field(default_factory=list)
    cases: list[GoldenCase] = Field(default_factory=list)


class AgentConfig(BaseModel):
    agent_id: str
    name: str
    base_url: str | None = None
    dataset_file: str = "dataset.json"
    metrics_stub_file: str = "metrics_stub.json"
    # Per-agent override for the metrics source. If set, takes precedence over
    # the global METRICS_SOURCE env var. Values: capture | http | stub.
    metrics_source: str | None = None


# --- Observations / scores ---------------------------------------------------

class Observation(BaseModel):
    target_id: str
    output: Any = None
    tool_calls: list[dict[str, Any]] = Field(default_factory=list)
    stage_trace: list[dict[str, Any]] = Field(default_factory=list)
    source_context: Any = None
    latency_ms: int = 0
    usage: dict[str, int] = Field(default_factory=dict)
    model: str | None = None
    metadata: dict[str, Any] = Field(default_factory=dict)
    error: str | None = None


class Score(BaseModel):
    metric: str
    score: float
    passed: bool
    threshold: float
    weight: float
    baseline: float | None = None
    delta: float | None = None
    rationale: str = ""
    evidence: list[str] = Field(default_factory=list)
    # Banking-grade audit + gating metadata.
    critical: bool = False
    raw_value: float | None = Field(
        default=None,
        description="Pre-normalisation measurement (e.g. latency ms, token count).",
    )
    variance: float | None = Field(
        default=None,
        description="Sample variance across judge repetitions (self-consistency).",
    )
    unstable: bool = Field(
        default=False,
        description="Judge self-consistency variance exceeded EVAL_JUDGE_MAX_VARIANCE.",
    )
    unit: str = "ratio"


class CaseResult(BaseModel):
    case_id: str
    scores: list[Score]
    weighted_score: float
    weighted_delta: float
    passed: bool
    observation: Observation
    # Self-contained review context so a run's detail page can show a
    # golden-vs-agent diff without re-loading the (possibly since-changed)
    # dataset: the case input and the ideal reference answer.
    input: dict[str, Any] = Field(default_factory=dict)
    golden_output: str | None = None


class RunStats(BaseModel):
    """Dataset-level statistical rigor computed across all cases in a run.

    Confidence intervals and the drift test use a normal (z) approximation so
    the service stays dependency-free; for small n treat them as indicative and
    apply a Student-t correction when a stats backend is available.
    """
    n_cases: int = 0
    pass_rate: float = 0.0
    mean_score: float = 0.0
    score_stdev: float = 0.0
    # 95% confidence interval on the mean weighted score (z-approx).
    ci95_low: float = 0.0
    ci95_high: float = 0.0
    # Drift vs baseline: mean per-case weighted delta + a two-sided z-test that
    # the mean delta differs from zero. `drift_significant` flags a *regression*
    # (mean_delta < 0 and p < 0.05) — a statistically real drop, not noise.
    mean_delta: float = 0.0
    drift_p_value: float | None = None
    drift_significant: bool = False
    # Judge-vs-human calibration (populated only when human labels exist for the
    # run's cases). Prediction = the gate's per-case pass/fail; truth = label.
    labeled_cases: int = 0
    precision: float | None = None
    recall: float | None = None
    f1: float | None = None
    cohens_kappa: float | None = None


class RunRecord(BaseModel):
    run_id: str
    agent_id: str
    dataset_id: str
    dataset_version: str
    weighted_score: float
    weighted_delta: float
    passed: bool
    created_at: str
    case_results: list[CaseResult] = Field(default_factory=list)
    stats: RunStats | None = None


# --- Human-in-the-loop labels ------------------------------------------------

class HumanLabel(BaseModel):
    """An expert verdict on a case, used to calibrate the automated gate/judge."""
    case_id: str
    verdict: str = Field(description="'pass' or 'fail' — the ground-truth acceptability")
    score: float | None = Field(default=None, description="Optional human quality score 0..1")
    labeler: str = "anonymous"
    note: str = ""
    run_id: str | None = None
    created_at: str = ""


# --- API request bodies ------------------------------------------------------

class EvaluateRequest(BaseModel):
    agent_id: str
    dataset_version: str | None = None
    judge_repetitions: int = Field(default=1, ge=1, le=5)


class LabelRequest(BaseModel):
    case_id: str
    verdict: str = Field(pattern="^(pass|fail)$")
    score: float | None = Field(default=None, ge=0.0, le=1.0)
    labeler: str = "anonymous"
    note: str = ""
    run_id: str | None = None


class AsyncEvaluateRequest(BaseModel):
    agent_id: str
    dataset_version: str | None = None
    judge_repetitions: int = Field(default=1, ge=1, le=5)
    webhook_url: str | None = None


class ABCompareRequest(BaseModel):
    agent_a: str
    agent_b: str
    dataset_version: str | None = None
    judge_repetitions: int = Field(default=1, ge=1, le=5)
