"""Render an agent Observation.output to readable prose for LLM judges.

Agents may return a plain string or a structured bundle. The scoping agent
returns `{ <report>: { report_title, paragraphs: [{ content, ... }] } }`. Judges
must see the same *prose* the golden reference is written in — not a raw JSON
dump — otherwise they compare across formats and, worse, invent format
"instructions" (e.g. "output must be valid JSON") that were never requested and
reward the agent for them. This mirrors the frontend `reportBundleToProse` so
the human diff view and the judge see identical text.
"""

from __future__ import annotations

import json
from typing import Any


def _paragraph_text(report: Any) -> str | None:
    paras = report.get("paragraphs") if isinstance(report, dict) else None
    if not isinstance(paras, list):
        return None
    parts = []
    for p in paras:
        if isinstance(p, dict):
            val = p.get("content", p.get("text", p.get("paragraph", "")))
        else:
            val = p
        if val is not None and str(val).strip():
            parts.append(str(val))
    return "\n\n".join(parts)


def _report_bundle_to_prose(value: Any) -> str:
    """Return prose for a report bundle/single report, else '' to fall back."""
    if not isinstance(value, dict):
        return ""

    # Single report: { report_title, paragraphs: [...] }.
    if isinstance(value.get("paragraphs"), list):
        body = _paragraph_text(value)
        if body is None:
            return ""
        title = value.get("report_title") or ""
        return (f"{title}\n\n{body}") if title else body

    # Bundle: { <key>: { report_title, paragraphs }, ... }.
    sections = []
    for key, rep in value.items():
        if isinstance(rep, dict) and isinstance(rep.get("paragraphs"), list):
            body = _paragraph_text(rep)
            if body is None:
                continue
            title = rep.get("report_title") or key
            sections.append(f"{title}\n\n{body}")
    return "\n\n\n".join(sections) if sections else ""


def render_output_text(value: Any) -> str:
    """Flatten any agent output to prose; JSON-serialise unrecognised shapes.

    The config-driven HTTP adapter pre-extracts document text (PDF/DOCX) and
    stores it as a string in ``observation.output``, so most calls receive text
    already. As a fallback for raw bytes (e.g. a Python adapter returning bytes),
    we attempt on-the-fly text extraction.
    """
    if value is None:
        return ""
    if isinstance(value, (bytes, bytearray)):
        from .adapters.documents import extract_text

        return extract_text(bytes(value), "auto")
    if isinstance(value, str):
        return value
    prose = _report_bundle_to_prose(value)
    if prose:
        return prose
    return json.dumps(value, ensure_ascii=False, default=str)
