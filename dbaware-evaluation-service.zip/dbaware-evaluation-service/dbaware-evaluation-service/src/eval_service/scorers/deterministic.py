"""Built-in deterministic (objective) scorers.

Each takes keyword args: observation (Observation), case (GoldenCase),
metrics (dict from the metrics API for this case). Returns (score, rationale,
evidence). Mirrors the semantics of the reference eval harness.
"""

from __future__ import annotations

import json
import re

from .base import scorer


def _output_text(observation) -> str:
    out = observation.output
    if isinstance(out, str):
        return out
    return json.dumps(out, ensure_ascii=False, default=str)


def _norm(text: str) -> str:
    return re.sub(r"[*_`#]", "", text).lower()


@scorer("tool_selection")
def tool_selection(*, observation, case, metrics=None, **_) -> tuple[float, str, list[str]]:
    """Did the agent call the expected tool and pass through expected values?"""
    expected_tool = case.expected.get("expected_tool", "")
    expected_values = case.expected.get("expected_values", [])
    called = {tc.get("name", "") for tc in observation.tool_calls}
    args_blob = json.dumps(observation.tool_calls, ensure_ascii=False, default=str).lower()

    checks: list[bool] = [expected_tool in called]
    evidence = [f"called tools: {sorted(called)}", f"expected tool: {expected_tool}"]
    for value in expected_values:
        hit = str(value).lower() in args_blob
        checks.append(hit)
        evidence.append(f"{'✓' if hit else '✗'} value '{value}'")

    score = sum(checks) / len(checks) if checks else 0.0
    return score, f"{sum(checks)}/{len(checks)} tool-selection checks passed", evidence


@scorer("assertions")
def assertions(*, observation, case, metrics=None, **_) -> tuple[float, str, list[str]]:
    """Verbatim present/absent assertions from case.expected.spot_checks."""
    text = _norm(_output_text(observation))
    checks = case.expected.get("spot_checks", [])
    if not checks:
        return 1.0, "no assertions defined", []

    passed = 0
    evidence: list[str] = []
    for chk in checks:
        want_present = chk.get("expect", "present") == "present"
        terms = chk.get("all_of") or chk.get("any_of") or []
        terms_l = [str(t).lower() for t in terms]
        if chk.get("all_of"):
            found = all(t in text for t in terms_l)
        else:
            found = any(t in text for t in terms_l)
        ok = found if want_present else not found
        passed += int(ok)
        evidence.append(f"{'✓' if ok else '✗'} {chk.get('id', '?')}")

    return passed / len(checks), f"{passed}/{len(checks)} assertions passed", evidence


@scorer("metric_threshold")
def metric_threshold(*, observation, case, metrics=None, metric_name=None, **_):
    """Pass through a numeric metric supplied by the metrics API (0/1 vs threshold)."""
    metrics = metrics or {}
    name = metric_name or case.expected.get("metric_name")
    value = metrics.get(name)
    if value is None:
        return 0.0, f"metric '{name}' missing from metrics API response", []
    # Normalised score is the raw metric value clamped to [0,1] when it is a ratio,
    # otherwise the gate handles thresholding.
    try:
        v = float(value)
    except (TypeError, ValueError):
        return 0.0, f"metric '{name}' not numeric: {value!r}", []
    score = min(max(v, 0.0), 1.0) if 0.0 <= v <= 1.0 else v
    return score, f"metric '{name}' = {v}", [f"{name}={v}"]


@scorer("ai_confidence")
def ai_confidence(*, observation, case, metrics=None, **_) -> tuple[float, str, list[str]]:
    """Use the model's self-reported AI_Confidence_Score (0..1) as the score."""
    metrics = metrics or {}
    value = metrics.get("ai_confidence_score")
    if value is None:
        return 0.0, "ai_confidence_score missing from CTA_ACTION payload", []
    v = min(max(float(value), 0.0), 1.0)
    return v, f"AI_Confidence_Score = {v}", [f"ai_confidence_score={v}"]
