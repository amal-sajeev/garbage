"""Scorer registry + built-in scorers.

A scorer is `(observation, case, metrics_by_case) -> (score, rationale, evidence)`
registered by name. Agents can add bespoke scorers via `@scorer("name")` in their
`custom_tests.py`, which the registry imports at startup.

Config-driven scorers (parameterised via `MetricSpec.config`) are in
`configurable.py` — text/regex, JSON, document-structure, and a custom LLM
`rubric` judge from config.
"""

from .base import scorer, get_scorer, all_scorers
from . import deterministic  # noqa: F401  (registers built-ins)
from . import similarity     # noqa: F401  (reference-based)
from . import trajectory     # noqa: F401  (agent trajectory)
from . import safety         # noqa: F401  (safety & compliance)
from . import operational    # noqa: F401  (SLOs)
from . import llm_judge      # noqa: F401  (judge + rubric dimensions)
from . import configurable   # noqa: F401  (config-driven scorers)

__all__ = ["all_scorers", "get_scorer", "scorer"]
