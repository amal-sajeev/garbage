"""Config-driven scorers — custom evaluation metrics from ``dataset.json``.

Every scorer here is parameterised entirely through ``MetricSpec.config`` (the
``config`` field on a metric in ``dataset.json``). Engineers define new checks
without writing Python: they reference the scorer by name and supply the
parameters in the ``config`` block.

Four families ship:

**Text / regex** (operate on the extracted output text):
  - ``contains``          — required terms must appear (with min_count).
  - ``regex_match``       — regex patterns must match.
  - ``length_range``      — output length within min/max (words or chars).
  - ``keyword_count``    — count of keyword occurrences (raw count metric).

**JSON** (operate on the parsed JSON output):
  - ``json_path``         — dotted-path value check (equals/contains/exists).
  - ``field_match``       — required fields with value operators (==/contains/regex/in).
  - ``json_schema_valid``  — output matches a JSON schema from config.

**Document structure** (need pypdf/python-docx; skip cleanly if absent):
  - ``section_present``  — required section headings must appear.
  - ``heading_count``    — number of headings within min/max.
  - ``docx_table_has``   — DOCX tables with required headers + min rows.

**Custom LLM rubric from config** (the key feature):
  - ``rubric``            — engineer writes the rubric text + scale in config;
                            reuses the Vertex judge with self-consistency.

All scorers return ``(score, rationale, evidence[, extras])`` and read their
parameters from ``spec.config``. Document-structure scorers raise
``MetricSkipped`` when the parsing library is absent (clean omit, like
Vertex-offline).
"""

from __future__ import annotations

import json
import re
from statistics import pvariance
from typing import Any

from .base import scorer, MetricSkipped
from .output_text import render_output_text
from ..adapters.documents import (
    parse_markdown_sections,
    parse_headings,
)


# --------------------------------------------------------------------------- #
# Helpers
# --------------------------------------------------------------------------- #

def _output_text(observation) -> str:
    """Get the text form of the observation output (uses pre-extracted text)."""
    meta = observation.metadata or {}
    if meta.get("extracted_text"):
        return meta["extracted_text"]
    return render_output_text(observation.output)


def _output_json(observation) -> Any:
    """Parse the observation output as JSON (dict/list), or raise ValueError."""
    raw = observation.output
    if isinstance(raw, (dict, list)):
        return raw
    if isinstance(raw, str):
        return json.loads(raw)
    raise ValueError("output is not JSON")


def _dotted(obj: Any, path: str) -> Any:
    """Look up a dotted path in a nested dict/list, returning None if missing."""
    cur: Any = obj
    for part in path.split("."):
        if isinstance(cur, dict):
            cur = cur.get(part)
        elif isinstance(cur, list):
            try:
                cur = cur[int(part)]
            except (ValueError, IndexError):
                return None
        else:
            return None
    return cur


# --------------------------------------------------------------------------- #
# Text / regex scorers
# --------------------------------------------------------------------------- #

@scorer("contains")
def contains(*, observation, case, spec=None, **_):
    """Required terms must appear in the output text.

    config:
      terms: [str, ...]          — terms that must be present.
      case_sensitive: bool       — default false.
      min_count: int             — minimum occurrences per term (default 1).
    """
    cfg = (spec.config if spec else {}) or {}
    terms = cfg.get("terms", [])
    if not terms:
        return 1.0, "no terms configured", []
    case_sensitive = cfg.get("case_sensitive", False)
    min_count = int(cfg.get("min_count", 1))

    text = _output_text(observation)
    if not case_sensitive:
        text = text.lower()
    found, evidence = 0, []
    for term in terms:
        t = term if case_sensitive else term.lower()
        count = text.count(t)
        ok = count >= min_count
        found += 1 if ok else 0
        evidence.append(f"{'✓' if ok else '✗'} '{term}' x{count} (need {min_count})")
    score = found / len(terms) if terms else 1.0
    rationale = f"{found}/{len(terms)} required terms present"
    return score, rationale, evidence


@scorer("regex_match")
def regex_match(*, observation, case, spec=None, **_):
    """Regex patterns must match the output text.

    config:
      patterns: [{pattern: str, required: bool, flags: str}, ...]
        - required (default true): if false, the pattern is informational only.
        - flags: any combination of 'i','m','s','x' (regex flags).
    """
    cfg = (spec.config if spec else {}) or {}
    patterns = cfg.get("patterns", [])
    if not patterns:
        return 1.0, "no patterns configured", []
    text = _output_text(observation)
    required_total, matched, evidence = 0, 0, []
    for entry in patterns:
        pat = entry.get("pattern", "")
        required = entry.get("required", True)
        flag_str = entry.get("flags", "")
        flags = 0
        if "i" in flag_str:
            flags |= re.I
        if "m" in flag_str:
            flags |= re.M
        if "s" in flag_str:
            flags |= re.S
        if "x" in flag_str:
            flags |= re.X
        hit = bool(re.search(pat, text, flags))
        if required:
            required_total += 1
            matched += 1 if hit else 0
            evidence.append(f"{'✓' if hit else '✗'} /{pat}/")
        else:
            evidence.append(f"  /{pat}/ -> {'hit' if hit else 'miss'} (optional)")
    score = matched / required_total if required_total else 1.0
    return score, f"{matched}/{required_total} required patterns matched", evidence


@scorer("length_range")
def length_range(*, observation, case, spec=None, **_):
    """Output length (words or chars) within [min, max].

    config:
      min: int (default 0)
      max: int (default 0 = unlimited)
      unit: "words" | "chars" (default "words")

    Returns a 0..1 score: 1.0 inside the range, linearly decreasing outside.
    For ``lower_is_better`` use ``direction`` + ``norm_min``/``norm_max`` on the
    MetricSpec; this scorer returns the raw length in ``extras.raw_value`` so
    the runner's normaliser maps it.
    """
    cfg = (spec.config if spec else {}) or {}
    lo = int(cfg.get("min", 0))
    hi = int(cfg.get("max", 0))
    unit = cfg.get("unit", "words")
    text = _output_text(observation)
    length = len(text.split()) if unit == "words" else len(text)

    if hi > 0 and lo > 0 and lo <= length <= hi:
        score = 1.0
    elif hi == 0 and length >= lo:
        score = 1.0
    elif length < lo and lo > 0:
        score = max(0.0, length / lo) if lo > 0 else 1.0
    elif hi > 0 and length > hi:
        score = max(0.0, hi / length) if length > 0 else 0.0
    else:
        score = 1.0

    range_str = f"[{lo}, {hi if hi > 0 else '∞'})"
    rationale = f"{unit}={length} vs range {range_str}"
    evidence = [f"length={length} {unit}"]
    return score, rationale, evidence, {"raw_value": float(length)}


@scorer("keyword_count")
def keyword_count(*, observation, case, spec=None, **_):
    """Count keyword occurrences in the output (raw count metric).

    config:
      terms: [str, ...]    — keywords to count.
      case_sensitive: bool  — default false.

    Returns the total count in ``extras.raw_value``; use ``direction``,
    ``norm_min``, ``norm_max`` on the MetricSpec to normalise.
    """
    cfg = (spec.config if spec else {}) or {}
    terms = cfg.get("terms", [])
    case_sensitive = cfg.get("case_sensitive", False)
    text = _output_text(observation)
    if not case_sensitive:
        text = text.lower()
    total = 0
    evidence = []
    for term in terms:
        t = term if case_sensitive else term.lower()
        c = text.count(t)
        total += c
        evidence.append(f"'{term}': {c}")
    return float(total), f"total keyword hits={total}", evidence, {"raw_value": float(total)}


# --------------------------------------------------------------------------- #
# JSON scorers
# --------------------------------------------------------------------------- #

@scorer("json_path")
def json_path(*, observation, case, spec=None, **_):
    """Check a dotted-path value in the JSON output.

    config:
      path: str             — dotted path into the JSON (e.g. "data.results[0].id").
      op: str               — "equals" | "contains" | "exists" | "regex" (default "exists").
      value: Any            — comparison value for equals/contains/regex.
    """
    cfg = (spec.config if spec else {}) or {}
    path = cfg.get("path", "")
    op = cfg.get("op", "exists")
    value = cfg.get("value")
    if not path:
        return 1.0, "no path configured", []
    try:
        obj = _output_json(observation)
    except (TypeError, ValueError) as exc:
        return 0.0, f"output is not valid JSON: {exc}", []

    val = _dotted(obj, path)
    if op == "exists":
        ok = val is not None
        return (1.0 if ok else 0.0), f"path '{path}' {'exists' if ok else 'missing'}", [
            f"{path}={'present' if ok else 'absent'}"
        ]
    if op == "equals":
        ok = val == value
        return (1.0 if ok else 0.0), f"{path}=={value!r}: {ok}", [f"{path}={val!r}"]
    if op == "contains":
        try:
            ok = value in val if val is not None else False
        except TypeError:
            ok = False
        return (1.0 if ok else 0.0), f"{value!r} in {path}: {ok}", [f"{path}={val!r}"]
    if op == "regex":
        try:
            ok = bool(re.search(str(value), str(val))) if val is not None else False
        except re.error:
            ok = False
        return (1.0 if ok else 0.0), f"/{value}/ matches {path}: {ok}", [f"{path}={val!r}"]
    return 0.0, f"unknown op '{op}'", []


@scorer("field_match")
def field_match(*, observation, case, spec=None, **_):
    """Required JSON fields with value operators.

    config:
      fields: [{name: str, op: str, value: Any, required: bool}, ...]
        op: "==" | "!=" | "contains" | "regex" | "in" | "exists" | "type"
        required: default true
    """
    cfg = (spec.config if spec else {}) or {}
    fields = cfg.get("fields", [])
    if not fields:
        return 1.0, "no fields configured", []
    try:
        obj = _output_json(observation)
    except (TypeError, ValueError) as exc:
        return 0.0, f"output is not valid JSON: {exc}", []

    checks, evidence = 0, []
    _type_map = {
        "str": str, "int": int, "float": (int, float), "bool": bool,
        "list": list, "dict": dict, "number": (int, float),
    }
    for f in fields:
        name = f.get("name", "")
        op = f.get("op", "exists")
        value = f.get("value")
        required = f.get("required", True)
        present = name in obj if isinstance(obj, dict) else False
        val = obj.get(name) if isinstance(obj, dict) and present else None

        if op == "exists":
            ok = present
        elif op == "==":
            ok = present and val == value
        elif op == "!=":
            ok = present and val != value
        elif op == "contains":
            try:
                ok = present and value in val
            except TypeError:
                ok = False
        elif op == "regex":
            try:
                ok = present and bool(re.search(str(value), str(val)))
            except re.error:
                ok = False
        elif op == "in":
            ok = present and val in (value if isinstance(value, (list, tuple, set)) else [value])
        elif op == "type":
            py_type = _type_map.get(str(value).lower(), object)
            ok = present and isinstance(val, py_type)
        else:
            ok = False

        if required:
            checks += 1 if ok else 0
        ev = f"{'✓' if ok else '✗'} {name} {op} {value!r}"
        if present:
            ev += f" (got {val!r})"
        evidence.append(ev)

    score = checks / len(fields) if fields else 1.0
    return score, f"{checks}/{len(fields)} field checks passed", evidence


@scorer("json_schema_valid")
def json_schema_valid_config(*, observation, case, spec=None, **_):
    """Output matches a JSON schema from config.

    config:
      schema: dict              — a JSON Schema (draft-07 subset: type, properties,
                                   required, items, additionalProperties).
      required: [str, ...]      — shortcut: required keys (if no schema).
      types: {field: type_str}  — shortcut: per-field type check.
    """
    cfg = (spec.config if spec else {}) or {}
    schema = cfg.get("schema")
    if schema:
        return _validate_schema(observation, schema)
    # Fall back to the shortcut required/types form (enhanced from the original).
    required = cfg.get("required", [])
    types = cfg.get("types", {})
    try:
        obj = _output_json(observation)
    except (TypeError, ValueError) as exc:
        return 0.0, f"output is not valid JSON: {exc}", []
    if not isinstance(obj, dict):
        return (1.0, "valid JSON (non-object)", []) if not required else (0.0, "expected JSON object", [])

    checks: list[bool] = []
    evidence: list[str] = []
    _type_map = {"str": str, "int": int, "float": (int, float), "bool": bool,
                 "list": list, "dict": dict, "number": (int, float)}
    for field in required:
        present = field in obj
        checks.append(present)
        ok_type = True
        if present and field in types:
            ok_type = isinstance(obj[field], _type_map.get(types[field], object))
            checks.append(ok_type)
        evidence.append(f"{'✓' if present and ok_type else '✗'} {field}")
    score = sum(checks) / len(checks) if checks else 1.0
    return score, f"{sum(checks)}/{len(checks)} schema checks passed", evidence


def _validate_schema(observation, schema: dict) -> tuple:
    """Minimal JSON Schema (draft-07 subset) validator."""
    try:
        obj = _output_json(observation)
    except (TypeError, ValueError) as exc:
        return 0.0, f"output is not valid JSON: {exc}", []

    errors: list[str] = []
    _check_schema(obj, schema, "", errors)
    if not errors:
        return 1.0, "output matches schema", ["schema valid"]
    return 0.0, f"{len(errors)} schema violations", errors[:20]


def _check_schema(value: Any, schema: dict, path: str, errors: list[str]) -> None:
    stype = schema.get("type")
    _type_map = {
        "string": str, "integer": int, "number": (int, float),
        "boolean": bool, "array": list, "object": dict, "null": type(None),
    }
    if stype:
        expected = _type_map.get(stype)
        if expected and not isinstance(value, expected):
            errors.append(f"{path or 'root'}: expected {stype}, got {type(value).__name__}")
            return
    if stype == "object" or isinstance(value, dict):
        required = schema.get("required", [])
        for r in required:
            if r not in value:
                errors.append(f"{path}.{r}: required field missing")
        props = schema.get("properties", {})
        for k, v in value.items():
            if k in props:
                _check_schema(v, props[k], f"{path}.{k}", errors)
            elif schema.get("additionalProperties") is False:
                errors.append(f"{path}.{k}: additional property not allowed")
    if stype == "array" or isinstance(value, list):
        items_schema = schema.get("items")
        if items_schema:
            for i, item in enumerate(value):
                _check_schema(item, items_schema, f"{path}[{i}]", errors)


# --------------------------------------------------------------------------- #
# Document-structure scorers (skip cleanly when pypdf/python-docx absent)
# --------------------------------------------------------------------------- #

@scorer("section_present")
def section_present(*, observation, case, spec=None, **_):
    """Required section headings must appear in the document.

    config:
      sections: [str, ...]   — heading substrings that must be present.

    Works on Markdown (# headings), extracted PDF/DOCX text, and plain text.
    """
    cfg = (spec.config if spec else {}) or {}
    sections = cfg.get("sections", [])
    if not sections:
        return 1.0, "no sections configured", []

    meta = observation.metadata or {}
    content_type = meta.get("content_type", "auto")
    text = _output_text(observation)

    if content_type == "markdown":
        found_sections = parse_markdown_sections(text)
        found_keys = {k.lower() for k in found_sections}
    else:
        headings = parse_headings(text, content_type)
        found_keys = set()
        for h in headings:
            if isinstance(h, tuple):
                found_keys.add(h[1].lower())
            else:
                found_keys.add(str(h).lower())

    found, evidence = 0, []
    for s in sections:
        hit = any(s.lower() in k for k in found_keys)
        found += 1 if hit else 0
        evidence.append(f"{'✓' if hit else '✗'} section '{s}'")
    score = found / len(sections) if sections else 1.0
    return score, f"{found}/{len(sections)} required sections present", evidence


@scorer("heading_count")
def heading_count(*, observation, case, spec=None, **_):
    """Number of headings within [min, max].

    config:
      min: int (default 0)
      max: int (default 0 = unlimited)

    Returns raw count in extras.raw_value for normalisation.
    """
    cfg = (spec.config if spec else {}) or {}
    lo = int(cfg.get("min", 0))
    hi = int(cfg.get("max", 0))

    meta = observation.metadata or {}
    content_type = meta.get("content_type", "auto")
    text = _output_text(observation)
    headings = parse_headings(text, content_type)
    count = len(headings)

    if hi > 0 and lo <= count <= hi:
        score = 1.0
    elif hi == 0 and count >= lo:
        score = 1.0
    elif count < lo and lo > 0:
        score = max(0.0, count / lo)
    elif hi > 0 and count > hi:
        score = max(0.0, hi / count) if count > 0 else 0.0
    else:
        score = 1.0

    range_str = f"[{lo}, {hi if hi > 0 else '∞'})"
    return score, f"headings={count} vs range {range_str}", [f"count={count}"], {"raw_value": float(count)}


@scorer("docx_table_has")
def docx_table_has(*, observation, case, spec=None, **_):
    """DOCX tables must contain required headers and minimum rows.

    config:
      tables: [{required_headers: [str, ...], min_rows: int}, ...]

    Requires python-docx; skips cleanly if absent.
    """
    cfg = (spec.config if spec else {}) or {}
    tables_spec = cfg.get("tables", [])
    if not tables_spec:
        return 1.0, "no table constraints configured", []

    meta = observation.metadata or {}
    raw = meta.get("raw_output")
    if raw is None:
        # Try extracting from output directly.
        raw = observation.output

    try:
        import docx
        import io
    except ImportError as exc:
        raise MetricSkipped(
            "python-docx is not installed; docx_table_has is skipped."
        ) from exc

    # Resolve to bytes.
    doc_bytes: bytes | None = None
    if isinstance(raw, (bytes, bytearray)):
        doc_bytes = bytes(raw)
    elif isinstance(raw, str):
        import base64
        import binascii
        try:
            doc_bytes = base64.b64decode(raw, validate=True)
        except (binascii.Error, ValueError):
            doc_bytes = raw.encode("utf-8")
    if doc_bytes is None:
        return 0.0, "could not resolve DOCX bytes from observation", []

    try:
        document = docx.Document(io.BytesIO(doc_bytes))
    except Exception as exc:
        return 0.0, f"could not parse DOCX: {exc}", []

    doc_tables = document.tables
    checks, evidence = 0, []
    for i, tspec in enumerate(tables_spec):
        required_headers = [h.lower() for h in tspec.get("required_headers", [])]
        min_rows = int(tspec.get("min_rows", 1))

        # Find a table whose headers contain all required headers.
        found = False
        for tbl in doc_tables:
            if len(tbl.rows) < min_rows:
                continue
            actual_headers = [c.text.strip().lower() for c in tbl.rows[0].cells]
            if all(h in actual_headers for h in required_headers):
                found = True
                break
        checks += 1 if found else 0
        evidence.append(
            f"{'✓' if found else '✗'} table #{i}: headers={required_headers} min_rows={min_rows}"
        )

    score = checks / len(tables_spec) if tables_spec else 1.0
    return score, f"{checks}/{len(tables_spec)} table constraints met", evidence


# --------------------------------------------------------------------------- #
# Custom LLM rubric judge from config — the key "custom metric from config" feature
# --------------------------------------------------------------------------- #

from .llm_judge import build_judge, _run_samples, _samples, _text, _invoke_cached


_RUBRIC_PROMPT_CUSTOM = """You are a strict evaluation judge scoring ONE criterion.

Criterion: {rubric}

Score from 0.0 to 1.0. Reason step by step, then give the score, a short
rationale, and cite specific evidence strings from the output.
{bias}

INPUT:
{input}

{golden_block}

AGENT OUTPUT:
{output}
"""


@scorer("rubric")
def rubric(*, observation, case, spec=None, metrics=None, judge_repetitions: int = 1, **_):
    """Custom LLM rubric judge — the rubric text comes from config.

    config:
      rubric: str          — the evaluation criterion text (what to judge).
      uses_golden: bool     — if true, include the golden_output in the prompt
                               (default false; skips if golden is missing).
      bias_guard: bool      — if true, add the standard bias guard (default true).
      examples: str         — optional few-shot examples appended to the prompt.

    Reuses the Vertex judge (build_judge) with self-consistency via
    judge_repetitions. Skips cleanly when Vertex is unavailable (offline).
    """
    cfg = (spec.config if spec else {}) or {}
    rubric_text = cfg.get("rubric", "")
    if not rubric_text:
        raise MetricSkipped("rubric scorer requires config.rubric text")
    uses_golden = cfg.get("uses_golden", False)
    bias_guard = cfg.get("bias_guard", True)
    examples = cfg.get("examples", "")

    try:
        judge = build_judge()
    except RuntimeError as exc:
        raise MetricSkipped(f"LLM judge unavailable: {exc}") from exc

    from .llm_judge import _BIAS_GUARD

    inp = _text(case.input)
    out = render_output_text(observation.output)

    golden_block = ""
    if uses_golden:
        if not case.golden_output:
            raise MetricSkipped("rubric uses_golden=true but no golden_output provided")
        golden_block = f"GOLDEN OUTPUT:\n{_text(case.golden_output)}\n"

    bias = _BIAS_GUARD if bias_guard else ""
    extra = f"\nExamples:\n{examples}" if examples else ""

    def render(_swap: bool) -> str:
        return _RUBRIC_PROMPT_CUSTOM.format(
            rubric=rubric_text,
            bias=bias,
            input=inp,
            golden_block=golden_block,
            output=out,
        ) + extra

    return _run_samples(judge, render, _samples(judge_repetitions))


# --------------------------------------------------------------------------- #
# Multi-criteria rubric judge — N criteria in one Vertex call (cost saver)
# --------------------------------------------------------------------------- #

from .vertex import build_judge_for, MultiRubricVerdict

_MULTI_RUBRIC_PROMPT = """You are a strict evaluation judge scoring MULTIPLE criteria in one call.

Score each criterion from 0.0 to 1.0. For each, provide a short rationale.
{bias}

INPUT:
{input}

{golden_block}

AGENT OUTPUT:
{output}

CRITERIA:
{criteria_list}
"""


@scorer("rubric_multi")
def rubric_multi(*, observation, case, spec=None, metrics=None, judge_repetitions: int = 1, **_):
    """Multi-criteria LLM rubric judge — scores N criteria in ONE Vertex call.

    A cost-saver vs defining N separate ``rubric`` metrics: one judge invocation
    returns scores for all criteria. The scorer returns the mean; per-criterion
    breakdown is in the evidence.

    config:
      criteria: [{name: str, rubric: str}, ...]  — the criteria to evaluate
      uses_golden: bool                            — include golden_output in prompt
      bias_guard: bool                             — add the standard bias guard
    """
    cfg = (spec.config if spec else {}) or {}
    criteria = cfg.get("criteria", [])
    if not criteria:
        raise MetricSkipped("rubric_multi requires config.criteria (list of {name, rubric})")
    uses_golden = cfg.get("uses_golden", False)
    bias_guard = cfg.get("bias_guard", True)

    try:
        judge = build_judge_for(MultiRubricVerdict)
    except RuntimeError as exc:
        raise MetricSkipped(f"LLM judge unavailable: {exc}") from exc

    from .llm_judge import _BIAS_GUARD

    inp = _text(case.input)
    out = render_output_text(observation.output)

    golden_block = ""
    if uses_golden:
        if not case.golden_output:
            raise MetricSkipped("rubric_multi uses_golden=true but no golden_output provided")
        golden_block = f"GOLDEN OUTPUT:\n{_text(case.golden_output)}\n"

    criteria_list = "\n".join(
        f"{i+1}. {c.get('name', f'criterion_{i+1}')}: {c.get('rubric', '')}"
        for i, c in enumerate(criteria)
    )
    bias = _BIAS_GUARD if bias_guard else ""
    prompt = _MULTI_RUBRIC_PROMPT.format(
        bias=bias, input=inp, golden_block=golden_block,
        output=out, criteria_list=criteria_list,
    )

    n = _samples(judge_repetitions)
    scores_per_criterion: dict[str, list[float]] = {c["name"]: [] for c in criteria}
    all_avgs: list[float] = []
    last_verdict = None
    for i in range(n):
        verdict = _invoke_cached(judge, prompt, i)
        last_verdict = verdict
        for cs in verdict.scores:
            name = cs.criterion
            if name in scores_per_criterion:
                scores_per_criterion[name].append(cs.score)
        case_avg = sum(cs.score for cs in verdict.scores) / max(len(verdict.scores), 1)
        all_avgs.append(case_avg)

    overall = sum(all_avgs) / len(all_avgs) if all_avgs else 0.0
    evidence = []
    for c in criteria:
        name = c["name"]
        vals = scores_per_criterion.get(name, [])
        if vals:
            mean = sum(vals) / len(vals)
            evidence.append(f"{name}: {mean:.3f} ({len(vals)} samples)")
    if last_verdict and last_verdict.overall_rationale:
        evidence.append(f"overall: {last_verdict.overall_rationale}")
    extras = {"variance": pvariance(all_avgs) if len(all_avgs) > 1 else 0.0}
    return overall, f"mean of {len(criteria)} criteria", evidence, extras


# --------------------------------------------------------------------------- #
# PDF table extraction scorer (needs pdfplumber; skips cleanly if absent)
# --------------------------------------------------------------------------- #

@scorer("pdf_table_has")
def pdf_table_has(*, observation, case, spec=None, **_):
    """PDF tables must contain required headers and minimum rows.

    config:
      tables: [{required_headers: [str, ...], min_rows: int}, ...]

    Requires ``pdfplumber``; skips cleanly (MetricSkipped) if not installed.
    """
    cfg = (spec.config if spec else {}) or {}
    tables_spec = cfg.get("tables", [])
    if not tables_spec:
        return 1.0, "no table constraints configured", []

    meta = observation.metadata or {}
    raw = meta.get("raw_output")
    if raw is None:
        raw = observation.output

    try:
        import pdfplumber
        import io
    except ImportError as exc:
        raise MetricSkipped(
            "pdfplumber is not installed; pdf_table_has is skipped. "
            "Install pdfplumber to enable PDF table checks."
        ) from exc

    # Resolve to bytes.
    doc_bytes: bytes | None = None
    if isinstance(raw, (bytes, bytearray)):
        doc_bytes = bytes(raw)
    elif isinstance(raw, str):
        import base64
        import binascii
        try:
            doc_bytes = base64.b64decode(raw, validate=True)
        except (binascii.Error, ValueError):
            doc_bytes = raw.encode("utf-8")
    if doc_bytes is None:
        return 0.0, "could not resolve PDF bytes from observation", []

    try:
        all_tables = []
        with pdfplumber.open(io.BytesIO(doc_bytes)) as pdf:
            for page in pdf.pages:
                all_tables.extend(page.extract_tables())
    except Exception as exc:
        return 0.0, f"could not parse PDF tables: {exc}", []

    checks, evidence = 0, []
    for i, tspec in enumerate(tables_spec):
        required_headers = [h.lower() for h in tspec.get("required_headers", [])]
        min_rows = int(tspec.get("min_rows", 1))
        found = False
        for tbl in all_tables:
            if len(tbl) < min_rows:
                continue
            actual_headers = [str(c).lower() if c else "" for c in tbl[0]]
            if all(h in actual_headers for h in required_headers):
                found = True
                break
        checks += 1 if found else 0
        evidence.append(
            f"{'✓' if found else '✗'} table #{i}: headers={required_headers} min_rows={min_rows}"
        )
    score = checks / len(tables_spec) if tables_spec else 1.0
    return score, f"{checks}/{len(tables_spec)} table constraints met", evidence
