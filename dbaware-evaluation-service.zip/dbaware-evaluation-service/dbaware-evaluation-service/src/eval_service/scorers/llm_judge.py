"""LLM-as-a-judge scorers (quality vs the golden output + rubric dimensions).

Runs the Vertex judge with temperature 0. Improvements over the first cut:

* **Self-consistency**: N samples are drawn; the mean is returned and the sample
  variance is recorded on the Score. Variance above `EVAL_JUDGE_MAX_VARIANCE`
  flags the verdict `unstable` (a reliability warning, not a gate failure).
* **Response caching**: identical (model, prompt) invocations are memoised for
  the life of the process, so repeated samples / re-runs don't re-bill Vertex.
* **Reference-free mode**: when a case has no `golden_output`, the judge scores
  the answer against the INPUT alone instead of a `"(no golden output)"` string.
* **Bias controls**: the prompt explicitly instructs the judge to ignore answer
  length and position; with N>1 samples the GOLDEN/AGENT order is swapped on
  alternate samples to detect position bias (recorded in extras).

The pass decision is re-applied in code by the runner, never trusted from the
model. Skips (not fails) when the Vertex judge is unavailable offline.
"""

from __future__ import annotations

import json
import threading
import time
from statistics import pvariance

from ..config import Config
from .base import scorer, MetricSkipped
from .output_text import render_output_text
from .vertex import build_judge, build_judge_for, PairwiseVerdict

_BIAS_GUARD = "Judge only on substance. Do NOT reward longer answers, and do NOT let the order in which answers are presented affect the score."

_JUDGE_PROMPT = """You are a strict evaluation judge for an AI agent.

Compare the AGENT OUTPUT against the GOLDEN (ideal) OUTPUT and any CONTEXT.
Score from 0.0 to 1.0 how well the agent output matches the golden output in
factual correctness and completeness. Penalise unsupported or contradicted
claims heavily. Provide a short rationale and cite specific evidence strings.
{bias}

INPUT:
{input}

GOLDEN OUTPUT:
{golden}

AGENT OUTPUT:
{output}
"""

_JUDGE_PROMPT_REFFREE = """You are a strict evaluation judge for an AI agent.

No reference answer is available. Score from 0.0 to 1.0 how well the AGENT
OUTPUT satisfies the INPUT request on factual correctness, completeness, and
usefulness. Penalise unsupported or contradicted claims heavily. Provide a short
rationale and cite specific evidence strings.
{bias}

INPUT:
{input}

AGENT OUTPUT:
{output}
"""

_RUBRICS = {
    "relevance": "how directly the AGENT OUTPUT answers the INPUT request",
    "completeness": "whether the AGENT OUTPUT covers all information in the GOLDEN OUTPUT",
    "coherence": "how logically structured and internally consistent the AGENT OUTPUT is",
    "conciseness": "whether the AGENT OUTPUT avoids redundancy and unnecessary content",
    "instruction_following": "how well the AGENT OUTPUT obeys the explicit instructions in the INPUT",
}

_RUBRIC_USES_GOLDEN = {"completeness"}

_INSTRUCTION_GUARD = (
    "If the INPUT contains no explicit formatting or content instructions, do "
    "NOT invent any (e.g. do not require JSON, headings, or a particular length) "
    "and do not infer instructions from the output's format. Score how well the "
    "output addresses the requested subject; absent explicit instructions, a "
    "relevant on-topic answer scores high."
)

_RUBRIC_PROMPT = """You are a strict evaluation judge scoring ONE dimension.

Dimension: {dimension} — score 0.0 to 1.0 based on {criterion}.
Reason step by step, then give the score, a short rationale, and evidence.
{bias}
{extra}

INPUT:
{input}

GOLDEN OUTPUT:
{golden}

AGENT OUTPUT:
{output}
"""

_RUBRIC_PROMPT_REFFREE = """You are a strict evaluation judge scoring ONE dimension.

Dimension: {dimension} — score 0.0 to 1.0 based on {criterion}.
Reason step by step, then give the score, a short rationale, and evidence.
{bias}
{extra}

INPUT:
{input}

AGENT OUTPUT:
{output}
"""

_CACHE: dict[tuple[str, str, int], object] = {}
_CACHE_LOCK = threading.Lock()


def reset_cache() -> None:
    """Clear the judge response cache (e.g. between runs)."""
    with _CACHE_LOCK:
        _CACHE.clear()


def _text(value) -> str:
    return value if isinstance(value, str) else json.dumps(value, ensure_ascii=False, default=str)


def _samples(judge_repetitions: int) -> int:
    n = judge_repetitions if judge_repetitions and judge_repetitions > 1 else Config.JUDGE_SAMPLES
    return max(1, min(int(n), 5))


def _invoke_cached(judge, prompt: str, idx: int = 0):
    key = (Config.JUDGE_MODEL, prompt, idx)
    with _CACHE_LOCK:
        if key in _CACHE:
            return _CACHE[key]
    verdict = _invoke_with_retry(judge, prompt)
    with _CACHE_LOCK:
        return _CACHE.setdefault(key, verdict)


def _invoke_with_retry(judge, prompt: str):
    import httpx

    transient = (
        httpx.RemoteProtocolError,
        httpx.ConnectError,
        httpx.ReadError,
        httpx.WriteError,
        httpx.ConnectTimeout,
        httpx.ReadTimeout,
        httpx.PoolTimeout,
    )
    attempts = max(1, Config.JUDGE_TRANSIENT_RETRIES)
    last_exc: Exception | None = None
    for attempt in range(attempts):
        try:
            return judge.invoke(prompt)
        except transient as exc:
            last_exc = exc
            if attempt + 1 >= attempts:
                break
            time.sleep(min(0.5 * (2 ** attempt), 4.0))
        except Exception as exc:
            msg = str(exc).lower()
            if "disconnected without sending a response" in msg or "server disconnected" in msg:
                last_exc = exc
                if attempt + 1 >= attempts:
                    break
                time.sleep(min(0.5 * (2 ** attempt), 4.0))
            else:
                raise
    raise last_exc  # type: ignore[misc]


def _run_samples(judge, render, n: int, *, swap_capable: bool = False):
    scores: list[float] = []
    swapped_scores: list[float] = []
    last = None
    for i in range(n):
        swap = bool(swap_capable and Config.JUDGE_SWAP_ORDER and i % 2 == 1)
        verdict = _invoke_cached(judge, render(swap), i)
        scores.append(float(verdict.score))
        if swap:
            swapped_scores.append(float(verdict.score))
        last = verdict
    avg = sum(scores) / len(scores)
    var = pvariance(scores) if len(scores) > 1 else 0.0
    rationale = last.rationale if last else ""
    evidence = list(last.evidence) if last else []
    extras: dict[str, float | bool] = {"variance": var}
    if len(scores) > 1:
        evidence.append(f"samples={scores} mean={avg:.3f} var={var:.4f}")
    if swapped_scores:
        normal = [s for i, s in enumerate(scores) if i % 2 == 0]
        if normal:
            extras["position_bias"] = abs(
                sum(normal) / len(normal) - sum(swapped_scores) / len(swapped_scores)
            )
    if var > Config.JUDGE_MAX_VARIANCE:
        extras["unstable"] = True
    return avg, rationale, evidence, extras


@scorer("faithfulness")
def faithfulness(*, observation, case, metrics=None, judge_repetitions: int = 1, **_):
    try:
        judge = build_judge()
    except RuntimeError as exc:
        raise MetricSkipped(f"LLM judge unavailable: {exc}") from exc

    inp = _text(case.input)
    out = render_output_text(observation.output)
    if case.golden_output:
        golden = _text(case.golden_output)

        def render(swap: bool) -> str:
            a, b = (out, golden) if not swap else (golden, out)
            return _JUDGE_PROMPT.format(bias=_BIAS_GUARD, input=inp, golden=b, output=a)

        return _run_samples(judge, render, _samples(judge_repetitions), swap_capable=True)

    def render_ref_free(_swap: bool) -> str:
        return _JUDGE_PROMPT_REFFREE.format(bias=_BIAS_GUARD, input=inp, output=out)

    return _run_samples(judge, render_ref_free, _samples(judge_repetitions))


def _make_rubric_scorer(dimension: str, criterion: str):
    uses_golden = dimension in _RUBRIC_USES_GOLDEN
    extra = _INSTRUCTION_GUARD if dimension == "instruction_following" else ""

    @scorer(dimension)
    def _rubric(*, observation, case, metrics=None, judge_repetitions: int = 1, **_):
        try:
            judge = build_judge()
        except RuntimeError as exc:
            raise MetricSkipped(f"LLM judge unavailable: {exc}") from exc
        inp = _text(case.input)
        out = render_output_text(observation.output)

        if uses_golden:
            if not case.golden_output:
                raise MetricSkipped(f"{dimension} requires a golden_output reference")
            golden = _text(case.golden_output)

            def render(_swap: bool) -> str:
                return _RUBRIC_PROMPT.format(
                    dimension=dimension, criterion=criterion,
                    bias=_BIAS_GUARD, extra=extra, input=inp, golden=golden, output=out,
                )
        else:
            def render(_swap: bool) -> str:
                return _RUBRIC_PROMPT_REFFREE.format(
                    dimension=dimension, criterion=criterion,
                    bias=_BIAS_GUARD, extra=extra, input=inp, output=out,
                )

        return _run_samples(judge, render, _samples(judge_repetitions))

    return _rubric


for _dim, _crit in _RUBRICS.items():
    _make_rubric_scorer(_dim, _crit)


_PAIRWISE_PROMPT = """You are comparing two answers to the same INPUT.

Decide which answer is better on factual correctness, completeness, and
usefulness. Answer A is the agent under test; answer B is the reference.
{bias}
Report `winner` ('A', 'B', or 'tie') and `score`: the preference strength for
A (1.0 = A clearly better, 0.5 = tie, 0.0 = B clearly better).

INPUT:
{input}

ANSWER A:
{a}

ANSWER B:
{b}
"""


@scorer("pairwise_vs_golden")
def pairwise_vs_golden(*, observation, case, metrics=None, judge_repetitions: int = 1, **_):
    if not case.golden_output:
        raise MetricSkipped("pairwise_vs_golden requires a golden_output reference")
    try:
        judge = build_judge_for(PairwiseVerdict)
    except RuntimeError as exc:
        raise MetricSkipped(f"LLM judge unavailable: {exc}") from exc

    inp = _text(case.input)
    agent = render_output_text(observation.output)
    golden = _text(case.golden_output)
    n = _samples(judge_repetitions)
    scores: list[float] = []
    last = None
    for i in range(n):
        swap = bool(Config.JUDGE_SWAP_ORDER and i % 2 == 1)
        a, b = (golden, agent) if swap else (agent, golden)
        prompt = _PAIRWISE_PROMPT.format(bias=_BIAS_GUARD, input=inp, a=a, b=b)
        verdict = _invoke_cached(judge, prompt, i)
        pref = float(verdict.score)
        scores.append(1.0 - pref if swap else pref)
        last = verdict
    avg = sum(scores) / len(scores)
    var = pvariance(scores) if len(scores) > 1 else 0.0
    rationale = last.rationale if last else ""
    evidence = list(last.evidence) if last else []
    extras: dict[str, float | bool] = {"variance": var}
    if var > Config.JUDGE_MAX_VARIANCE:
        extras["unstable"] = True
    return avg, rationale, evidence, extras
