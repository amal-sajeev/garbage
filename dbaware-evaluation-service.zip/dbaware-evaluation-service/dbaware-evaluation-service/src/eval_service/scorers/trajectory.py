"""Trajectory scorers: judge *how* the agent reached its answer, not just the
final text. These use the tool trace on the Observation plus the CTA_ACTION-
derived tool_* metrics.

- tool_order_correct   — expected tools called in the expected relative order.
- no_redundant_calls   — penalise duplicate/repeated identical tool calls.
- tool_arg_accuracy    — expected args present per tool (nested-path aware).
- tool_error_free      — no tool errors (from CTA_ACTION tool_error_count).
- step_efficiency      — steps taken vs an expected optimal count.

Scorers return (score, rationale, evidence[, extras]).
"""

from __future__ import annotations

import json

from .base import scorer


def _tool_names(observation) -> list[str]:
    return [tc.get("name") or tc.get("Tool_Id") or "" for tc in observation.tool_calls]


def _args_blob(tc: dict) -> str:
    return json.dumps(tc.get("args") or tc.get("Tool_Param") or {}, ensure_ascii=False, default=str).lower()


@scorer("tool_order_correct")
def tool_order_correct(*, observation, case, **_):
    """Were the expected tools invoked in the expected relative order?

    case.expected.expected_tool_sequence = ["tool_a", "tool_b", ...]
    Falls back to expected_tool (single) when a sequence is not provided.
    """
    expected = case.expected.get("expected_tool_sequence")
    if not expected:
        one = case.expected.get("expected_tool")
        expected = [one] if one else []
    if not expected:
        return 1.0, "no expected tool sequence defined", []

    called = _tool_names(observation)
    # Longest-subsequence match: how many expected tools appear in order.
    i = 0
    for name in called:
        if i < len(expected) and name == expected[i]:
            i += 1
    score = i / len(expected)
    return score, f"{i}/{len(expected)} expected tools in order", [f"called={called}"]


@scorer("no_redundant_calls")
def no_redundant_calls(*, observation, case, **_):
    """1.0 when there are no duplicate identical (tool, args) invocations."""
    seen: set[tuple[str, str]] = set()
    duplicates = 0
    for tc in observation.tool_calls:
        key = (tc.get("name") or tc.get("Tool_Id") or "", _args_blob(tc))
        if key in seen:
            duplicates += 1
        seen.add(key)
    total = len(observation.tool_calls) or 1
    score = 1.0 - duplicates / total
    return score, f"{duplicates} redundant call(s) of {total}", [f"unique={len(seen)}"]


@scorer("tool_arg_accuracy")
def tool_arg_accuracy(*, observation, case, **_):
    """Fraction of expected (tool -> values) that appear in that tool's args.

    case.expected.expected_tool_args = {"tool_name": ["value1", "value2"]}.
    Falls back to expected_tool + expected_values.
    """
    spec_args: dict[str, list] = dict(case.expected.get("expected_tool_args") or {})
    if not spec_args and case.expected.get("expected_tool"):
        spec_args = {case.expected["expected_tool"]: case.expected.get("expected_values", [])}
    if not spec_args:
        return 1.0, "no expected tool args defined", []

    checks: list[bool] = []
    evidence: list[str] = []
    for tool_name, values in spec_args.items():
        blobs = [_args_blob(tc) for tc in observation.tool_calls
                 if (tc.get("name") or tc.get("Tool_Id")) == tool_name]
        joined = " ".join(blobs)
        for value in values:
            hit = str(value).lower() in joined
            checks.append(hit)
            evidence.append(f"{'✓' if hit else '✗'} {tool_name}:{value}")
    score = sum(checks) / len(checks) if checks else 1.0
    return score, f"{sum(checks)}/{len(checks)} tool-arg checks passed", evidence


@scorer("tool_error_free")
def tool_error_free(*, observation, case, metrics=None, **_):
    """1.0 when no tool errors were recorded (CTA_ACTION tool_error_count)."""
    metrics = metrics or {}
    errors = metrics.get("tool_error_count")
    if errors is None:
        # Fall back to the observation-level error flag.
        errors = 1 if observation.error else 0
    errors = float(errors)
    score = 1.0 if errors == 0 else 0.0
    return score, f"tool_error_count={errors}", [], {"raw_value": errors}


@scorer("step_efficiency")
def step_efficiency(*, observation, case, spec=None, **_):
    """Steps taken vs expected optimal; more steps than optimal lowers the score.

    case.expected.optimal_steps sets the target; defaults to the number of
    expected tools.
    """
    optimal = case.expected.get("optimal_steps")
    if optimal is None:
        seq = case.expected.get("expected_tool_sequence")
        optimal = len(seq) if seq else 1
    taken = len(observation.tool_calls) or 1
    score = min(1.0, optimal / taken) if taken else 1.0
    return score, f"{taken} steps taken vs {optimal} optimal", [], {"raw_value": float(taken)}
