"""Reference-based scorers: compare the agent output to the golden output.

These are deterministic and cheap (no LLM), catching paraphrase and structural
correctness that verbatim substring checks miss:

- token_overlap_f1   — bag-of-tokens F1 against the golden output.
- edit_similarity    — 1 - normalised Levenshtein distance.
- embedding_similarity — cosine similarity of Vertex embeddings (offline-skips
                          cleanly when no ADC credentials are present).
- json_schema_valid  — output parses as JSON and matches a supplied schema.
                          (Enhanced version in configurable.py also accepts
                           config.schema as a full JSON Schema; this simpler
                           form handles config.required + config.types.)

Note: ``field_match`` (JSON field-value checks) is implemented in
``configurable.py`` — the earlier ``json_field_match`` mentioned here was a
doc gap that is now resolved by that scorer.

Scorers return (score, rationale, evidence[, extras]).
"""

from __future__ import annotations

import json
import re
from typing import Any

from .base import scorer, MetricSkipped
from .output_text import render_output_text

_TOKEN = re.compile(r"[a-z0-9]+")


def _text(value: Any) -> str:
    return value if isinstance(value, str) else json.dumps(value, ensure_ascii=False, default=str)


def _tokens(text: str) -> list[str]:
    return _TOKEN.findall(text.lower())


@scorer("token_overlap_f1")
def token_overlap_f1(*, observation, case, **_):
    """Bag-of-tokens F1 between output and golden_output."""
    golden = case.golden_output
    if not golden:
        return 1.0, "no golden_output to compare", []
    out_tokens = _tokens(render_output_text(observation.output))
    gold_tokens = _tokens(golden)
    if not out_tokens or not gold_tokens:
        return 0.0, "empty output or golden", []

    out_set, gold_set = set(out_tokens), set(gold_tokens)
    overlap = out_set & gold_set
    if not overlap:
        return 0.0, "no token overlap with golden", []
    precision = len(overlap) / len(out_set)
    recall = len(overlap) / len(gold_set)
    f1 = 2 * precision * recall / (precision + recall)
    return f1, f"token F1={f1:.3f} (P={precision:.2f} R={recall:.2f})", [f"overlap={len(overlap)}"]


def _levenshtein(a: str, b: str) -> int:
    if a == b:
        return 0
    if not a:
        return len(b)
    if not b:
        return len(a)
    prev = list(range(len(b) + 1))
    for i, ca in enumerate(a, 1):
        cur = [i]
        for j, cb in enumerate(b, 1):
            cur.append(min(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + (ca != cb)))
        prev = cur
    return prev[-1]


@scorer("edit_similarity")
def edit_similarity(*, observation, case, **_):
    """1 - normalised Levenshtein distance vs golden_output."""
    golden = case.golden_output
    if not golden:
        return 1.0, "no golden_output to compare", []
    out = render_output_text(observation.output)
    dist = _levenshtein(out, golden)
    denom = max(len(out), len(golden)) or 1
    sim = 1.0 - dist / denom
    return sim, f"edit similarity={sim:.3f}", [f"distance={dist}"]


@scorer("embedding_similarity")
def embedding_similarity(*, observation, case, **_):
    """Cosine similarity of Vertex embeddings of output vs golden_output.

    Skips (rather than fails) when embeddings are unavailable offline.
    """
    golden = case.golden_output
    if not golden:
        return 1.0, "no golden_output to compare", []
    candidate = render_output_text(observation.output)
    if not (candidate or "").strip():
        return 0.0, "empty output to compare", []
    try:
        from .vertex import embed_texts
    except Exception as exc:
        raise MetricSkipped(f"embeddings unavailable: {exc}") from exc

    try:
        vecs = embed_texts([candidate, golden])
    except RuntimeError as exc:
        raise MetricSkipped(f"embeddings unavailable: {exc}") from exc

    if not vecs or len(vecs) < 2:
        raise MetricSkipped("embeddings returned fewer than two vectors")
    a, b = vecs[0], vecs[1]
    dot = sum(x * y for x, y in zip(a, b, strict=False))
    na = sum(x * x for x in a) ** 0.5
    nb = sum(y * y for y in b) ** 0.5
    cos = dot / (na * nb) if na and nb else 0.0
    cos = max(0.0, min(1.0, cos))
    return cos, f"embedding cosine={cos:.3f}", []


@scorer("json_schema_valid")
def json_schema_valid(*, observation, case, spec=None, **_):
    """Output parses as JSON and contains the required keys/types.

    spec.config may carry {"required": ["field", ...], "types": {"field": "str"}}.
    """
    cfg = (spec.config if spec else {}) or {}
    required = cfg.get("required", [])
    types = cfg.get("types", {})
    raw = observation.output
    try:
        obj = raw if isinstance(raw, (dict, list)) else json.loads(raw)
    except (TypeError, ValueError) as exc:
        return 0.0, f"output is not valid JSON: {exc}", []
    if not isinstance(obj, dict):
        return (1.0, "valid JSON (non-object)", []) if not required else (0.0, "expected JSON object", [])

    checks: list[bool] = []
    evidence: list[str] = []
    _type_map = {"str": str, "int": int, "float": (int, float), "bool": bool,
                 "list": list, "dict": dict, "number": (int, float)}
    for field in required:
        present = field in obj
        checks.append(present)
        ok_type = True
        if present and field in types:
            ok_type = isinstance(obj[field], _type_map.get(types[field], object))
            checks.append(ok_type)
        evidence.append(f"{'✓' if present and ok_type else '✗'} {field}")
    score = sum(checks) / len(checks) if checks else 1.0
    return score, f"{sum(checks)}/{len(checks)} schema checks passed", evidence
