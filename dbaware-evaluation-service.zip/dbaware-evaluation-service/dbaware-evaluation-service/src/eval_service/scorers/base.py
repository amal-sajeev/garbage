"""Scorer registry primitives."""

from __future__ import annotations

from collections.abc import Callable

# A scorer returns (score in [0,1], rationale, evidence list).
ScorerFn = Callable[..., tuple[float, str, list[str]]]

_REGISTRY: dict[str, ScorerFn] = {}


class MetricSkipped(Exception):
    """Raised by a scorer that cannot run (e.g. no Vertex creds for the judge).

    The runner omits a skipped metric from the weighted score and gate rather
    than failing the whole run, so the service is still exercisable offline.
    """

    def __init__(self, reason: str):
        super().__init__(reason)
        self.reason = reason


def scorer(name: str) -> Callable[[ScorerFn], ScorerFn]:
    """Decorator registering a scorer under `name`."""
    def _wrap(fn: ScorerFn) -> ScorerFn:
        _REGISTRY[name] = fn
        return fn
    return _wrap


def get_scorer(name: str) -> ScorerFn:
    if name not in _REGISTRY:
        raise KeyError(
            f"Unknown scorer '{name}'. Registered: {sorted(_REGISTRY)}. "
            "Add it as a built-in or in the agent's custom_tests.py."
        )
    return _REGISTRY[name]


def all_scorers() -> dict[str, ScorerFn]:
    return dict(_REGISTRY)
