"""Operational SLO scorers — gate on latency, cost, and reliability using the
CTA_ACTION-derived metrics. These are typically `lower_is_better` and use the
MetricSpec norm_min/norm_max bounds to normalise into a 0..1 quality score; the
runner passes raw_value through for audit.

- latency_slo         — execution_latency_ms (lower better).
- token_cost_budget   — token_total_count (lower better).
- response_success    — response_code == 200 (1.0/0.0).
- tool_latency_slo    — tool_latency_total (lower better).

Scorers return (score, rationale, evidence, extras{raw_value}).
"""

from __future__ import annotations

from .base import scorer


def _raw(metrics: dict, name: str, default: float = 0.0) -> float:
    value = (metrics or {}).get(name)
    try:
        return float(value)
    except (TypeError, ValueError):
        return default


@scorer("latency_slo")
def latency_slo(*, observation, case, metrics=None, **_):
    """Execution latency (ms). Normalisation handled by the runner via spec bounds."""
    ms = _raw(metrics, "execution_latency_ms", float(observation.latency_ms or 0))
    return ms, f"execution_latency_ms={ms:.0f}", [], {"raw_value": ms}


@scorer("token_cost_budget")
def token_cost_budget(*, observation, case, metrics=None, **_):
    """Total tokens consumed (proxy for cost). Lower is better."""
    total = _raw(metrics, "token_total_count",
                 float((observation.usage or {}).get("total_tokens", 0)))
    return total, f"token_total_count={total:.0f}", [], {"raw_value": total}


@scorer("response_success")
def response_success(*, observation, case, metrics=None, **_):
    """1.0 when the response code indicates success (2xx) and no error flag."""
    code = _raw(metrics, "response_code", 0.0)
    ok = (200 <= code < 300) and not observation.error
    return (1.0 if ok else 0.0), f"response_code={code:.0f} error={bool(observation.error)}", [], {"raw_value": code}


@scorer("tool_latency_slo")
def tool_latency_slo(*, observation, case, metrics=None, **_):
    """Total tool latency (ms). Lower is better."""
    total = _raw(metrics, "tool_latency_total", 0.0)
    return total, f"tool_latency_total={total:.0f}", [], {"raw_value": total}
