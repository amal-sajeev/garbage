const $ = (sel) => document.querySelector(sel);

async function loadHealth() {
  try {
    const h = await (await fetch("/api/health")).json();
    const pill = $("#health");
    const cred = h.credential_class ? ` · ${h.credential_class}` : "";
    pill.textContent = `${h.status} · vertex: ${h.vertex || "?"}${cred}`;
    pill.className = "pill " + (h.status === "ok" ? "ok" : "bad");
  } catch (e) {
    const pill = $("#health");
    pill.textContent = "health unreachable";
    pill.className = "pill bad";
  }
}

async function loadAgents() {
  const { agents } = await (await fetch("/api/agents")).json();
  const sel = $("#agent");
  sel.innerHTML = agents
    .map((a) => `<option value="${a.agent_id}">${a.name} (${a.cases} cases · v${a.dataset_version})</option>`)
    .join("");
  // Mirror the agents into the run-history filter, preserving the leading "All".
  const filter = $("#run-filter");
  if (filter) {
    filter.innerHTML = `<option value="__all__">All</option>` + agents
      .map((a) => `<option value="${a.agent_id}">${a.name}</option>`)
      .join("");
  }
}

function fmtDelta(d) {
  const cls = d >= 0 ? "delta-pos" : "delta-neg";
  const sign = d >= 0 ? "+" : "";
  return `<span class="${cls}">${sign}${d.toFixed(3)}</span>`;
}

let _allRuns = [];  // cache so the agent filter re-renders without refetching.

async function loadRuns() {
  const { runs } = await (await fetch("/api/runs")).json();
  _allRuns = runs || [];
  applyRunFilter();
}

function applyRunFilter() {
  const filter = $("#run-filter");
  const selected = filter ? filter.value : "__all__";
  const runs = (selected && selected !== "__all__")
    ? _allRuns.filter((r) => r.agent_id === selected)
    : _allRuns;

  const tbody = $("#runs tbody");
  if (!runs.length) {
    tbody.innerHTML = `<tr><td colspan="7" class="empty">${
      _allRuns.length ? "No runs for this agent — pick another or select All." : "No runs yet — start an evaluation above."
    }</td></tr>`;
    renderTrend(runs);
    return;
  }
  tbody.innerHTML = runs
    .map((r) => `<tr data-id="${r.run_id}">
      <td>${r.run_id.slice(0, 8)}</td><td>${r.agent_id}</td><td>${r.dataset_version}</td>
      <td>${r.weighted_score.toFixed(3)}</td><td>${fmtDelta(r.weighted_delta)}</td>
      <td class="${r.passed ? "pass" : "fail"}">${r.passed ? "PASS" : "FAIL"}</td>
      <td>${new Date(r.created_at).toLocaleString()}</td></tr>`)
    .join("");
  // Each run opens its own detail page, addressable by ?run=<uuid>.
  tbody.querySelectorAll("tr[data-id]").forEach((tr) =>
    tr.addEventListener("click", () => {
      location.href = `/run_detail.html?run=${encodeURIComponent(tr.dataset.id)}`;
    }));
  renderTrend(runs);
}

function spark(values) {
  // Unicode block sparkline; maps values to eight levels.
  if (!values.length) return "";
  const bars = "\u2581\u2582\u2583\u2584\u2585\u2586\u2587\u2588".split("");
  const lo = Math.min(...values), hi = Math.max(...values);
  const span = hi - lo || 1;
  return values.map((v) => bars[Math.min(7, Math.floor(((v - lo) / span) * 7))]).join("");
}

function renderTrend(runs) {
  const el = $("#trend");
  if (!el) return;
  if (!runs || runs.length < 2) { el.innerHTML = ""; return; }
  // Oldest -> newest for a left-to-right trend.
  const ordered = [...runs].reverse();
  const scores = ordered.map((r) => r.weighted_score);
  const deltas = ordered.map((r) => r.weighted_delta);
  const passRate = ordered.filter((r) => r.passed).length / ordered.length;
  el.innerHTML =
    `<span class="trend-item">score ${spark(scores)} ${num(scores[scores.length - 1])}</span>` +
    `<span class="trend-item">delta ${spark(deltas)} ${fmtDelta(deltas[deltas.length - 1])}</span>` +
    `<span class="trend-item">pass rate ${pct(passRate)} over ${ordered.length} runs</span>`;
}

async function showRun(id) {
  // Run detail now lives on its own page, addressable by ?run=<uuid>.
  location.href = `/run_detail.html?run=${encodeURIComponent(id)}`;
}

function pct(x) { return (x * 100).toFixed(1) + "%"; }
function num(x, d = 3) { return x === null || x === undefined ? "–" : Number(x).toFixed(d); }

function escapeHtml(s) {
  return String(s).replace(/[&<>"']/g, (ch) =>
    ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[ch]));
}

async function loadCaptures() {
  try {
    const { source, captures } = await (await fetch("/api/captures")).json();
    $("#capture-source").textContent = `· source: ${source}`;
    const rows = captures || [];
    $("#captures tbody").innerHTML = rows.length
      ? rows.map((c) => {
          const cid = c.case_id || c.Case_ID || "";
          const action = c.CTA_ACTION || c.action || "";
          const conf = c.AI_Confidence_Score ?? c.ai_confidence ?? "";
          const st = c.status || c.Status || "";
          return `<tr data-case="${cid}"><td>${cid}</td><td>${action}</td><td>${conf}</td><td>${st}</td></tr>`;
        }).join("")
      : `<tr><td colspan="4" class="muted">No captures yet (source: ${source}).</td></tr>`;
    document.querySelectorAll("#captures tbody tr[data-case]").forEach((tr) =>
      tr.addEventListener("click", () => showCapture(tr.dataset.case)));
  } catch (e) { $("#capture-source").textContent = "· captures unreachable"; }
}

async function showCapture(caseId) {
  const res = await fetch(`/api/captures/${caseId}`);
  const pre = $("#capture-detail");
  pre.textContent = JSON.stringify(await res.json(), null, 2);
  pre.hidden = false;
}

async function runEval() {
  // Hand off to the dedicated live run page which streams progress at all
  // levels (cases + each metric scoring in parallel) via Server-Sent Events.
  const agent = $("#agent").value;
  const reps = Number($("#reps").value) || 1;
  location.href = `/run.html?agent=${encodeURIComponent(agent)}&reps=${reps}`;
}

$("#run").addEventListener("click", runEval);

// Run-history agent filter. Selecting an agent to evaluate also narrows the
// history to that agent; "All" clears the filter.
const _agentSel = $("#agent");
const _runFilter = $("#run-filter");
if (_runFilter) _runFilter.addEventListener("change", applyRunFilter);
if (_agentSel && _runFilter) {
  _agentSel.addEventListener("change", () => {
    _runFilter.value = _agentSel.value;
    applyRunFilter();
  });
}

loadHealth();
// Load agents first so the filter is populated before runs render.
loadAgents().then(loadRuns);
loadCaptures();

// Deep link: /?run=<id> forwards to the standalone run detail page.
(function openDeepLinkedRun() {
  const id = new URLSearchParams(location.search).get("run");
  if (id) location.href = `/run_detail.html?run=${encodeURIComponent(id)}`;
})();
