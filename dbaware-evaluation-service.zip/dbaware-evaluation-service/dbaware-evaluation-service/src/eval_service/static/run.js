// Live run page — opens an SSE stream to /api/evaluate/stream and renders the
// evaluation as it happens: each case appears, its metrics fill in live (many
// scoring in parallel), then a final pass/fail banner links to the full detail.

const params = new URLSearchParams(location.search);
const agentId = params.get("agent") || params.get("agent_id") || "";
const reps = Number(params.get("reps") || params.get("judge_repetitions") || 1);
// When present, we attach to an already-running background run instead of
// starting a new one — set after start() and used to survive a tab refresh.
let streamId = params.get("stream") || "";

const $ = (s) => document.querySelector(s);
const state = {
  total: 0,
  done: 0,
  metrics: [],            // metric specs from run_started
  caseEls: {},            // caseId -> { root, metricsGrid, chips: {metric: el}, summary }
  runId: null,
};

function pill(text, cls) {
  const p = $("#run-pill");
  p.textContent = text;
  p.className = "pill " + (cls || "");
}

function num(x, d = 3) {
  return x === null || x === undefined ? "–" : Number(x).toFixed(d);
}

function escapeHtml(s) {
  return String(s).replace(/[&<>"']/g, (ch) =>
    ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[ch]));
}

function setProgress() {
  const pctDone = state.total ? (state.done / state.total) * 100 : 0;
  $("#progress-bar").style.width = pctDone + "%";
  $("#progress-text").textContent = state.total
    ? `${state.done} / ${state.total} cases complete`
    : "Starting…";
}

function onRunStarted(e) {
  state.total = e.total_cases;
  state.metrics = e.metrics || [];
  $("#m-agent").textContent = e.agent_id;
  $("#m-dataset").textContent = `${e.dataset_id} · v${e.dataset_version}`;
  $("#m-cases").textContent = e.total_cases;
  $("#m-conc").textContent = `${e.concurrency}× parallel`;
  $("#m-reps").textContent = e.judge_repetitions;
  pill("running", "running");
  setProgress();
}

function chipHtml(m) {
  const badges = [];
  if (m.judge) badges.push(`<span class="badge badge-judge">judge</span>`);
  if (m.critical) badges.push(`<span class="badge badge-critical">critical</span>`);
  return `<div class="mchip queued" data-metric="${escapeHtml(m.name)}">
      <div class="mchip-top">
        <span class="mchip-name">${escapeHtml(m.name)}</span>
        ${badges.join(" ")}
      </div>
      <div class="mchip-state"><span class="dot"></span><span class="txt">queued</span></div>
      <div class="mchip-meter"><span></span></div>
    </div>`;
}

function onCaseStarted(e) {
  const wrap = document.createElement("details");
  wrap.className = "live-case running";
  wrap.open = true;
  wrap.innerHTML = `
    <summary>
      <span class="case-status"><span class="spinner"></span></span>
      <strong>${escapeHtml(e.case_id)}</strong>
      <span class="muted">case ${e.index + 1} / ${e.total}</span>
      <span class="case-score muted"></span>
    </summary>
    <div class="live-case-body">
      <div class="observation muted">running agent…</div>
      <div class="metrics-grid">${state.metrics.map(chipHtml).join("")}</div>
    </div>`;
  $("#live-cases").prepend(wrap);
  const chips = {};
  wrap.querySelectorAll(".mchip").forEach((el) => { chips[el.dataset.metric] = el; });
  state.caseEls[e.case_id] = {
    root: wrap,
    obs: wrap.querySelector(".observation"),
    summary: wrap.querySelector(".case-score"),
    statusEl: wrap.querySelector(".case-status"),
    chips,
  };
}

function onObservation(e) {
  const c = state.caseEls[e.case_id];
  if (!c) return;
  const bits = [];
  if (e.model) bits.push(`model ${escapeHtml(e.model)}`);
  bits.push(`${e.tool_calls} tool call${e.tool_calls === 1 ? "" : "s"}`);
  bits.push(`${e.latency_ms} ms`);
  if (e.error) bits.push(`<span class="fail">error: ${escapeHtml(e.error)}</span>`);
  const preview = e.output_preview
    ? `<div class="obs-output">${escapeHtml(e.output_preview)}</div>` : "";
  c.obs.innerHTML = `<div class="obs-line">${bits.join(" · ")}</div>${preview}`;
  c.obs.classList.remove("muted");
}

function onMetricStarted(e) {
  const c = state.caseEls[e.case_id];
  if (!c || !c.chips[e.metric]) return;
  const chip = c.chips[e.metric];
  chip.className = "mchip running";
  chip.querySelector(".mchip-state .txt").textContent = e.judge ? "judging…" : "scoring…";
}

function onMetricDone(e) {
  const c = state.caseEls[e.case_id];
  if (!c || !c.chips[e.metric]) return;
  const chip = c.chips[e.metric];
  chip.className = "mchip " + (e.passed ? "ok" : "bad");
  const pct = Math.max(0, Math.min(1, Number(e.score) || 0)) * 100;
  chip.querySelector(".mchip-meter span").style.width = pct + "%";
  const extra = [];
  if (e.delta !== null && e.delta !== undefined) {
    const sign = e.delta >= 0 ? "+" : "";
    extra.push(`Δ${sign}${num(e.delta)}`);
  }
  if (e.unstable) extra.push(`<span class="badge badge-warn">unstable</span>`);
  chip.querySelector(".mchip-state").innerHTML =
    `<span class="dot"></span><span class="txt">${e.passed ? "PASS" : "FAIL"} · ${num(e.score)} / ${num(e.threshold)} ${extra.join(" ")}</span>`;
  if (e.rationale) chip.title = e.rationale;
}

function onMetricSkipped(e) {
  const c = state.caseEls[e.case_id];
  if (!c || !c.chips[e.metric]) return;
  const chip = c.chips[e.metric];
  chip.className = "mchip skipped";
  chip.querySelector(".mchip-state .txt").textContent = "skipped (offline)";
  chip.title = e.reason || "";
}

function onCaseDone(e) {
  const c = state.caseEls[e.case_id];
  state.done += 1;
  setProgress();
  if (!c) return;
  c.root.className = "live-case " + (e.passed ? "pass" : "fail");
  c.root.open = !e.passed; // keep failures expanded, collapse passes
  c.statusEl.innerHTML = e.passed
    ? `<span class="pass">✓</span>` : `<span class="fail">✗</span>`;
  c.summary.innerHTML =
    `<span class="${e.passed ? "pass" : "fail"}">${e.passed ? "PASS" : "FAIL"}</span> · score ${num(e.weighted_score)} · Δ ${num(e.weighted_delta)}`;
}

function onRunDone(e) {
  state.runId = e.run_id;
  pill(e.passed ? "PASS" : "FAIL", e.passed ? "ok" : "bad");
  $("#live-dot").style.display = "none";
  $("#final-panel").hidden = false;
  $("#final-banner").innerHTML =
    `<div class="final ${e.passed ? "pass" : "fail"}">
       <span class="final-verdict">${e.passed ? "PASS" : "FAIL"}</span>
       <span>weighted score <strong>${num(e.weighted_score)}</strong></span>
       <span>Δ delta <strong>${num(e.weighted_delta)}</strong></span>
     </div>`;
  $("#view-detail").href = `/run_detail.html?run=${encodeURIComponent(e.run_id)}`;
}

function onError(e) {
  pill("error", "bad");
  $("#live-dot").style.display = "none";
  $("#final-panel").hidden = false;

  // Dump the FULL error to the browser console so it can be copied verbatim and
  // shared. Includes the server traceback when present.
  const details = {
    when: new Date().toISOString(),
    page_url: location.href,
    agent_id: agentId,
    reps,
    stream_id: streamId || null,
    run_id: state.runId || null,
    status: e.status || null,
    error_type: e.error_type || null,
    detail: e.detail || null,
    traceback: e.traceback || null,
    raw_event: e,
  };
  // A single labelled group + a flat JSON blob (easiest to copy).
  console.group("%cEVALUATION RUN ERROR", "color:#f87171;font-weight:bold");
  console.error(details.detail || "run failed");
  if (details.traceback) console.error("Server traceback:\n" + details.traceback);
  console.log("Full error details (copy the JSON below):");
  console.log(JSON.stringify(details, null, 2));
  console.groupEnd();
  // Also stash it on window so it can be retrieved later from the console.
  window.__lastRunError = details;

  const tb = e.traceback
    ? `<pre class="err-trace">${escapeHtml(e.traceback)}</pre>` : "";
  $("#final-banner").innerHTML =
    `<div class="final fail"><span class="final-verdict">ERROR ${e.status || ""}</span>
       <span>${escapeHtml(e.detail || "run failed")}</span></div>
     ${tb}
     <div class="err-actions">
       <button id="copy-err" class="pill link">Copy full error</button>
       <span class="muted">Full details also logged to the browser console (F12) and window.__lastRunError</span>
     </div>`;
  const btn = $("#copy-err");
  if (btn) btn.addEventListener("click", () => {
    navigator.clipboard.writeText(JSON.stringify(details, null, 2))
      .then(() => { btn.textContent = "Copied ✓"; })
      .catch(() => { btn.textContent = "Copy failed — see console"; });
  });
}

const HANDLERS = {
  run_started: onRunStarted,
  case_started: onCaseStarted,
  observation: onObservation,
  metric_started: onMetricStarted,
  metric_done: onMetricDone,
  metric_skipped: onMetricSkipped,
  case_done: onCaseDone,
  run_done: onRunDone,
  error: onError,
};

// Attach an SSE stream to a background run id. The run itself is decoupled from
// this connection on the server, so a dropped stream (tab close / refresh /
// network blip) never cancels it — reconnecting just replays buffered events.
function attach(sid) {
  const es = new EventSource(`/api/evaluate/stream/${encodeURIComponent(sid)}`);
  es.onmessage = (msg) => {
    let ev;
    try { ev = JSON.parse(msg.data); }
    catch (err) {
      console.error("Could not parse SSE event:", err, "raw:", msg.data);
      return;
    }
    // Trace every event to the console so the full run timeline is inspectable.
    if (ev.type === "error") console.error("[run event] error:", ev);
    else console.debug("[run event]", ev.type, ev);
    const h = HANDLERS[ev.type];
    if (h) h(ev);
    if (ev.type === "run_done" || ev.type === "error") es.close();
  };
  es.onerror = (err) => {
    // The browser's EventSource auto-reconnects; on reconnect the server replays
    // the full event buffer, so state re-syncs. Only surface an error if the run
    // truly finished without us seeing a terminal event.
    console.warn("[run stream] EventSource connection error (will auto-retry):",
                 err, "readyState:", es.readyState);
    if (state.runId || !$("#final-panel").hidden) es.close();
  };
}

async function start() {
  // Reattaching to an existing background run (deep link / refresh).
  if (streamId) {
    attach(streamId);
    return;
  }
  if (!agentId) {
    onError({ status: 400, detail: "No agent specified. Return to the dashboard and start a run." });
    return;
  }
  try {
    const res = await fetch("/api/evaluate/start", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ agent_id: agentId, judge_repetitions: reps }),
    });
    if (!res.ok) {
      const detail = await res.text();
      onError({ status: res.status, detail: detail || "failed to start run" });
      return;
    }
    const data = await res.json();
    streamId = data.stream_id;
    // Persist the stream id in the URL so a refresh reattaches to the same
    // background run rather than starting a new one.
    const url = new URL(location.href);
    url.searchParams.set("stream", streamId);
    history.replaceState(null, "", url);
    attach(streamId);
  } catch (err) {
    onError({ detail: "Could not reach the evaluation service to start the run." });
  }
}

start();
