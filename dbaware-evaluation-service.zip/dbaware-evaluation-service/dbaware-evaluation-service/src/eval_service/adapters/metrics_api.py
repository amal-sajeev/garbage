"""Metrics adapter.

`MetricsClient.fetch(case_id) -> {metric_name: value}`. Two implementations:
- StubMetricsClient reads an agent's metrics_stub.json (default until the real
  metrics API is available).
- HttpMetricsClient hits the real API when METRICS_API_BASE is configured.
Swapping is one config flag; scorers never change.

The metrics API speaks in `CTA_ACTION` records — a logged AI action with a rich
`payload` (model config, confidence, tokens, tool calls, execution times). This
adapter flattens one CTA_ACTION into the flat numeric metric map the scorers and
gate consume, deriving latency/tool aggregates from the raw fields.
"""

from __future__ import annotations

import json
from datetime import datetime
from pathlib import Path
from typing import Any

import httpx

from ..config import Config

# Timestamp formats seen on Execution_Start_Time / Execution_End_Time.
_TS_FORMATS = (
    "%Y-%m-%d %H:%M:%S:%f",
    "%Y-%m-%d %H:%M:%S.%f",
    "%Y-%m-%d %H:%M:%S",
    "%Y-%m-%dT%H:%M:%S.%f%z",
    "%Y-%m-%dT%H:%M:%S%z",
)


def _num(value: Any) -> float | None:
    """Coerce a possibly-stringy numeric field to float; blanks -> None."""
    if value is None or value == "":
        return None
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


def _parse_ts(value: Any) -> datetime | None:
    if not value:
        return None
    for fmt in _TS_FORMATS:
        try:
            return datetime.strptime(str(value), fmt)
        except ValueError:
            continue
    return None


def _derive_metrics(action: dict) -> dict[str, float]:
    """Flatten a single CTA_ACTION into the numeric metric map used downstream."""
    payload = action.get("payload", {}) or {}
    metrics: dict[str, float] = {}

    def put(name: str, value: float | None) -> None:
        if value is not None:
            metrics[name] = value

    # Direct numeric fields.
    put("ai_confidence_score", _num(payload.get("AI_Confidence_Score")))
    put("token_input_count", _num(payload.get("Token_Input_Count")))
    put("token_output_count", _num(payload.get("Token_Output_Count")))
    put("response_code", _num(payload.get("Response_Code")))

    tin = metrics.get("token_input_count")
    tout = metrics.get("token_output_count")
    if tin is not None and tout is not None:
        put("token_total_count", tin + tout)

    # Execution latency derived from start/end timestamps.
    start = _parse_ts(payload.get("Execution_Start_Time"))
    end = _parse_ts(payload.get("Execution_End_Time"))
    if start and end:
        put("execution_latency_ms", (end - start).total_seconds() * 1000.0)

    # Tool-call aggregates.
    tool_calls = payload.get("Tool_Calls") or []
    call_count = 0.0
    latency_total = 0.0
    error_count = 0.0
    for call in tool_calls:
        call_count += _num(call.get("Call_Count")) or 0.0
        latency_total += _num(call.get("Tool_Latency")) or 0.0
        errors = [e for e in (call.get("Tool_Errors") or []) if e]
        error_count += len(errors)
    put("tool_call_count", call_count)
    put("tool_latency_total", latency_total)
    put("tool_error_count", error_count)

    return metrics


def _extract_action(entry: dict) -> dict:
    """Accept either a bare CTA_ACTION record or a {'CTA_ACTION': {...}} envelope."""
    if "CTA_ACTION" in entry:
        return entry["CTA_ACTION"]
    return entry


# Shared entrypoint so other adapters (e.g. the live capture service) can reuse
# the exact same flattening rules the scorers depend on.
derive_metrics = _derive_metrics


class StubMetricsClient:
    def __init__(self, stub_path: Path):
        data = json.loads(stub_path.read_text(encoding="utf-8")) if stub_path.exists() else {}
        # stub file: {"cases": {case_id: <CTA_ACTION envelope or record>}}
        self._by_case = data.get("cases", data)

    async def fetch(self, case_id: str, observation=None) -> dict[str, float]:
        entry = self._by_case.get(case_id)
        if not entry:
            return {}
        return _derive_metrics(_extract_action(entry))


class HttpMetricsClient:
    def __init__(self, base_url: str):
        self._base = base_url.rstrip("/")

    async def fetch(self, case_id: str, observation=None) -> dict[str, float]:
        async with httpx.AsyncClient(timeout=30.0) as client:
            resp = await client.get(f"{self._base}/metrics", params={"case_id": case_id})
            resp.raise_for_status()
            return _derive_metrics(_extract_action(resp.json()))


def build_metrics_client(stub_path: Path, source_override: str | None = None):
    """Select the metrics source: capture (live) | http | stub.

    - capture: derive a CTA_ACTION from each live agent Observation (no DB / no
      external metrics API). This is what lets us run the sample agents and test
      the eval service standalone.
    - http: the real CTA_ACTION metrics API (METRICS_API_BASE).
    - stub: the agent's metrics_stub.json.

    ``source_override`` (from agent.yaml) takes precedence over the global
    METRICS_SOURCE env var.
    """
    source = (source_override or Config.METRICS_SOURCE or "").lower()
    if source == "capture":
        from .capture import CaptureMetricsClient, capture_store
        return CaptureMetricsClient(capture_store)
    if source == "http" or (not source and Config.METRICS_API_BASE):
        if not Config.METRICS_API_BASE:
            raise RuntimeError("METRICS_SOURCE=http requires METRICS_API_BASE to be set.")
        return HttpMetricsClient(Config.METRICS_API_BASE)
    return StubMetricsClient(stub_path)
