"""Capture service: turns each live agent run into a CTA_ACTION.

Instead of reading a stub file or calling an external metrics database/API, this
derives a CTA_ACTION record from the Observation the target adapter already
returns (tool calls, token usage, latency, model, error/confidence). The derived
records are held in an in-memory store — so the sample agents can be run and the
evaluation service exercised end-to-end with no database connection.

The derived metric map is produced by the *same* `derive_metrics` flattening the
stub/HTTP clients use, so scorers and the gate are identical across sources.
"""

from __future__ import annotations

from datetime import datetime, timedelta, UTC

from ..models import Observation
from .metrics_api import derive_metrics

_TS_FMT = "%Y-%m-%d %H:%M:%S:%f"


class CaptureStore:
    """In-memory store of captured CTA_ACTION records (no persistence)."""

    def __init__(self) -> None:
        self._by_case: dict[str, dict] = {}
        self._history: list[dict] = []

    def put(self, case_id: str, action: dict) -> None:
        self._by_case[case_id] = action
        self._history.append(action)

    def get(self, case_id: str) -> dict | None:
        return self._by_case.get(case_id)

    def latest(self) -> dict[str, dict]:
        return dict(self._by_case)

    def history(self) -> list[dict]:
        return list(self._history)

    def clear(self) -> None:
        self._by_case.clear()
        self._history.clear()


# Module-level singleton so the FastAPI app can expose the captured records.
capture_store = CaptureStore()


def _confidence(observation: Observation) -> float:
    """Confidence the agent reported, else infer from success/error."""
    meta = observation.metadata or {}
    for key in ("ai_confidence", "confidence", "AI_Confidence_Score"):
        if key in meta:
            try:
                return float(meta[key])
            except (TypeError, ValueError):
                pass
    return 0.0 if observation.error else 1.0


def observation_to_cta_action(case_id: str, observation: Observation) -> dict:
    """Synthesize a CTA_ACTION envelope from a live agent Observation."""
    usage = observation.usage or {}
    start = datetime.now(UTC)
    end = start + timedelta(milliseconds=observation.latency_ms or 0)

    tool_calls = []
    for call in observation.tool_calls:
        tool_calls.append(
            {
                "Tool_Id": call.get("name") or call.get("Tool_Id") or "",
                "Call_Count": "1",
                "Tool_Param": str(call.get("args") or call.get("Tool_Param") or ""),
                "Tool_Latency": str(call.get("latency_ms", "")),
                "Tool_Errors": [observation.error] if observation.error else [""],
            }
        )

    return {
        "CTA_ACTION": {
            "action_id": f"capture-{case_id}",
            "plan_review_item_id": case_id,
            "timestamp": start.strftime(_TS_FMT),
            "actor_type": "AI_AGENT",
            "actor_email": "",
            "action_type": "AGENT_RUN",
            "target_entity_type": observation.target_id,
            "target_entity_id": case_id,
            "payload": {
                "Agent_Name": observation.target_id,
                "Activity_Type": "Preliminary_Research",
                "AI_Model_Name": observation.model or "",
                "AI_Rationale": "",
                "AI_Confidence_Score": _confidence(observation),
                "Token_Input_Count": str(usage.get("input_tokens", "")),
                "Token_Output_Count": str(usage.get("output_tokens", "")),
                "Tool_Calls": tool_calls,
                "Response_Code": "502" if observation.error else "200",
                "Response_Text": observation.error or "OK",
                "Execution_Start_Time": start.strftime(_TS_FMT),
                "Execution_End_Time": end.strftime(_TS_FMT),
                "Remarks": "captured from live agent run",
            },
        }
    }


class CaptureMetricsClient:
    """Derives metrics from the live Observation and records the CTA_ACTION."""

    def __init__(self, store: CaptureStore):
        self._store = store

    async def fetch(self, case_id: str, observation: Observation | None = None) -> dict[str, float]:
        if observation is None:
            existing = self._store.get(case_id)
            return derive_metrics(existing["CTA_ACTION"]) if existing else {}
        action = observation_to_cta_action(case_id, observation)
        self._store.put(case_id, action)
        return derive_metrics(action["CTA_ACTION"])
