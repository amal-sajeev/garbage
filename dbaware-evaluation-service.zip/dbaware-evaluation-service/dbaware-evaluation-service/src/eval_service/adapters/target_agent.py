"""Target adapter: replays a golden input against the agent's production API.

The default adapter talks to a hosted agent-service `/api/eval/*`
hooks (non-mutating), which return the standard Observation envelope. New agents
can register alternative adapters here without touching the runner.
"""

from __future__ import annotations

import time

import httpx

from ..config import Config
from ..models import Dataset, GoldenCase, Observation


class AgentEvalHookAdapter:
    """Calls a POST /api/eval/* endpoint on the agent service."""

    adapter_id = "agent_eval_hook"

    def __init__(self, base_url: str, endpoint: str):
        self._base_url = base_url.rstrip("/")
        self._endpoint = endpoint

    async def run_case(self, case: GoldenCase) -> Observation:
        url = f"{self._base_url}{self._endpoint}"
        # trust_env=False so a corporate HTTP(S)_PROXY does not intercept calls
        # to localhost agents (the proxy has no route back to 127.0.0.1).
        async with httpx.AsyncClient(timeout=120.0, trust_env=False) as client:
            try:
                resp = await client.post(url, json=case.input)
                resp.raise_for_status()
                return Observation.model_validate(resp.json())
            except httpx.HTTPStatusError as exc:
                return Observation(
                    target_id=case.id,
                    error=f"HTTP {exc.response.status_code}: {exc.response.text[:500]}",
                )
            except Exception as exc:
                return Observation(target_id=case.id, error=f"{type(exc).__name__}: {exc}")


class ScopingAnalyticsAdapter:
    """Adapter for the Scoping Analytics / Summary agent.

    That agent does not speak the Observation envelope: it exposes
    `POST /run-analytics-agent` taking `{planNumber, planName}` and returns
    `{plan_number, plan_name, session_id, analysis_report: {<report>: ScopingReport}}`
    where each ScopingReport is `{report_title, paragraphs:[…]}`. This adapter
    replays the plan identifiers and maps the returned report bundle into an
    Observation (`output` = the analysis_report bundle) so the standard scorers
    and the agent's custom structural/citation scorers can consume it.

    The agent reads its plan data from GCS and calls Vertex, so it is a hosted
    target (not runnable fully offline); point AGENT_SERVICE_BASE_URL or the
    agent.yaml `base_url` at wherever it is served.
    """

    adapter_id = "scoping_analytics"

    def __init__(self, base_url: str, endpoint: str):
        self._base_url = base_url.rstrip("/")
        self._endpoint = endpoint

    async def run_case(self, case: GoldenCase) -> Observation:
        url = f"{self._base_url}{self._endpoint}"
        inp = case.input or {}
        payload = {
            "planNumber": inp.get("planNumber") or inp.get("plan_number"),
            "planName": inp.get("planName") or inp.get("plan_name"),
        }
        # The summary agent runs three sequential/concurrent Gemini generations
        # over large plan payloads, so allow a generous timeout.
        start = time.perf_counter()
        async with httpx.AsyncClient(timeout=600.0, trust_env=False) as client:
            try:
                resp = await client.post(url, json=payload)
                resp.raise_for_status()
                data = resp.json()
            except httpx.HTTPStatusError as exc:
                return Observation(
                    target_id=case.id,
                    error=f"HTTP {exc.response.status_code}: {exc.response.text[:500]}",
                )
            except Exception as exc:
                return Observation(target_id=case.id, error=f"{type(exc).__name__}: {exc}")

        latency_ms = int((time.perf_counter() - start) * 1000)
        report = data.get("analysis_report", data) if isinstance(data, dict) else data

        # The agent has no MCP tools — it runs one Gemini generation per report
        # in the bundle. Surface each generated report as a "tool call" so the
        # trajectory/telemetry (and the live run page's "N tool calls") reflect
        # what the agent actually did instead of showing 0.
        tool_calls = []
        if isinstance(report, dict):
            for key, rep in report.items():
                title = rep.get("report_title") if isinstance(rep, dict) else None
                paras = rep.get("paragraphs") if isinstance(rep, dict) else None
                tool_calls.append({
                    "name": "generate_report",
                    "args": {"report": key, "title": title},
                    "paragraphs": len(paras) if isinstance(paras, list) else None,
                })

        return Observation(
            target_id=case.id,
            output=report,
            tool_calls=tool_calls,
            latency_ms=latency_ms,
            model="gemini-2.5-pro",
            metadata={
                "plan_number": data.get("plan_number") if isinstance(data, dict) else None,
                "plan_name": data.get("plan_name") if isinstance(data, dict) else None,
                "session_id": data.get("session_id") if isinstance(data, dict) else None,
                "report_count": len(tool_calls),
            },
        )


# Target adapters keyed by their `adapter_id`; a dataset's `target.adapter`
# selects one. New agents can register alternative adapters here without
# touching the runner.
_ADAPTERS = {
    AgentEvalHookAdapter.adapter_id: AgentEvalHookAdapter,
    ScopingAnalyticsAdapter.adapter_id: ScopingAnalyticsAdapter,
    "http": None,  # HttpAdapter needs the TargetSpec; handled below.
}


def build_target_adapter(dataset: Dataset, base_url: str | None = None):
    """Select and construct the target adapter from ``dataset.target``.

    - ``agent_eval_hook`` / ``scoping_analytics`` — the built-in Python
      adapters (backward-compatible).
    - ``http`` — the config-driven HTTP adapter; all request/response details
      come from the ``TargetSpec`` in ``dataset.json``.
    - Any adapter registered via ``@register_adapter("id")`` in the agent's
      ``custom_tests.py`` — the Python escape hatch for non-HTTP agents.
    """
    from .http_adapter import HttpAdapter, get_registered_adapter

    base = base_url or Config.AGENT_SERVICE_BASE_URL
    adapter_id = dataset.target.adapter

    # Config-driven HTTP adapter.
    if adapter_id == "http":
        return HttpAdapter(base, dataset.target.endpoint, dataset.target)

    # Custom Python adapter registered via @register_adapter.
    custom_cls = get_registered_adapter(adapter_id)
    if custom_cls is not None:
        return custom_cls(base, dataset.target.endpoint, dataset.target)

    # Built-in Python adapters.
    adapter_cls = _ADAPTERS.get(adapter_id, AgentEvalHookAdapter)
    return adapter_cls(base, dataset.target.endpoint)
