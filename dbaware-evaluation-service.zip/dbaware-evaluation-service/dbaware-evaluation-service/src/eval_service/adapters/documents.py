"""Document text-extraction layer.

Agents may return documents (PDF, DOCX, Markdown, JSON) rather than plain text.
This module extracts readable text from each supported kind so that the existing
scorers (token overlap, edit/embedding similarity, every LLM judge) and the new
configurable scorers operate on the *content*, not on raw base64/bytes.

Extraction is done **once** when the observation is received; the result is stored
in ``observation.metadata["extracted_text"]`` so every downstream scorer reuses
the same text without re-parsing.

PDF support uses ``pypdf`` and DOCX support uses ``python-docx``. Both are
imported lazily; if the library is absent the caller raises ``MetricSkipped``
(clean omit, matching the Vertex-offline contract) — text/markdown/json always
work with no extra dependency.
"""

from __future__ import annotations

import base64
import binascii
import json
import re
from pathlib import Path
from typing import Any

# Sniffing heuristics for ``content_type == "auto"``.
_MAGIC_PDF = b"%PDF"
_MAGIC_PK = b"PK"  # docx (and other zip-based OOXML)


def detect_content_type(value: Any, output_kind: str = "text") -> str:
    """Best-effort detection of the content kind from the raw value."""
    if value is None:
        return "text"
    if isinstance(value, (dict, list)):
        return "json"
    if isinstance(value, str):
        s = value.lstrip()
        if s.startswith("{") or s.startswith("["):
            return "json"
        if s.startswith("%PDF"):
            return "pdf"
        if output_kind in ("base64", "bytes"):
            return _detect_b64_or_bytes(value)
        if s.startswith("# ") or s.startswith("## "):
            return "markdown"
        return "text"
    if isinstance(value, (bytes, bytearray)):
        return _detect_bytes(value)
    return "text"


def _detect_b64_or_bytes(value: str) -> str:
    try:
        raw = base64.b64decode(value, validate=True)
    except (binascii.Error, ValueError):
        return "text"
    return _detect_bytes(raw)


def _detect_bytes(raw: bytes) -> str:
    if raw[:4] == _MAGIC_PDF:
        return "pdf"
    if raw[:2] == _MAGIC_PK:
        return "docx"
    try:
        raw.decode("utf-8")
        return "text"
    except UnicodeDecodeError:
        return "text"


def extract_text(
    value: Any,
    content_type: str = "auto",
    *,
    output_kind: str = "text",
    http_client: Any = None,
) -> str:
    """Extract readable text from an agent output of any supported kind.

    - text / markdown  -> passthrough.
    - json             -> pretty-printed JSON.
    - pdf              -> pypdf (lazy; text only).
    - docx             -> python-docx (lazy; paragraphs + tables).

    ``output_kind`` describes how ``value`` is encoded when it is a string:
    ``text`` (raw text), ``json`` (already JSON), ``base64`` (base64-encoded
    bytes), ``bytes`` (a bytes object), or ``url`` (fetch the document at the
    URL via the optional ``http_client``).
    """
    if value is None:
        return ""

    if content_type == "auto":
        content_type = detect_content_type(value, output_kind)

    if content_type == "text":
        return str(value)
    if content_type == "markdown":
        return _markdown_to_text(str(value))
    if content_type == "json":
        return _json_to_text(value)
    if content_type == "pdf":
        return _extract_pdf(value, output_kind, http_client)
    if content_type == "docx":
        return _extract_docx(value, output_kind, http_client)
    # Unknown kind — best effort.
    return _json_to_text(value)


# --------------------------------------------------------------------------- #
# Per-kind extractors
# --------------------------------------------------------------------------- #

def _json_to_text(value: Any) -> str:
    if isinstance(value, (dict, list)):
        return json.dumps(value, ensure_ascii=False, indent=2, default=str)
    if isinstance(value, str):
        try:
            return json.dumps(json.loads(value), ensure_ascii=False, indent=2)
        except (TypeError, ValueError):
            return value
    return str(value)


def _markdown_to_text(text: str) -> str:
    # Strip common Markdown syntax for cleaner token-overlap/judge comparison.
    text = re.sub(r"```[^\n]*\n?", "", text)  # fenced code blocks
    text = re.sub(r"`([^`]+)`", r"\1", text)  # inline code
    text = re.sub(r"^#{1,6}\s*", "", text, flags=re.M)  # headings -> plain
    text = re.sub(r"\*\*([^*]+)\*\*", r"\1", text)  # bold
    text = re.sub(r"\*([^*]+)\*", r"\1", text)  # italic
    text = re.sub(r"^[-*+]\s+", "", text, flags=re.M)  # bullet markers
    text = re.sub(r"^\d+\.\s+", "", text, flags=re.M)  # numbered list markers
    text = re.sub(r"\[([^\]]+)\]\([^)]+\)", r"\1", text)  # links -> label
    return text.strip()


def _to_bytes(value: Any, output_kind: str, http_client: Any) -> bytes | None:
    """Resolve ``value`` to raw bytes given its ``output_kind``."""
    if output_kind == "bytes":
        if isinstance(value, (bytes, bytearray)):
            return bytes(value)
        return None
    if output_kind == "base64":
        if isinstance(value, str):
            try:
                return base64.b64decode(value, validate=True)
            except (binascii.Error, ValueError):
                return None
        return None
    if output_kind == "url":
        return _fetch_url(value, http_client)
    if isinstance(value, (bytes, bytearray)):
        return bytes(value)
    if isinstance(value, str):
        return value.encode("utf-8")
    return None


def _fetch_url(url: Any, http_client: Any) -> bytes | None:
    if not isinstance(url, str) or not http_client:
        return None
    try:
        resp = http_client.get(url, follow_redirects=True, timeout=60.0)
        resp.raise_for_status()
        return resp.content
    except Exception:
        return None


def _extract_pdf(value: Any, output_kind: str, http_client: Any) -> str:
    raw = _to_bytes(value, output_kind, http_client)
    if raw is None:
        return ""
    try:
        from pypdf import PdfReader
    except ImportError as exc:
        raise _DocUnavailable(
            "pypdf is not installed; PDF scorers will be skipped. "
            "Install pypdf to enable PDF support."
        ) from exc
    try:
        reader = PdfReader(io_from_bytes(raw))
        pages = []
        for page in reader.pages:
            pages.append(page.extract_text() or "")
        return "\n\n".join(p for p in pages if p.strip())
    except Exception:
        return ""


def _extract_docx(value: Any, output_kind: str, http_client: Any) -> str:
    raw = _to_bytes(value, output_kind, http_client)
    if raw is None:
        return ""
    try:
        import docx
    except ImportError as exc:
        raise _DocUnavailable(
            "python-docx is not installed; DOCX scorers will be skipped. "
            "Install python-docx to enable DOCX support."
        ) from exc
    try:
        document = docx.Document(io_from_bytes(raw))
        parts: list[str] = []
        for para in document.paragraphs:
            if para.text.strip():
                parts.append(para.text)
        for table in document.tables:
            for row in table.rows:
                cells = [c.text.strip() for c in row.cells]
                parts.append("\t".join(cells))
        return "\n\n".join(parts)
    except Exception:
        return ""


def io_from_bytes(raw: bytes):
    """Wrap raw bytes in a seekable buffer (io.BytesIO)."""
    import io

    return io.BytesIO(raw)


class _DocUnavailable(Exception):
    """Raised when a document-parsing library is missing.

    The adapter/scorer catches this and converts it to ``MetricSkipped`` so
    document metrics are omitted (not failed) when the lib is absent.
    """


# --------------------------------------------------------------------------- #
# Structural accessors for the document-aware scorers (heading/table checks)
# --------------------------------------------------------------------------- #

def parse_headings(text: str, content_type: str = "auto") -> list[str]:
    """Return headings/section titles from a document.

    Markdown ``# Heading`` lines and docx paragraph styles are recognised.
    """
    if content_type == "auto":
        content_type = detect_content_type(text, "text")
    if content_type == "markdown":
        return re.findall(r"^(#{1,6})\s+(.+)$", text, flags=re.M)
    # For text/other, treat lines that look like short title lines as headings.
    return re.findall(r"^(#{1,6}\s+.+|[A-Z][A-Za-z0-9 .\-]{2,80})$", text, flags=re.M)


def parse_markdown_sections(text: str) -> dict[str, str]:
    """Split markdown into ``{heading: body}`` by ``#`` headings."""
    sections: dict[str, str] = {}
    current, body = None, []
    for line in text.splitlines():
        m = re.match(r"^(#{1,6})\s+(.+)$", line)
        if m:
            if current is not None:
                sections[current] = "\n".join(body).strip()
            current = m.group(2).strip()
            body = []
        elif current is not None:
            body.append(line)
    if current is not None:
        sections[current] = "\n".join(body).strip()
    return sections


def load_golden_file(path_or_data_url: str, agent_folder: Path) -> str:
    """Resolve a golden_file reference to text.

    Accepts a path relative to the agent folder, or a ``data:<ctype>;base64,...``
    data URL.
    """
    if path_or_data_url.startswith("data:"):
        # data:<content-type>;base64,<payload>
        m = re.match(r"data:([^;]+);base64,(.+)", path_or_data_url, re.S)
        if not m:
            return path_or_data_url
        ctype = m.group(1)
        raw = base64.b64decode(m.group(2))
        if "pdf" in ctype:
            return extract_text(raw, "pdf")
        if "msword" in ctype or "officedocument" in ctype:
            return extract_text(raw, "docx")
        return raw.decode("utf-8", errors="replace")
    p = agent_folder / path_or_data_url
    if p.exists():
        content = p.read_bytes()
        if path_or_data_url.lower().endswith(".pdf"):
            return extract_text(content, "pdf")
        if path_or_data_url.lower().endswith(".docx"):
            return extract_text(content, "docx")
        return content.decode("utf-8", errors="replace")
    return path_or_data_url
