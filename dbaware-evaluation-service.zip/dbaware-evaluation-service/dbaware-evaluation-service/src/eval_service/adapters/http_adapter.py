"""Config-driven HTTP target adapter.

Describes the HTTP request and response mapping entirely from ``TargetSpec``
config (in ``dataset.json``), so an engineer can wire up a call to any agent
service without writing Python. Supports:

- Any HTTP method (GET/POST/PUT/PATCH/DELETE).
- Headers (static or templated from env/input).
- Auth (bearer / basic / api_key_header / api_key_query) — secrets from env only.
- Query params and body templated from ``case.input`` and env vars.
- Response mapping via dotted paths into JSON (or raw text) into the
  ``Observation`` envelope.
- Document content types (pdf/docx/markdown/json) with automatic text
  extraction so all scorers work on documents out of the box.

Template syntax: ``${env.VAR_NAME}`` and ``${input.dotted.path}``.
"""

from __future__ import annotations

import contextlib
import os
import re
import time
from typing import Any

import httpx

from ..models import GoldenCase, Observation, TargetSpec
from .documents import extract_text, detect_content_type, _DocUnavailable

_TEMPLATE_RE = re.compile(r"\$\{(env|input)\.([a-zA-Z0-9_.]+)\}")


def _resolve_template(value: Any, case_input: dict[str, Any]) -> Any:
    """Recursively substitute ${env.VAR} and ${input.path} in strings/dicts/lists."""
    if isinstance(value, str):
        def _sub(m: re.Match) -> str:
            scope, path = m.group(1), m.group(2)
            if scope == "env":
                return os.environ.get(path, "")
            if scope == "input":
                return str(_dotted(case_input, path))
            return m.group(0)
        return _TEMPLATE_RE.sub(_sub, value)
    if isinstance(value, dict):
        return {k: _resolve_template(v, case_input) for k, v in value.items()}
    if isinstance(value, list):
        return [_resolve_template(v, case_input) for v in value]
    return value


def _dotted(obj: dict[str, Any], path: str) -> Any:
    """Look up a dotted path in a nested dict/list, returning None if missing."""
    cur: Any = obj
    for part in path.split("."):
        if isinstance(cur, dict):
            cur = cur.get(part)
        elif isinstance(cur, list):
            try:
                cur = cur[int(part)]
            except (ValueError, IndexError):
                return None
        else:
            return None
    return cur


def _set_dotted(obj: dict[str, Any], path: str, value: Any) -> None:
    """Set a nested dict value via a dotted path (creates intermediate dicts)."""
    parts = path.split(".")
    cur = obj
    for part in parts[:-1]:
        if part not in cur or not isinstance(cur[part], dict):
            cur[part] = {}
        cur = cur[part]
    cur[parts[-1]] = value


def _build_headers(target: TargetSpec, case_input: dict[str, Any]) -> dict[str, str]:
    headers = _resolve_template(target.headers, case_input) or {}
    if target.auth:
        auth = target.auth
        token = os.environ.get(auth.get("token_env", ""), "")
        atype = auth.get("type", "")
        if atype == "bearer" and token:
            headers["Authorization"] = f"Bearer {token}"
        elif atype == "api_key_header":
            hname = auth.get("header", "X-API-Key")
            headers[hname] = token
        elif atype == "basic":
            user = os.environ.get(auth.get("username_env", ""), "")
            pwd = os.environ.get(auth.get("password_env", ""), "")
            import base64
            cred = base64.b64encode(f"{user}:{pwd}".encode()).decode()
            headers["Authorization"] = f"Basic {cred}"
    return headers


def _build_params(target: TargetSpec, case_input: dict[str, Any]) -> dict[str, str] | None:
    if not target.params:
        return None
    return _resolve_template(target.params, case_input)


def _build_body(target: TargetSpec, case_input: dict[str, Any]) -> tuple[Any, str | None]:
    """Return (content, content_type_header) for the request body."""
    if target.body is not None:
        body = _resolve_template(target.body, case_input)
        btype = target.body_type
        if btype == "json":
            return body, "application/json"
        if btype == "text":
            return str(body), "text/plain"
        if btype == "form":
            return body, "application/x-www-form-urlencoded"
        if btype == "raw":
            return body, None
        return body, "application/json"
    # Default: send case.input as JSON (backward-compatible).
    return case_input, "application/json"


def _build_auth_for_client(target: TargetSpec) -> httpx.Auth | None:
    """For api_key_query, we inject the key into params (handled in _build_params
    via templates). For other types, headers handle it. Return None — httpx auth
    is handled via headers here."""
    return None


class HttpAdapter:
    """Config-driven HTTP adapter — calls any agent HTTP endpoint.

    Selected by ``dataset.target.adapter: "http"``. All request/response
    details come from the ``TargetSpec`` in ``dataset.json``.
    """

    adapter_id = "http"

    def __init__(self, base_url: str, endpoint: str, target: TargetSpec | None = None):
        self._base_url = base_url.rstrip("/")
        self._endpoint = endpoint
        self._target = target or TargetSpec(adapter="http", endpoint=endpoint)

    async def run_case(self, case: GoldenCase) -> Observation:
        target = self._target
        url = f"{self._base_url}{self._endpoint}"
        case_input = case.input or {}

        headers = _build_headers(target, case_input)
        params = _build_params(target, case_input)
        content, content_type_hdr = _build_body(target, case_input)
        method = target.method.upper()
        timeout = target.timeout or 120.0
        trust_env = target.trust_env

        start = time.perf_counter()
        try:
            async with httpx.AsyncClient(
                timeout=timeout, trust_env=trust_env
            ) as client:
                kwargs: dict[str, Any] = {"headers": headers, "params": params}
                if content_type_hdr:
                    kwargs["headers"] = {**headers, "Content-Type": content_type_hdr}
                if method in ("POST", "PUT", "PATCH"):
                    if target.body_type == "form" and isinstance(content, dict):
                        kwargs["data"] = content
                    elif target.body_type == "text":
                        kwargs["content"] = content
                    elif target.body_type == "raw":
                        kwargs["content"] = content
                    else:
                        kwargs["json"] = content
                resp = await client.request(method, url, **kwargs)
                resp.raise_for_status()
        except httpx.HTTPStatusError as exc:
            return Observation(
                target_id=case.id,
                error=f"HTTP {exc.response.status_code}: {exc.response.text[:500]}",
                latency_ms=int((time.perf_counter() - start) * 1000),
            )
        except Exception as exc:
            return Observation(
                target_id=case.id,
                error=f"{type(exc).__name__}: {exc}",
                latency_ms=int((time.perf_counter() - start) * 1000),
            )

        latency_ms = int((time.perf_counter() - start) * 1000)
        return self._map_response(resp, case, target, latency_ms)

    def _map_response(
        self,
        resp: httpx.Response,
        case: GoldenCase,
        target: TargetSpec,
        latency_ms: int,
    ) -> Observation:
        mapping = target.response
        rm = mapping
        raw_body = resp.content
        parsed: Any = None
        is_json = False
        try:
            parsed = resp.json()
            is_json = True
        except Exception:
            parsed = resp.text

        def _path_lookup(path: str | None) -> Any:
            if not path:
                return None
            if is_json:
                return _dotted(parsed if isinstance(parsed, dict) else {"_": parsed}, path)
            return None

        output = _path_lookup(rm.output_path) if rm.output_path else parsed
        tool_calls = _path_lookup(rm.tool_calls_path) or []
        usage = _path_lookup(rm.usage_path) or {}
        model = _path_lookup(rm.model_path)
        resp_latency = _path_lookup(rm.latency_path)
        error = _path_lookup(rm.error_path)
        metadata = _path_lookup(rm.metadata_path) or {}

        if resp_latency:
            with contextlib.suppress(TypeError, ValueError):
                latency_ms = int(resp_latency)

        # Determine content type and extract document text if needed.
        content_type = rm.content_type
        output_kind = rm.output_kind
        raw_output: Any = None
        extracted_text: str | None = None

        if content_type == "auto":
            if rm.output_path:
                content_type = detect_content_type(output, output_kind)
            else:
                # No output_path: the whole response body is the output.
                ct_hdr = resp.headers.get("content-type", "")
                if "pdf" in ct_hdr:
                    content_type = "pdf"
                elif "msword" in ct_hdr or "officedocument" in ct_hdr:
                    content_type = "docx"
                elif "markdown" in ct_hdr:
                    content_type = "markdown"
                elif "json" in ct_hdr:
                    content_type = "json"
                else:
                    content_type = detect_content_type(output, output_kind)

        # For document types, extract text so text-based scorers work, and
        # preserve the raw bytes for document-structure scorers.
        if content_type in ("pdf", "docx"):
            if output_kind in ("base64", "bytes", "url") or isinstance(output, (bytes, bytearray)):
                raw_output = output
                try:
                    extracted_text = extract_text(output, content_type, output_kind=output_kind)
                except _DocUnavailable:
                    # Lib missing — keep raw output; text scorers will see raw bytes.
                    extracted_text = None
                if extracted_text is not None:
                    output = extracted_text
            elif isinstance(output, str) and output_kind == "text":
                # Already text-extracted by the agent itself.
                pass
        elif content_type == "markdown":
            # Keep markdown as-is; render_output_text handles it.
            pass

        meta = dict(metadata) if isinstance(metadata, dict) else {}
        meta["content_type"] = content_type
        if raw_output is not None:
            meta["raw_output"] = raw_output
        if extracted_text is not None:
            meta["extracted_text"] = extracted_text

        return Observation(
            target_id=case.id,
            output=output,
            tool_calls=tool_calls if isinstance(tool_calls, list) else [],
            usage=usage if isinstance(usage, dict) else {},
            model=model if isinstance(model, str) else None,
            latency_ms=latency_ms,
            metadata=meta,
            error=error if isinstance(error, str) and error else None,
        )


# --------------------------------------------------------------------------- #
# Adapter registry — the Python escape hatch for non-HTTP agents.
# --------------------------------------------------------------------------- #

_ADAPTER_REGISTRY: dict[str, type] = {}


def register_adapter(adapter_id: str):
    """Decorator: register a custom Python target adapter.

    Used in an agent's ``custom_tests.py`` (or a shared module imported there)
    to add an adapter that can't be described by the config-driven ``http``
    adapter — e.g. a direct SDK call, gRPC, or a local function.

    The adapter class must accept ``(base_url, endpoint, target)`` and implement
    ``async def run_case(self, case: GoldenCase) -> Observation``.
    """

    def _wrap(cls):
        _ADAPTER_REGISTRY[adapter_id] = cls
        return cls

    return _wrap


def get_registered_adapter(adapter_id: str) -> type | None:
    return _ADAPTER_REGISTRY.get(adapter_id)
