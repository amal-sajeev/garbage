"""Adapters that reach the outside world: the evaluation target and metrics API."""

from .target_agent import AgentEvalHookAdapter, ScopingAnalyticsAdapter, build_target_adapter
from .http_adapter import HttpAdapter, register_adapter, get_registered_adapter
from .metrics_api import build_metrics_client
from .capture import CaptureMetricsClient, capture_store
from .documents import extract_text, detect_content_type

__all__ = [
    "AgentEvalHookAdapter",
    "CaptureMetricsClient",
    "HttpAdapter",
    "ScopingAnalyticsAdapter",
    "build_metrics_client",
    "build_target_adapter",
    "capture_store",
    "detect_content_type",
    "extract_text",
    "get_registered_adapter",
    "register_adapter",
]
