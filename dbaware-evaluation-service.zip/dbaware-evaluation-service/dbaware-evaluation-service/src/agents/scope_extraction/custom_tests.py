"""Agent-specific (custom) scorers for the scope_extraction agent.

Dropped into the agent folder and auto-imported by the registry at startup. The
@scorer decorator registers the function under a name that dataset.json can then
reference. This is the extension point for bespoke, per-agent tests.
"""

from __future__ import annotations

import json

from eval_service.scorers.base import scorer


@scorer("identifier_passthrough")
def identifier_passthrough(*, observation, case, metrics=None, **_):
    """Every expected identifier must appear verbatim in the tool-call arguments.

    Stricter than tool_selection's fractional check: this is all-or-nothing on
    the identifiers the agent was given, catching silent dropping/mangling.
    """
    expected_values = case.expected.get("expected_values", [])
    if not expected_values:
        return 1.0, "no identifiers to check", []

    args_blob = json.dumps(observation.tool_calls, ensure_ascii=False, default=str).lower()
    missing = [v for v in expected_values if str(v).lower() not in args_blob]
    evidence = [f"{'✗ missing' if v in missing else '✓'} {v}" for v in expected_values]
    score = 0.0 if missing else 1.0
    rationale = "all identifiers passed through" if not missing else f"missing: {missing}"
    return score, rationale, evidence
