import sys
from pathlib import Path
import uvicorn

sys.path.insert(0, str(Path(__file__).resolve().parent / "src"))

from eval_service.main import app
from eval_service.config import Config

if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=Config.PORT)