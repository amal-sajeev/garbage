"""Tests for the config-driven HTTP adapter (adapters/http_adapter.py)."""

from __future__ import annotations

import pytest
import httpx

from eval_service.models import GoldenCase, TargetSpec, ResponseMapping
from eval_service.adapters.http_adapter import HttpAdapter, _resolve_template, _dotted


class TestResolveTemplate:
    def test_env_substitution(self, monkeypatch):
        monkeypatch.setenv("MY_TOKEN", "secret123")
        result = _resolve_template("Bearer ${env.MY_TOKEN}", {})
        assert result == "Bearer secret123"

    def test_input_substitution(self):
        result = _resolve_template("${input.query}", {"query": "hello"})
        assert result == "hello"

    def test_nested_input(self):
        result = _resolve_template("${input.data.topic}", {"data": {"topic": "finance"}})
        assert result == "finance"

    def test_dict_substitution(self):
        monkeypatch_env = {"TEST_KEY": "val"}
        result = _resolve_template({"key": "${env.TEST_KEY}", "q": "${input.query}"}, {"query": "hi"})
        # env won't resolve without monkeypatch in this test; just check input
        assert result["q"] == "hi"

    def test_no_template(self):
        assert _resolve_template("plain text", {}) == "plain text"


class TestDotted:
    def test_simple(self):
        assert _dotted({"a": 1}, "a") == 1

    def test_nested(self):
        assert _dotted({"a": {"b": {"c": 42}}}, "a.b.c") == 42

    def test_missing(self):
        assert _dotted({"a": 1}, "b") is None

    def test_list_index(self):
        assert _dotted({"items": [{"id": 1}, {"id": 2}]}, "items.1.id") == 2


class TestHttpAdapterRequestBuilding:
    @pytest.mark.asyncio
    async def test_post_json_default_body(self):
        """When body is not set, case.input is sent as JSON (back-compat)."""
        case = GoldenCase(id="t1", input={"query": "hello"})
        target = TargetSpec(
            adapter="http", endpoint="/test",
            response=ResponseMapping(output_path="output"),
        )
        adapter = HttpAdapter("http://localhost:9999", "/test", target)

        captured = {}

        async def mock_handler(request: httpx.Request) -> httpx.Response:
            captured["method"] = request.method
            captured["body"] = request.content
            captured["content_type"] = request.headers.get("content-type", "")
            return httpx.Response(200, json={"output": "result"})

        transport = httpx.MockTransport(mock_handler)
        client = httpx.AsyncClient(transport=transport)
        adapter._build_auth_for_client = lambda t: None  # no-op
        # Patch httpx.AsyncClient to use mock transport
        original_init = httpx.AsyncClient.__init__

        def patched_init(self, **kwargs):
            kwargs["transport"] = transport
            original_init(self, **kwargs)

        httpx.AsyncClient.__init__ = patched_init
        try:
            obs = await adapter.run_case(case)
        finally:
            httpx.AsyncClient.__init__ = original_init

        assert captured["method"] == "POST"
        assert b'"query"' in captured["body"]
        assert obs.output == "result"
        assert obs.error is None

    @pytest.mark.asyncio
    async def test_response_mapping_output_path(self):
        """Response mapping extracts output from a dotted path."""
        case = GoldenCase(id="t1", input={"topic": "finance"})
        target = TargetSpec(
            adapter="http",
            endpoint="/test",
            response=ResponseMapping(output_path="data.result", content_type="text"),
        )
        adapter = HttpAdapter("http://localhost:9999", "/test", target)

        async def mock_handler(request: httpx.Request) -> httpx.Response:
            return httpx.Response(200, json={"data": {"result": "extracted text"}})

        transport = httpx.MockTransport(mock_handler)
        original_init = httpx.AsyncClient.__init__

        def patched_init(self, **kwargs):
            kwargs["transport"] = transport
            original_init(self, **kwargs)

        httpx.AsyncClient.__init__ = patched_init
        try:
            obs = await adapter.run_case(case)
        finally:
            httpx.AsyncClient.__init__ = original_init

        assert obs.output == "extracted text"

    @pytest.mark.asyncio
    async def test_error_handling(self):
        """HTTP error is captured in observation.error."""
        case = GoldenCase(id="t1", input={"q": "test"})
        target = TargetSpec(adapter="http", endpoint="/test")
        adapter = HttpAdapter("http://localhost:9999", "/test", target)

        async def mock_handler(request: httpx.Request) -> httpx.Response:
            return httpx.Response(500, text="Internal Server Error")

        transport = httpx.MockTransport(mock_handler)
        original_init = httpx.AsyncClient.__init__

        def patched_init(self, **kwargs):
            kwargs["transport"] = transport
            original_init(self, **kwargs)

        httpx.AsyncClient.__init__ = patched_init
        try:
            obs = await adapter.run_case(case)
        finally:
            httpx.AsyncClient.__init__ = original_init

        assert obs.error is not None
        assert "500" in obs.error

    @pytest.mark.asyncio
    async def test_auth_bearer(self, monkeypatch):
        """Bearer auth injects Authorization header from env."""
        monkeypatch.setenv("TEST_TOKEN", "tok123")
        case = GoldenCase(id="t1", input={"q": "x"})
        target = TargetSpec(
            adapter="http",
            endpoint="/test",
            auth={"type": "bearer", "token_env": "TEST_TOKEN"},
        )
        adapter = HttpAdapter("http://localhost:9999", "/test", target)

        captured = {}

        async def mock_handler(request: httpx.Request) -> httpx.Response:
            captured["auth"] = request.headers.get("authorization", "")
            return httpx.Response(200, json={"output": "ok"})

        transport = httpx.MockTransport(mock_handler)
        original_init = httpx.AsyncClient.__init__

        def patched_init(self, **kwargs):
            kwargs["transport"] = transport
            original_init(self, **kwargs)

        httpx.AsyncClient.__init__ = patched_init
        try:
            await adapter.run_case(case)
        finally:
            httpx.AsyncClient.__init__ = original_init

        assert captured["auth"] == "Bearer tok123"
