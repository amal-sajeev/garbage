"""Integration test for Runner.evaluate with in-memory repo + stub adapters.

Exercises the full orchestration offline: target replay → metrics → scorers →
gate → persisted RunRecord. The LLM judge is monkeypatched at build_judge so no
Vertex call happens; deterministic scorers run for real.
"""

from __future__ import annotations

import pytest

from eval_service.models import (
    AgentConfig, Dataset, GoldenCase, MetricSpec, Observation,
)
from eval_service.registry import RegisteredAgent, Registry
from eval_service.repository.base import EvaluationRepository
from eval_service.runner import Runner


class InMemoryRepo(EvaluationRepository):
    def __init__(self):
        self.runs = {}
        self.baselines = {}
        self.labels = []

    def init_schema(self): ...
    def save_run(self, run): self.runs[run.run_id] = run
    def get_run(self, run_id): return self.runs.get(run_id)
    def list_runs(self, agent_id=None, limit=50): return list(self.runs.values())
    def get_baseline(self, agent_id, dataset_version, metric):
        return self.baselines.get((agent_id, dataset_version, metric))
    def set_baseline(self, agent_id, dataset_version, metric, value):
        self.baselines[(agent_id, dataset_version, metric)] = value
    def list_labels(self): return self.labels


class StubTarget:
    async def run_case(self, case):
        return Observation(
            target_id="t",
            output="AU-10001 Acme Corp inventory",
            tool_calls=[{"name": "get_application_data", "args": "AU-10001;Acme Corp", "error": None}],
            latency_ms=1000,
            usage={"input_tokens": 100, "output_tokens": 50},
        )


class StubMetrics:
    async def fetch(self, case_id, observation):
        return {"ai_confidence_score": 0.95, "response_code": 200}


@pytest.fixture
def registry_with_dataset(monkeypatch):
    dataset = Dataset(
        dataset_id="t", version="v1",
        metrics=[
            MetricSpec(name="tool_selection", type="deterministic", scorer="tool_selection",
                       weight=2.0, threshold=1.0),
            MetricSpec(name="faithfulness", type="llm_judge", scorer="faithfulness",
                       weight=3.0, threshold=0.8),
        ],
        cases=[GoldenCase(
            id="app_single_unit",
            input={"query": "Get AppCatalog data for AU-10001 at Acme Corp."},
            golden_output="AU-10001 Acme Corp inventory",
            expected={"expected_tool": "get_application_data", "expected_values": ["AU-10001", "Acme Corp"]},
            baseline_metrics={"tool_selection": 1.0, "faithfulness": 0.9},
        )],
    )
    reg = Registry()
    reg._agents = {"t": RegisteredAgent(folder=None, config=AgentConfig(agent_id="t", name="T"), dataset=dataset)}
    # Avoid touching a real metrics_stub file.
    monkeypatch.setattr(RegisteredAgent, "metrics_stub_path", property(lambda self: None))
    return reg


async def test_runner_end_to_end_with_mocked_judge(registry_with_dataset, monkeypatch):
    # Judge returns a passing verdict; deterministic tool_selection runs for real.
    from eval_service.scorers.vertex import JudgeVerdict

    class FakeJudge:
        def invoke(self, prompt):
            return JudgeVerdict(score=0.95, passed=False, rationale="ok", evidence=[])

    monkeypatch.setattr("eval_service.scorers.llm_judge.build_judge", lambda: FakeJudge())
    monkeypatch.setattr("eval_service.runner.build_target_adapter", lambda dataset, base_url: StubTarget())
    monkeypatch.setattr("eval_service.runner.build_metrics_client", lambda path, source_override=None: StubMetrics())

    repo = InMemoryRepo()
    runner = Runner(registry_with_dataset, repo)
    run = await runner.evaluate("t")

    assert run.run_id in repo.runs
    assert run.passed is True
    case = run.case_results[0]
    faith = next(s for s in case.scores if s.metric == "faithfulness")
    # Pass is re-applied in code from the score, not trusted from the model.
    assert faith.score == pytest.approx(0.95)
    assert faith.passed is True


async def test_runner_skips_judge_when_unavailable(registry_with_dataset, monkeypatch):
    def _raise():
        raise RuntimeError("no ADC")
    monkeypatch.setattr("eval_service.scorers.llm_judge.build_judge", _raise)
    monkeypatch.setattr("eval_service.runner.build_target_adapter", lambda dataset, base_url: StubTarget())
    monkeypatch.setattr("eval_service.runner.build_metrics_client", lambda path, source_override=None: StubMetrics())

    repo = InMemoryRepo()
    run = await Runner(registry_with_dataset, repo).evaluate("t")
    metrics = {s.metric for s in run.case_results[0].scores}
    # Judge metric omitted (skipped) but the deterministic one remains.
    assert "faithfulness" not in metrics
    assert "tool_selection" in metrics
