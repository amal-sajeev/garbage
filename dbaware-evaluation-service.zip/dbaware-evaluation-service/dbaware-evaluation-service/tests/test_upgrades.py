"""Tests for the round-2 upgrades: validation, concurrency, pagination,
retention, comparison, promotion, new scorers, and logging."""

from __future__ import annotations

import tempfile
from datetime import datetime, timedelta, UTC
from pathlib import Path

import pytest

from eval_service.models import (
    AgentConfig, Dataset, GoldenCase, MetricSpec, Observation,
    RunRecord,
)
from eval_service.scorers.base import MetricSkipped, get_scorer, all_scorers
from eval_service.repository.sqlite_repo import SqliteRepository


# --------------------------------------------------------------------------- #
# Registry validation
# --------------------------------------------------------------------------- #

class TestRegistryValidation:
    def test_validate_catches_unknown_scorer(self):
        from eval_service.registry import Registry, RegisteredAgent

        reg = Registry()
        bad_dataset = Dataset(
            dataset_id="test",
            version="1.0",
            metrics=[MetricSpec(name="m", type="deterministic", scorer="nonexistent_scorer")],
            cases=[GoldenCase(id="c1", input={})],
        )
        reg._agents = {
            "test": RegisteredAgent(
                folder=Path("."),
                config=AgentConfig(agent_id="test", name="Test"),
                dataset=bad_dataset,
            )
        }
        with pytest.raises(ValueError, match="unknown scorer 'nonexistent_scorer'"):
            reg.validate()

    def test_validate_catches_empty_cases(self):
        from eval_service.registry import Registry, RegisteredAgent

        reg = Registry()
        bad_dataset = Dataset(
            dataset_id="test",
            version="1.0",
            metrics=[MetricSpec(name="m", type="deterministic", scorer="contains")],
            cases=[],
        )
        reg._agents = {
            "test": RegisteredAgent(
                folder=Path("."),
                config=AgentConfig(agent_id="test", name="Test"),
                dataset=bad_dataset,
            )
        }
        with pytest.raises(ValueError, match="dataset has no cases"):
            reg.validate()

    def test_validate_passes_with_valid_config(self):
        from eval_service.registry import Registry, RegisteredAgent

        reg = Registry()
        good_dataset = Dataset(
            dataset_id="test",
            version="1.0",
            metrics=[MetricSpec(name="m", type="deterministic", scorer="contains", config={"terms": ["hello"]})],
            cases=[GoldenCase(id="c1", input={"q": "hello world"})],
        )
        reg._agents = {
            "test": RegisteredAgent(
                folder=Path("."),
                config=AgentConfig(agent_id="test", name="Test"),
                dataset=good_dataset,
            )
        }
        reg.validate()  # should not raise


# --------------------------------------------------------------------------- #
# Repository: cursor pagination + delete_old_runs
# --------------------------------------------------------------------------- #

class TestCursorPagination:
    def test_list_runs_with_before_cursor(self):
        with tempfile.TemporaryDirectory(ignore_cleanup_errors=True) as d:
            repo = SqliteRepository(str(Path(d) / "test.db"))
            repo.init_schema()
            # Insert 3 runs with different timestamps.
            for i in range(3):
                run = RunRecord(
                    run_id=f"run_{i}",
                    agent_id="test",
                    dataset_id="ds",
                    dataset_version="1.0",
                    weighted_score=0.5 + i * 0.1,
                    weighted_delta=0.0,
                    passed=True,
                    created_at=datetime(2026, 1, i + 1, tzinfo=UTC).isoformat(),
                )
                repo.save_run(run)
            # All 3 (newest first)
            all_runs = repo.list_runs(limit=10)
            assert len(all_runs) == 3
            assert all_runs[0]["run_id"] == "run_2"
            # Page 1: 2 runs
            page1 = repo.list_runs(limit=2)
            assert len(page1) == 2
            assert page1[0]["run_id"] == "run_2"
            assert page1[1]["run_id"] == "run_1"
            # Page 2: before the last item of page 1
            cursor = page1[-1]["created_at"]
            page2 = repo.list_runs(limit=2, before=cursor)
            assert len(page2) == 1
            assert page2[0]["run_id"] == "run_0"


class TestDeleteOldRuns:
    def test_delete_old_runs(self):
        with tempfile.TemporaryDirectory(ignore_cleanup_errors=True) as d:
            repo = SqliteRepository(str(Path(d) / "test.db"))
            repo.init_schema()
            now = datetime.now(UTC)
            old = now - timedelta(days=10)
            recent = now - timedelta(days=1)
            for rid, ts in [("old_run", old), ("new_run", recent)]:
                run = RunRecord(
                    run_id=rid, agent_id="t", dataset_id="d", dataset_version="1.0",
                    weighted_score=0.5, weighted_delta=0.0, passed=True,
                    created_at=ts.isoformat(),
                )
                repo.save_run(run)
            deleted = repo.delete_old_runs(5)
            assert deleted == 1
            remaining = repo.list_runs(limit=10)
            assert len(remaining) == 1
            assert remaining[0]["run_id"] == "new_run"

    def test_delete_old_runs_zero_days_noop(self):
        with tempfile.TemporaryDirectory(ignore_cleanup_errors=True) as d:
            repo = SqliteRepository(str(Path(d) / "test.db"))
            repo.init_schema()
            run = RunRecord(
                run_id="r1", agent_id="t", dataset_id="d", dataset_version="1.0",
                weighted_score=0.5, weighted_delta=0.0, passed=True,
                created_at=datetime.now(UTC).isoformat(),
            )
            repo.save_run(run)
            assert repo.delete_old_runs(0) == 0
            assert len(repo.list_runs(limit=10)) == 1


# --------------------------------------------------------------------------- #
# New scorers: rubric_multi + pdf_table_has
# --------------------------------------------------------------------------- #

class TestRubricMultiScorer:
    def test_skips_without_criteria(self):
        obs = Observation(target_id="t", output="text")
        case = GoldenCase(id="c1", input={})
        from eval_service.models import MetricSpec
        spec = MetricSpec(name="m", type="llm_judge", scorer="rubric_multi", config={})
        fn = get_scorer("rubric_multi")
        with pytest.raises(MetricSkipped, match=r"requires config\.criteria"):
            fn(observation=obs, case=case, spec=spec, judge_repetitions=1)

    def test_skips_offline(self):
        obs = Observation(target_id="t", output="text")
        case = GoldenCase(id="c1", input={})
        spec = MetricSpec(name="m", type="llm_judge", scorer="rubric_multi",
                          config={"criteria": [{"name": "tone", "rubric": "professional tone"}]})
        fn = get_scorer("rubric_multi")
        with pytest.raises(MetricSkipped, match="LLM judge unavailable"):
            fn(observation=obs, case=case, spec=spec, judge_repetitions=1)


class TestPdfTableHasScorer:
    def test_skips_without_pdfplumber(self):
        try:
            import pdfplumber  # noqa: F401
            pytest.skip("pdfplumber installed; skip test is for missing lib")
        except ImportError:
            pass
        obs = Observation(
            target_id="t",
            output=b"%PDF-1.4 test",
            metadata={"raw_output": b"%PDF-1.4 test"},
        )
        case = GoldenCase(id="c1", input={})
        spec = MetricSpec(name="m", type="deterministic", scorer="pdf_table_has",
                          config={"tables": [{"required_headers": ["A", "B"], "min_rows": 2}]})
        fn = get_scorer("pdf_table_has")
        with pytest.raises(MetricSkipped, match="pdfplumber is not installed"):
            fn(observation=obs, case=case, spec=spec)

    def test_no_tables_config_returns_pass(self):
        obs = Observation(target_id="t", output=b"")
        case = GoldenCase(id="c1", input={})
        spec = MetricSpec(name="m", type="deterministic", scorer="pdf_table_has", config={})
        fn = get_scorer("pdf_table_has")
        score, _, _ = fn(observation=obs, case=case, spec=spec)
        assert score == 1.0


# --------------------------------------------------------------------------- #
# Logging
# --------------------------------------------------------------------------- #

class TestLogging:
    def test_get_logger_returns_logger(self):
        from eval_service.structured_logging import get_logger
        log = get_logger("test")
        assert log.name == "test"
        assert log.level <= 20  # INFO or below

    def test_structured_formatter_includes_extras(self):
        import logging
        from eval_service.structured_logging import StructuredFormatter
        import json

        formatter = StructuredFormatter()
        record = logging.LogRecord(
            name="test", level=logging.INFO, pathname="", lineno=0,
            msg="test message", args=None, exc_info=None,
        )
        record.trace_id = "abc123"
        record.agent_id = "my_agent"
        output = formatter.format(record)
        parsed = json.loads(output)
        assert parsed["msg"] == "test message"
        assert parsed["trace_id"] == "abc123"
        assert parsed["agent_id"] == "my_agent"
        assert parsed["level"] == "INFO"


# --------------------------------------------------------------------------- #
# Config additions
# --------------------------------------------------------------------------- #

class TestConfigAdditions:
    def test_case_concurrency_default(self):
        from eval_service.config import Config
        assert Config.CASE_CONCURRENCY >= 1

    def test_run_retention_default(self):
        from eval_service.config import Config
        assert Config.RUN_RETENTION_DAYS >= 0

    def test_webhook_timeout_default(self):
        from eval_service.config import Config
        assert Config.WEBHOOK_TIMEOUT > 0


# --------------------------------------------------------------------------- #
# Per-agent metrics_source override
# --------------------------------------------------------------------------- #

class TestPerAgentMetricsSource:
    def test_agent_config_has_metrics_source(self):
        cfg = AgentConfig(agent_id="t", name="T", metrics_source="capture")
        assert cfg.metrics_source == "capture"

    def test_agent_config_metrics_source_defaults_none(self):
        cfg = AgentConfig(agent_id="t", name="T")
        assert cfg.metrics_source is None


# --------------------------------------------------------------------------- #
# New scorers registered
# --------------------------------------------------------------------------- #

class TestNewScorersRegistered:
    def test_rubric_multi_registered(self):
        assert "rubric_multi" in all_scorers()

    def test_pdf_table_has_registered(self):
        assert "pdf_table_has" in all_scorers()
