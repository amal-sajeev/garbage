"""Tests for the judge improvements: caching, reference-free, variance flag, pairwise."""

from __future__ import annotations

import pytest

from eval_service import scorers  # noqa: F401  (ensures registration)
from eval_service.config import Config
from eval_service.scorers import get_scorer
from eval_service.scorers.base import MetricSkipped
from eval_service.scorers import llm_judge
from eval_service.scorers.vertex import PairwiseVerdict


def _run(name, observation, case, **kw):
    return get_scorer(name)(observation=observation, case=case, metrics={}, **kw)


@pytest.fixture(autouse=True)
def _clear_cache():
    llm_judge.reset_cache()
    yield
    llm_judge.reset_cache()


def test_cache_memoises_identical_prompt(patch_judge, make_judge, observation, case, monkeypatch):
    """A single sample caches; a repeat metric with the same prompt reuses it."""
    monkeypatch.setattr(Config, "JUDGE_SWAP_ORDER", False)
    judge = patch_judge(make_judge([0.9]))
    _run("faithfulness", observation, case)
    calls_after_first = len(judge.prompts)
    _run("faithfulness", observation, case)  # same rendered prompt → cache hit
    assert len(judge.prompts) == calls_after_first


def test_reference_free_when_no_golden(patch_judge, make_judge, observation, case, monkeypatch):
    case.golden_output = None
    judge = patch_judge(make_judge([0.7]))
    score, _r, _e, _x = _run("faithfulness", observation, case)
    assert score == pytest.approx(0.7)
    assert "No reference answer" in judge.prompts[0]


def test_unstable_flag_set_on_high_variance(patch_judge, make_judge, observation, case, monkeypatch):
    monkeypatch.setattr(Config, "JUDGE_SWAP_ORDER", False)
    monkeypatch.setattr(Config, "JUDGE_MAX_VARIANCE", 0.05)
    patch_judge(make_judge([0.2, 1.0]))  # pvariance 0.16 > 0.05
    _score, _r, _e, extras = _run("faithfulness", observation, case, judge_repetitions=2)
    assert extras.get("unstable") is True


def test_stable_verdict_not_flagged(patch_judge, make_judge, observation, case, monkeypatch):
    monkeypatch.setattr(Config, "JUDGE_SWAP_ORDER", False)
    monkeypatch.setattr(Config, "JUDGE_MAX_VARIANCE", 0.05)
    patch_judge(make_judge([0.8, 0.82]))  # tiny variance
    _score, _r, _e, extras = _run("faithfulness", observation, case, judge_repetitions=2)
    assert not extras.get("unstable")


def test_pairwise_skips_without_golden(monkeypatch, observation, case):
    case.golden_output = None
    with pytest.raises(MetricSkipped):
        _run("pairwise_vs_golden", observation, case)


def test_pairwise_prefers_agent(monkeypatch, observation, case):
    class FakePairwiseJudge:
        def invoke(self, prompt):
            return PairwiseVerdict(winner="A", score=0.9, rationale="A better", evidence=[])

    monkeypatch.setattr("eval_service.scorers.llm_judge.build_judge_for", lambda schema: FakePairwiseJudge())
    monkeypatch.setattr(Config, "JUDGE_SWAP_ORDER", False)
    score, _r, _e, _x = _run("pairwise_vs_golden", observation, case)
    assert score == pytest.approx(0.9)
