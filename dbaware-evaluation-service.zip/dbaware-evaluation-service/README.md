# scope-eval

Monorepo for the dbaware monitoring platform. The platform services are
**Python** (FastAPI); the Liquibase schema module is **Maven** (Java). The
repository is organised into three sub-modules:

```
scope-eval/                                # repo root (this folder)
├── dbaware-action-service/                # action service — placeholder (not yet built)
├── dbaware-evaluation-service/            # CTNA Evaluation Service (Python/FastAPI) — the LLM-as-a-judge
└── dbaware-evaluation-service-liquibase/  # Maven Liquibase module — Postgres (CloudSQL) schema
```

## Sub-modules

### dbaware-evaluation-service
The standalone LLM-as-a-judge that scores production agents against a versioned
golden set, computes a weighted pass/fail gate and delta vs baseline, and
persists runs to SQL. See [dbaware-evaluation-service/README.md](dbaware-evaluation-service/README.md)
and its [docs/](dbaware-evaluation-service/docs).

Quick start (from `dbaware-evaluation-service/`):

```powershell
./scripts/run_eval_service.ps1        # service on :4002
./scripts/run_sample_agent.ps1        # offline sample agent on :4010
```

### dbaware-evaluation-service-liquibase
The single source of truth for the Postgres schema (`runs`, `baselines`,
`labels`) that the evaluation service reads/writes. The schema is applied with
Liquibase (Maven), not by the service at startup.

It uses the **multi-user** layout: changesets are grouped by the database account
that owns them, selected via the `context` attribute on each `<include>` in
`src/main/resources/db/master-changelog.xml`:

- `DBAWARE_EVAL_OWNER` — DDL owner; creates the tables in its own schema and
  grants DML to the runtime user.
- `DBAWARE_EVAL_USER` — runtime account; owns any future views/functions in its
  own schema.

Connection details per environment live in
`src/main/resources/env_config/<env>.env` (`DB_URL`, `PGCONNECTION`, `PGADMIN`).
The schemas and roles are provisioned out of band by a DBA; Liquibase only
manages objects within them. Deploy runs `liquibase update` once per account, in
context order (see the CICD `liquibase_build_deploy` workflow). Locally, with the
Cloud SQL Auth Proxy on `127.0.0.1:5432` and the owner password exported:

```powershell
cd dbaware-evaluation-service-liquibase
mvn -s settings.xml org.liquibase:liquibase-maven-plugin:update `
  -Dliquibase.url="jdbc:postgresql://127.0.0.1:5432/cta-postgresql01" `
  -Dliquibase.username=DBAWARE_EVAL_OWNER `
  -Dliquibase.password="$env:DBAWARE_EVAL_OWNER_PASSWORD" `
  -Dliquibase.changeLogFile="db/master-changelog.xml" `
  -Dliquibase.contexts=DBAWARE_EVAL_OWNER `
  -Dliquibase.searchPath="src/main/resources"
```

### dbaware-action-service
Placeholder for a future action service. See
[dbaware-action-service/README.md](dbaware-action-service/README.md).

## Development environment

A single Python virtualenv at the repo root (`scope-eval/.venv`) currently serves
the evaluation service; its run scripts locate the venv at either the module root
or the repo root. Dependencies are tracked per module (e.g.
`dbaware-evaluation-service/requirements.txt`). The Liquibase module is built
with Maven (Java 17) and has no Python dependency.
