# dbaware-action-service

Placeholder module for the dbaware **action service**.

This sub-module is part of the `scope-eval` repository restructure:

```
scope-eval/                       # repo root
├── dbaware-action-service/       # (this module) — not yet implemented
├── dbaware-evaluation-service/   # the CTNA evaluation service (Python/FastAPI)
└── dbaware-evaluation-service-liquibase/ # Maven Liquibase module — Postgres schema
```

The action service does not exist yet. When implemented it will be a Python
service (the platform services are Python; the Liquibase schema module is
Maven). Add its code, its own `requirements.txt`, and a `scripts/` launcher
here, following the same conventions as `dbaware-evaluation-service`. If it
needs its own tables, add a separate `dbaware-action-service-liquibase` Maven
module following the same multi-user layout.
