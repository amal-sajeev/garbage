import liquibase.change.Change;
import liquibase.change.core.AddForeignKeyConstraintChange;
import liquibase.changelog.ChangeSet;
import liquibase.changelog.DatabaseChangeLog;
import liquibase.exception.LiquibaseException;
import liquibase.parser.ChangeLogParser;
import liquibase.parser.ChangeLogParserFactory;
import liquibase.resource.ClassLoaderResourceAccessor;
import org.junit.jupiter.api.Test;

import java.lang.reflect.Method;
import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.fail;
 
class LiquibaseChangelogUnitTest {

    // List of change types to ignore for schema name check.
    // These are either not schema-specific or contain raw SQL where the schema is expected to be qualified inside the script.
    private static final List<String> IGNORED_CHANGE_TYPE_NAMES = Arrays.asList(
            "liquibase.change.core.SqlChange",
            "liquibase.change.core.SqlFileChange",
            "liquibase.change.core.CreateProcedureChange",
            "liquibase.change.core.CreateChangeLogTableChange",
            "liquibase.change.core.CreateChangeLogLockTableChange",
            "liquibase.change.core.StopChange",
            "liquibase.change.core.TagDatabaseChange",
            "liquibase.change.core.EmptyChange",
            "liquibase.change.custom.CustomChangeWrapper",
            "liquibase.change.core.RawSQLChange" // For <sql> tags
    );

    private void validateChangeLogAndSchemaNames(String path) throws LiquibaseException {
        ChangeLogParser parser = ChangeLogParserFactory.getInstance()
                .getParser(path, new ClassLoaderResourceAccessor());

        DatabaseChangeLog changeLog = parser.parse(path, null, new ClassLoaderResourceAccessor());

        assertNotNull(changeLog, "Changelog must not be null: " + path);
        assertFalse(changeLog.getChangeSets().isEmpty(), "Changelog must contain at least one changeset: " + path);

        for (ChangeSet changeSet : changeLog.getChangeSets()) {
            for (Change change : changeSet.getChanges()) {
                if (IGNORED_CHANGE_TYPE_NAMES.contains(change.getClass().getName())) {
                    continue;
                }

                // Special handling for changes that don't have a standard `getSchemaName()` method.
                if (change instanceof AddForeignKeyConstraintChange) {
                    AddForeignKeyConstraintChange fkChange = (AddForeignKeyConstraintChange) change;
                    assertSchemaAttributePresent(fkChange.getBaseTableSchemaName(), changeSet, change, "baseTableSchemaName");
                    assertSchemaAttributePresent(fkChange.getReferencedTableSchemaName(), changeSet, change, "referencedTableSchemaName");
                    continue;
                }

                // For most change types, we expect a `getSchemaName()` method.
                try {
                    Method getSchemaNameMethod = change.getClass().getMethod("getSchemaName");
                    String schemaName = (String) getSchemaNameMethod.invoke(change);
                    assertSchemaAttributePresent(schemaName, changeSet, change, "schemaName");
                } catch (NoSuchMethodException e) {
                    // If a change type doesn't have `getSchemaName` and isn't ignored, we fail.
                    // This forces a developer to explicitly handle or ignore the new change type.
                    fail(String.format(
                            "Change type '%s' in changeset '%s' is not handled by the schema validation test. " +
                            "Please update LiquibaseChangelogUnitTest to ignore it or check its schema attribute.",
                            change.getClass().getSimpleName(),
                            changeSet.toString(false)
                    ));
                } catch (Exception e) {
                    fail(String.format(
                            "Error while checking schemaName for change type '%s' in changeset '%s'.",
                            change.getClass().getSimpleName(),
                            changeSet.toString(false)
                    ), e);
                }
            }
        }
    }

    private void assertSchemaAttributePresent(String schemaName, ChangeSet changeSet, Change change, String attributeName) {
        String message = String.format(
                "Attribute '%s' is missing or empty for change type '%s' in changeset '%s'. File: %s",
                attributeName,
                change.getClass().getSimpleName(),
                changeSet.toString(false),
                changeSet.getFilePath()
        );
        assertNotNull(schemaName, message);
        assertFalse(schemaName.trim().isEmpty(), message);
    }


    @Test
    void testChangelogShouldLoadAndHaveSchemaNames() throws Exception {
        // This test validates that all changesets included from the master changelog
        // adhere to the convention of specifying a schemaName.
        validateChangeLogAndSchemaNames("db/master-changelog.xml");
    }

}
