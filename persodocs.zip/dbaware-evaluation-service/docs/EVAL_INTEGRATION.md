# Eval Service as CI/CD Gate: Complete Integration Guide

**Date:** September 3, 2026  
**Status:** Ready to integrate into CI/CD pipelines

---

## Table of Contents

1. [Quick Answer (30 seconds)](#quick-answer)
2. [5-Minute Overview](#5-minute-overview)
3. [Architecture Patterns](#architecture-patterns)
4. [Complete API Reference](#api-reference)
5. [Integration Examples](#integration-examples)
6. [Practical Walkthrough](#practical-walkthrough)
7. [Performance & Cost](#performance--cost)
8. [Troubleshooting](#troubleshooting)
9. [FAQ](#faq)

---

## Quick Answer

**Your Question:** How can the eval service be integrated into a CI/CD pipeline for another repository as an evaluation gate?

**Answer:** The eval service exposes REST APIs that your CI/CD job calls:

```bash
# 1. Trigger evaluation
curl -X POST https://eval-service.example.com/api/evaluate/start \
  -d '{"agent_id":"my-agent"}'
# Returns: {"stream_id":"abc-123"}

# 2. Poll for results
curl https://eval-service.example.com/api/runs/abc-123
# Returns: {"passed":true, "weighted_score":0.92, ...}

# 3. Exit 0 if passed, Exit 1 if failed
# CI/CD interprets exit code → Deploy or Block
```

**That's it.** Copy `ci_gate.py` to your repo, add a GitHub Actions workflow, done.

---

## 5-Minute Overview

### What It Does

```
Your Agent Code       Eval Service          Judge (LLM)
      │                    │                    │
      ├─ agent endpoint ──→ │ Run 50 test cases │
      │                     ├────────────────→  │
      │                     │  Score each one   │ (Vertex AI)
      │                     │←────────────────  │
      │                     ├─ Compute gate     │
      │                     ├─ Store results    │
      │←────────────────────────────────────   │
      │  {passed:true, score:0.92}             │
```

### Deployment Options

**Option A: Cloud Run (Easiest)**
```bash
cd scope-eval/dbaware-evaluation-service
gcloud run deploy eval-service --source . --allow-unauthenticated
```

**Option B: GKE (Recommended)**
```bash
helm install eval-service ./helm-chart --namespace eval
```

**Option C: Docker Compose (Local)**
```bash
docker-compose up -d
# Service: http://localhost:4002
```

### Integration (5 Steps)

**1. Copy gate script**
```bash
cp dbaware-evaluation-service/scripts/ci_gate.py my-agent-repo/scripts/
```

**2. Add GitHub Actions workflow**
```yaml
# .github/workflows/eval-gate.yml
jobs:
  evaluate:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-python@v4
        with:
          python-version: "3.11"
      - run: pip install requests
      - run: python scripts/ci_gate.py ${{ github.repository }} \
          --eval-url https://eval-service.example.com
```

**3. Test locally**
```bash
python scripts/ci_gate.py my-agent --eval-url http://localhost:4002 -v
```

**4. Commit**
```bash
git add scripts/ci_gate.py .github/workflows/eval-gate.yml
git commit -m "feat: add evaluation gate"
```

**5. Push and watch CI/CD block degraded agents**

---

## Architecture: Centralized Service

**Setup:** One eval service for entire organization

```
Agent Repo 1 ──┐
Agent Repo 2 ──┼──→ Shared Eval Service ──→ Database
Agent Repo N ──┘                          ──→ Judge (Vertex AI)
```

**Benefits:**
- ✓ Single source of truth for quality standards
- ✓ Shared judge (consistent scoring across agents)
- ✓ Shared trends (all agents in one database for analysis)
- ✓ Cost-effective (one service for organization)
- ✓ Easiest to operate and maintain
- ✓ All agents use same URL: `https://eval-service.example.com`

**Deployment:**
```bash
# Deploy once for entire organization
gcloud run deploy eval-service --source .

# All agent repos reference same service
--eval-url https://eval-service.example.com
```

---

## API Reference

### 1. Health Check
```bash
GET /api/health

Response: {"status":"ok"}

Use to: Verify service is running before starting evals
```

---

### 2. Start Evaluation
```bash
POST /api/evaluate/start

Request Body:
{
  "agent_id": "my-org/my-agent",
  "judge_repetitions": 1,
  "dataset_version": "v1.0"
}

Response:
{
  "stream_id": "abc-123-def",
  "agent_id": "my-org/my-agent"
}

Use to: Trigger evaluation, get stream_id for polling
```

**Parameters:**
- `agent_id` (required): Unique identifier for your agent
- `judge_repetitions` (optional, default=1): 1=fast/noisy, 3=slow/stable
- `dataset_version` (optional): Golden set version to evaluate against

---

### 3. Poll for Results
```bash
GET /api/runs/{run_id}

Response:
{
  "run_id": "run-xyz",
  "agent_id": "my-org/my-agent",
  "dataset_id": "default",
  "dataset_version": "v1.0",
  "passed": true,                    ← PRIMARY GATE
  "weighted_score": 0.92,            ← OPTIONAL GATE
  "weighted_delta": 0.02,            ← OPTIONAL GATE
  "created_at": "2026-09-03T12:34:56Z",
  "case_results": [
    {
      "case_id": "case-001",
      "passed": true,
      "weighted_score": 0.95,
      "scores": [
        {
          "metric": "answer_matches_gold",
          "score": 1.0,
          "threshold": 0.95,
          "passed": true,
          "critical": false,
          "rationale": "Exact match"
        }
      ]
    }
  ],
  "stats": {
    "total_cases": 50,
    "passed_cases": 48,
    "pass_rate": 0.96
  }
}

Use to: Poll until evaluation completes
```

**Gate Decision Logic:**
```
if run.passed == false:
  exit 1  # ❌ FAIL - Regression detected

if run.weighted_score < 0.85:
  exit 1  # ❌ FAIL - Score too low

if run.weighted_delta < -0.05:
  exit 1  # ❌ FAIL - Quality regression

else:
  exit 0  # ✅ PASS - All gates passed
```

---

### 4. Stream Progress (Optional)
```bash
GET /api/evaluate/stream/{stream_id}

Returns Server-Sent Events (SSE):

data: {"type":"started","agent_id":"..."}
data: {"type":"case_progress","case_id":"case-001","passed":true,"score":0.95}
data: {"type":"case_progress","case_id":"case-002","passed":false,"score":0.82}
...
data: {"type":"done","result":{...full_run_object...}}

Use to: Display real-time progress in CI/CD logs
```

---

### 5. Export Results
```bash
GET /api/runs/{run_id}/export?format={csv|pdf}

Response: CSV/PDF file with detailed results

Use to: Archive results for human review
```

---

### 6. List Runs
```bash
GET /api/runs?agent_id=my-org/my-agent&limit=10

Response:
{
  "runs": [
    {"run_id": "run-xyz", "passed": true, ...},
    {"run_id": "run-abc", "passed": false, ...}
  ]
}

Use to: View evaluation history
```

---

## Integration Examples

### GitHub Actions

```yaml
name: Evaluation Gate

on:
  push:
    branches: [main, develop]
  pull_request:
    branches: [main, develop]

jobs:
  evaluate:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      
      - uses: actions/setup-python@v4
        with:
          python-version: "3.11"
      
      - run: pip install requests
      
      - name: Run Evaluation Gate
        id: eval
        env:
          AGENT_ID: ${{ github.repository }}
          EVAL_URL: https://eval-service.example.com
        run: |
          if [ "${{ github.event_name }}" = "pull_request" ]; then
            threshold="0.85"
          else
            threshold="0.80"
          fi
          
          python scripts/ci_gate.py \
            --timeout 1200 \
            --score $threshold \
            --delta -0.05 \
            --output eval_result.json \
            -v
      
      - name: Upload Results
        if: always()
        uses: actions/upload-artifact@v3
        with:
          name: eval-results
          path: eval_result.json
          retention-days: 90
      
      - name: Comment PR
        if: github.event_name == 'pull_request' && always()
        uses: actions/github-script@v7
        with:
          script: |
            const fs = require('fs');
            const result = JSON.parse(fs.readFileSync('eval_result.json'));
            const status = result.passed ? '✅ PASS' : '❌ FAIL';
            
            github.rest.issues.createComment({
              issue_number: context.issue.number,
              owner: context.repo.owner,
              repo: context.repo.repo,
              body: `
              ## 📊 Evaluation Results
              
              **Status:** ${status}
              **Score:** ${result.weighted_score?.toFixed(3)}
              **Delta:** ${result.weighted_delta?.toFixed(3)}
              **Pass Rate:** ${(result.stats?.pass_rate * 100)?.toFixed(1)}%
              `
            });

  deploy:
    needs: evaluate
    if: github.ref == 'refs/heads/main' && success()
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - run: |
          docker build -t my-agent:${{ github.sha }} .
          docker push gcr.io/my-project/my-agent:${{ github.sha }}
      - run: kubectl set image deployment/my-agent my-agent=gcr.io/my-project/my-agent:${{ github.sha }} -n prod
```

---

### GitLab CI

```yaml
stages:
  - test
  - evaluate
  - deploy

test:
  stage: test
  image: python:3.11
  script:
    - pip install -r requirements.txt pytest
    - pytest tests/ -v

evaluate:
  stage: evaluate
  image: python:3.11
  script:
    - pip install requests
    - python scripts/ci_gate.py $CI_PROJECT_NAME \
        --eval-url https://eval-service.example.com \
        --score 0.85 \
        --output eval_result.json \
        -v
  artifacts:
    paths:
      - eval_result.json
    expire_in: 90 days
  only:
    - merge_requests
    - main
    - develop

deploy:
  stage: deploy
  image: google/cloud-sdk:alpine
  script:
    - gcloud container clusters get-credentials prod
    - kubectl set image deployment/my-agent my-agent=gcr.io/my-project/my-agent:$CI_COMMIT_SHA
  only:
    - main
  needs:
    - evaluate
```

---

### Jenkins

```groovy
pipeline {
  agent any
  
  stages {
    stage('Test') {
      steps {
        sh '''
          pip install -r requirements.txt pytest
          pytest tests/ -v
        '''
      }
    }
    
    stage('Evaluate') {
      steps {
        sh '''
          pip install requests
          python scripts/ci_gate.py ${JOB_NAME} \
            --eval-url https://eval-service.example.com \
            --score 0.85 \
            --output eval_result.json
        '''
        
        script {
          result = readJSON(file: 'eval_result.json')
          if (!result.passed) {
            error("Evaluation failed: passed=${result.passed}")
          }
        }
      }
    }
    
    stage('Deploy') {
      when {
        branch 'main'
      }
      steps {
        sh '''
          docker build -t my-agent:${BUILD_NUMBER} .
          docker push gcr.io/my-project/my-agent:${BUILD_NUMBER}
          kubectl set image deployment/my-agent my-agent=gcr.io/my-project/my-agent:${BUILD_NUMBER}
        '''
      }
    }
  }
  
  post {
    failure {
      emailext(
        subject: "Evaluation failed: ${JOB_NAME}",
        body: "Build ${BUILD_NUMBER} failed evaluation gate",
        to: "team@example.com"
      )
    }
  }
}
```

---

### Generic CI/CD (Python Script)

Use the provided `ci_gate.py` with any CI/CD system:

```bash
#!/bin/bash

# Install
pip install requests

# Run
python scripts/ci_gate.py my-agent \
  --eval-url https://eval-service.example.com \
  --score 0.85 \
  --delta -0.05 \
  --output results.json \
  -v

# Capture exit code
exit_code=$?

# Post-process
if [ $exit_code -eq 0 ]; then
  echo "✅ Evaluation passed"
  curl -X POST https://slack.example.com/webhook -d "Agent passed eval"
else
  echo "❌ Evaluation failed"
  curl -X POST https://slack.example.com/webhook -d "Agent failed eval"
fi

exit $exit_code
```

---

## Practical Walkthrough

### Scenario: Integrate eval gate into `my-org/my-agent` repository

#### Step 1: Repository Structure (Before)

```
my-org/my-agent/
├── .github/workflows/
│   ├── lint.yml
│   └── test.yml
├── src/
│   └── agent/
├── tests/
├── requirements.txt
└── README.md
```

#### Step 2: Add Gate Script

```bash
mkdir -p scripts
cp ../scope-eval/dbaware-evaluation-service/scripts/ci_gate.py scripts/
chmod +x scripts/ci_gate.py

git add scripts/ci_gate.py
git commit -m "add: evaluation gate script"
```

#### Step 3: Add GitHub Actions Workflow

Create `.github/workflows/eval-gate.yml`:

```yaml
name: Evaluation Gate

on:
  push:
    branches: [main, develop]
  pull_request:

jobs:
  lint:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-python@v4
        with:
          python-version: "3.11"
      - run: pip install ruff pylint
      - run: ruff check src/
      - run: ruff format --check src/

  test:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-python@v4
        with:
          python-version: "3.11"
      - run: pip install -r requirements.txt pytest pytest-cov
      - run: pytest -v --cov=src

  evaluate:
    needs: [lint, test]
    runs-on: ubuntu-latest
    if: github.event_name == 'push' || github.event.pull_request.head.repo.full_name == github.repository
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-python@v4
        with:
          python-version: "3.11"
      
      - run: pip install requests
      
      - run: |
          python scripts/ci_gate.py ${{ github.repository }} \
            --eval-url https://eval-service.example.com \
            --score 0.85 \
            --delta -0.05 \
            --output eval_result.json \
            -v
      
      - if: always()
        uses: actions/upload-artifact@v3
        with:
          name: eval-results-${{ github.sha }}
          path: eval_result.json
          retention-days: 90
      
      - if: github.event_name == 'pull_request' && always()
        uses: actions/github-script@v7
        with:
          script: |
            const fs = require('fs');
            if (!fs.existsSync('eval_result.json')) return;
            
            const result = JSON.parse(fs.readFileSync('eval_result.json'));
            github.rest.issues.createComment({
              issue_number: context.issue.number,
              owner: context.repo.owner,
              repo: context.repo.repo,
              body: `✅ Eval passed: score=${result.weighted_score?.toFixed(3)}, delta=${result.weighted_delta?.toFixed(3)}`
            });

  deploy:
    needs: evaluate
    if: github.ref == 'refs/heads/main' && success()
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - run: |
          docker build -t gcr.io/my-project/my-agent:${{ github.sha }} .
          docker push gcr.io/my-project/my-agent:${{ github.sha }}
      - run: |
          gcloud container clusters get-credentials prod
          kubectl set image deployment/my-agent my-agent=gcr.io/my-project/my-agent:${{ github.sha }} -n prod
```

#### Step 4: Commit

```bash
git add .github/workflows/eval-gate.yml
git commit -m "feat: add evaluation gate to CI/CD

- Integrates with centralized eval service
- Blocks deployment if agent quality degrades
- Reports results to PR comments
- Thresholds: score>=0.85, delta>=-0.05"
git push
```

#### Step 5: Test Locally

```bash
# Start eval service (if not already running)
cd ../scope-eval/dbaware-evaluation-service
docker-compose up -d

# Back in agent repo
cd my-org/my-agent
python scripts/ci_gate.py my-org/my-agent \
  --eval-url http://localhost:4002 \
  --verbose

# Expected output:
# ============================================================
# Evaluation Gate for Agent: my-org/my-agent
# Eval Service URL: http://localhost:4002
# ============================================================
# 
# [INFO] ✅ Eval service healthy
# [INFO] Starting evaluation...
# [INFO] ✅ Evaluation started: run_id=abc-123
# [INFO] Poll #1 [5s]: In progress...
# [INFO] ✅ Completed in 60s
# 
# === Checking Gates ===
# [INFO] ✅ Primary gate: passed=true
# [INFO] ✅ Score gate: 0.920 >= 0.850
# [INFO] ✅ Improvement: delta=+0.020
# [INFO] ✅ Pass rate: 96.0% >= 90.0%
# 
# ✅ ALL GATES PASSED
```

#### Step 6: Watch CI/CD

- Push to GitHub
- GitHub Actions runs: lint → test → evaluate → deploy
- Eval service scores your agent
- If passed: deployment proceeds ✅
- If failed: deployment blocked ❌
- PR gets automatic comment with results

---

## Performance & Cost

### Per Evaluation Run

**Typical (50 cases, 1x judge repetition):**

| Component | Value |
|-----------|-------|
| LLM judge calls | 50 |
| Cost per call | $0.002 (Vertex AI) |
| Judge cost | $0.10 |
| Database storage | ~10 KB ≈ negligible |
| **Total per run** | **~$0.11** |

**Breakdown:**
- Judge: $0.002 × 50 = $0.10
- Compute: $0.01
- Storage: negligible

### Scaling Example (100-person organization)

| Metric | Value |
|--------|-------|
| Agents | 100 |
| PRs per agent per week | 5 |
| Total evals per week | 500 |
| Cost per eval | $0.11 |
| Weekly cost | $55 |
| Monthly cost | $220 |
| **Cost per agent** | **$2.20/month** |

**Conclusion:** Very affordable! ~$2 per agent per month.

### Timing

| Scenario | Duration |
|----------|----------|
| Fast (1× judge, small dataset) | ~2 minutes |
| Standard (1× judge, 50 cases) | ~3 minutes |
| Stable (3× judge, 50 cases) | ~9 minutes |
| (Timeout if hung) | 25 minutes (configurable) |

**Recommendation:**
- **PR gates:** `judge_reps=1` (2-3 min, acceptable for PR feedback)
- **Release gates:** `judge_reps=3` (9 min, more stable scores)

---

## Quality Gate Thresholds

### Recommended Configurations

#### Strict (Pre-Release, High Risk)
```bash
--score 0.95 \
--delta -0.02 \
--pass-rate 0.99
```
Use when: Deploying to production, high-stakes agents

#### Moderate (Standard, Recommended)
```bash
--score 0.85 \
--delta -0.05 \
--pass-rate 0.90
```
Use when: Main branch, development environments

#### Lenient (PR Gates, Low Risk)
```bash
--score 0.75 \
--delta -0.10 \
--pass-rate 0.80
```
Use when: PR gates, canary deployments

#### Binary (Just Pass/Fail)
```bash
# Omit --score, --delta, --pass-rate
python scripts/ci_gate.py my-agent
```
Use when: Only concerned with passing gate, not numeric thresholds

### How to Tune Thresholds

1. **Week 1:** Deploy with lenient thresholds
   - Monitor: What scores does your agent typically get?
   - Example: "Our agent scores 0.88 on average"

2. **Week 2:** Adjust to moderate thresholds
   - Set `--score 0.85` (slightly below average)
   - This catches regressions but allows normal variance

3. **Week 3+:** Fine-tune based on data
   - If agents rarely regress: Keep moderate
   - If too many false positives: Relax thresholds
   - If quality matters more: Tighten thresholds

---

## Troubleshooting

### Health Check

Before debugging, verify service is running:

```bash
curl -v https://eval-service.example.com/api/health

# Should return: 200 OK {"status":"ok"}
```

### Common Issues

#### "Connection refused"

**Symptom:** Error on `POST /api/evaluate/start`

**Cause:** Eval service not reachable

**Fix:**
1. Check URL: `echo $EVAL_SERVICE_URL`
2. Ping service: `curl https://eval-service.example.com/api/health`
3. Check network: Can CI/CD reach service? Firewall rules?
4. Restart service: `gcloud run deploy eval-service --source .` or `docker-compose restart`

---

#### "Unknown agent 'my-org/my-agent'"

**Symptom:** HTTP 404 on `/api/evaluate/start`

**Cause:** Agent not registered in eval service

**Fix:**
1. Check registered agents: `curl https://eval-service.example.com/api/agents`
2. Add agent to eval service:
   ```bash
   mkdir -p src/agents/my-org--my-agent
   cp src/agents/template/config.yaml src/agents/my-org--my-agent/
   # Edit config.yaml to point to your agent
   ```
3. Restart eval service

---

#### "Timeout after 25 minutes"

**Symptom:** Evaluation hangs and times out

**Cause:** Agent service not responding, judge stuck, or dataset too large

**Fix:**
1. Check agent health:
   ```bash
   curl https://my-agent.example.com/health
   ```
2. Check eval service logs:
   ```bash
   kubectl logs -n eval deployment/eval-service
   ```
3. Increase timeout (if eval is genuinely slow):
   ```bash
   python scripts/ci_gate.py my-agent --timeout 3000
   ```
4. Reduce dataset or judge repetitions:
   ```bash
   python scripts/ci_gate.py my-agent --judge-reps 1
   ```

---

#### "Stale OAuthError"

**Symptom:** `OAuthError: ID Token issued at ... is stale`

**Cause:** WIF JWT token expired

**Fix:**
1. Regenerate JWT:
   ```bash
   cd wif/wiftesting
   java -Dspring.config.location=../dbgarda/application.properties \
     -jar gcp-wif.jar
   ```
2. Verify new token created: `ls -la wif/dbgarda/jwtResponse.json`
3. Restart eval service or wait for next evaluation

---

#### "weighted_score is null"

**Symptom:** `{"weighted_score": null, "passed": null}`

**Cause:** Scorer failed (agent response format mismatch, metric error, etc.)

**Fix:**
1. Check eval service logs for exceptions
2. Verify agent response format matches expected schema
3. Test agent directly:
   ```bash
   curl -X POST https://my-agent.example.com/evaluate \
     -d '{"query":"test","context":"test"}'
   ```
4. Check golden set format (JSONL with proper schema)

---

#### "Gate failed (passed=false)"

**Symptom:** Evaluation completed but `passed=false`

**Cause:** Agent regression detected

**Fix:**
1. View run details: `https://eval-service.example.com/runs/{run_id}`
2. Check failing cases: Which cases did agent fail?
3. Compare to previous run: Use dashboard to spot metric changes
4. Investigate agent code: What changed since last passing eval?
5. Review `weighted_delta`: How much quality dropped?

---

### Debug Mode

Enable verbose logging:

```bash
python scripts/ci_gate.py my-agent \
  --eval-url http://localhost:4002 \
  --timeout 600 \
  --verbose \
  --output eval_debug.json

# Also saves detailed results to eval_debug.json
```

---

## FAQ

### Q: Will this slow down my CI/CD?

**A:** ~2-3 minutes per evaluation. Most teams run evaluation only on PRs and main branch, not every commit. Worth it for the quality gate.

---

### Q: Can multiple agents share one eval service?

**A:** Yes! Recommended approach (Centralized pattern). Register each agent, all use same service URL.

---

### Q: What if eval service is down?

**A:** CI/CD job fails (safety-first, prevents deploying unvalidated agents). Monitor service uptime and set up alerts to page on-call team if service goes down.

---

### Q: What if my agent is on a private network?

**A:** Eval service must reach your agent via HTTP. Either:
1. Expose agent publicly (with TLS/auth)
2. Run eval service on same network
3. Use SSH tunnels or VPN

---

### Q: Can I use this with GitLab CI, Jenkins, etc.?

**A:** Yes! Provide examples for GitHub Actions, GitLab CI, Jenkins. Generic Python script works with any CI/CD.

---

### Q: How do I track trends over time?

**A:** Use `weighted_delta` metric. Compare current run to previous baseline. Alert if delta < threshold.

Example Datadog query:
```
avg:eval.weighted_score{agent:my-agent}.rollup(avg, 1d)
```

---

### Q: What if my agent takes a long time?

**A:** Eval time scales with agent latency. If agent takes 10s per case:
- 50 cases × 10s = 500s = ~8 minutes

Optimize agent performance or reduce dataset size.

---

### Q: Can I run multiple evals in parallel?

**A:** Yes. Eval service handles multiple concurrent evals. Scale horizontally (GKE replicas) if needed.

---

### Q: Do I need to modify my agent code?

**A:** No. Eval service calls your agent via HTTP (`POST /evaluate`). Just ensure endpoint exists.

---

### Q: What's the difference between `judge_repetitions=1` and `judge_repetitions=3`?

**A:**
- `1` = Fast (~2-3 min), noisy, use for PR gates
- `3` = Slow (~9 min), stable, use for release gates

More repetitions = judge scores each case multiple times, results averaged for stability.

---

### Q: How do I handle authentication (OAuth, API keys)?

**A:** 
- **GCP Workload Identity:** Recommended for Cloud Run/GKE
- **API Keys:** Set in `EVAL_SERVICE_API_KEY` environment variable
- **Basic Auth:** Pass `--auth user:pass` to ci_gate.py
- **mTLS:** Configure in load balancer

---

### Q: Can I export results for compliance/audit?

**A:** Yes! Use `/api/runs/{run_id}/export?format=csv` or `format=pdf`.

```bash
curl https://eval-service.example.com/api/runs/abc-123/export?format=csv \
  > results.csv
```

---

### Q: What if I want to retry a failed evaluation?

**A:** Evaluation is deterministic (same agent + golden set = same result). To retry:
1. Fix agent code
2. Push new commit
3. CI/CD automatically re-evaluates

---

## Summary

### Minimum Viable Integration (15 minutes)

1. ✅ Copy `ci_gate.py` to your repo
2. ✅ Add `.github/workflows/eval-gate.yml` (or equivalent)
3. ✅ Test locally: `python scripts/ci_gate.py my-agent`
4. ✅ Commit and push
5. ✅ Watch CI/CD block degraded agents

### What This Gets You

✅ **Automated quality gates** — No degraded agents to production  
✅ **Trend tracking** — `weighted_delta` detects regressions  
✅ **Any CI/CD system** — GitHub Actions, GitLab CI, Jenkins, etc.  
✅ **Minimal setup** — Copy script + add workflow  
✅ **Scalable** — One service for entire organization  
✅ **Low cost** — ~$0.11 per evaluation  
✅ **Fast** — 2-3 minutes per run  

### Next Steps

1. Deploy eval service (Cloud Run, GKE, or Docker Compose)
2. Register your agent(s)
3. Copy `ci_gate.py` to agent repository
4. Add GitHub Actions workflow (or equivalent for your CI/CD)
5. Test locally
6. Commit and push
7. Watch CI/CD automatically gate your agent deployments

---

**Ready to start?** Begin with:
1. Deploy eval service (Step 1 above)
2. Copy gate script to your repo (Step 2 above)
3. Add workflow to your CI/CD (Step 3 above)
4. Test locally (Step 4 above)

Done. Your agent is now gated.
