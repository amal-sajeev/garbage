# Eval Service Integration: Centralized Model

**See:** [EVAL_INTEGRATION.md](EVAL_INTEGRATION.md)

This comprehensive document contains everything needed to integrate the eval service into a CI/CD pipeline using a **centralized service architecture** (one service for the entire organization).

**Topics covered:**
- Quick answer (30 seconds)
- 5-minute overview & deployment
- Architecture (centralized service)
- Complete API reference
- Integration examples (GitHub Actions, GitLab CI, Jenkins)
- Practical step-by-step walkthrough
- Performance & cost analysis
- Quality gate thresholds
- Troubleshooting guide
- FAQ

**Start reading:** [EVAL_INTEGRATION.md](EVAL_INTEGRATION.md#5-minute-overview)

**Document size:** ~850 lines, ~26 KB (single, comprehensive guide)


