"""Shared pytest fixtures for the CTNA Evaluation Service test suite.

The suite never touches Vertex or a database: the LLM judge is replaced by a
scripted fake, and ADC resolution is monkeypatched. This mirrors the offline
design (capture/label stores in memory, SQLite/no-DB) so `pytest` runs anywhere.
"""

from __future__ import annotations

import pytest

from models import GoldenCase, MetricSpec, Observation
from scorers.vertex import JudgeVerdict


@pytest.fixture(autouse=True)
def _reset_judge_cache():
    """Isolate the process-lifetime judge cache between tests."""
    from scorers import llm_judge
    llm_judge.reset_cache()
    yield
    llm_judge.reset_cache()


class FakeJudge:
    """Stand-in for the object returned by `build_judge()`.

    `.invoke(prompt)` returns the next scripted JudgeVerdict, cycling through the
    supplied scores so self-consistency (variance) can be exercised. Records every
    prompt it saw so tests can assert on caching / order-swap behaviour.
    """

    def __init__(self, scores, rationale="looks good", evidence=None):
        self._scores = list(scores)
        self._i = 0
        self._rationale = rationale
        self._evidence = list(evidence or ["ev-1"])
        self.prompts: list[str] = []

    def invoke(self, prompt):
        self.prompts.append(prompt)
        score = self._scores[self._i % len(self._scores)]
        self._i += 1
        return JudgeVerdict(
            score=float(score),
            passed=False,
            rationale=self._rationale,
            evidence=list(self._evidence),
        )


@pytest.fixture
def make_judge():
    """Factory building a FakeJudge with the given per-invocation scores."""
    def _factory(scores, **kw):
        return FakeJudge(scores, **kw)
    return _factory


@pytest.fixture
def patch_judge(monkeypatch):
    """Patch `build_judge` in llm_judge to return a supplied FakeJudge."""
    def _apply(judge):
        monkeypatch.setattr(
            "scorers.llm_judge.build_judge", lambda: judge
        )
        return judge
    return _apply


@pytest.fixture
def patch_judge_unavailable(monkeypatch):
    """Make `build_judge` raise, simulating missing ADC/Vertex (offline)."""
    def _raise():
        raise RuntimeError("PROJECT_NAME is not set; the evaluation judge requires Vertex AI.")
    monkeypatch.setattr("scorers.llm_judge.build_judge", _raise)


@pytest.fixture
def observation():
    return Observation(
        target_id="data-extraction-agent",
        output="The AppCatalog lookup for AU-10001 under Acme Corp returns the inventory.",
        tool_calls=[{"tool": "get_application_data", "args": "AU-10001;Acme Corp", "error": None}],
        latency_ms=1200,
        usage={"input_tokens": 1800, "output_tokens": 500},
        model="gemini-2.5-pro",
    )


@pytest.fixture
def case():
    return GoldenCase(
        id="app_single_unit",
        input={"query": "Get the AppCatalog data for AU-10001 at Acme Corp."},
        golden_output="The AppCatalog lookup for AU-10001 under Acme Corp returns the inventory.",
        expected={"expected_tool": "get_application_data", "expected_values": ["AU-10001", "Acme Corp"]},
        baseline_metrics={"faithfulness": 0.9},
    )


@pytest.fixture
def make_spec():
    def _factory(name="faithfulness", **kw):
        params = dict(name=name, type="llm_judge", scorer=name, weight=1.0, threshold=0.8)
        params.update(kw)
        return MetricSpec(**params)
    return _factory
