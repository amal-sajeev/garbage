"""Tests for the document text-extraction layer (adapters/documents.py)."""

from __future__ import annotations

import base64
import pytest

from adapters.documents import (
    detect_content_type,
    extract_text,
    parse_markdown_sections,
    parse_headings,
    _DocUnavailable,
)


class TestDetectContentType:
    def test_text(self):
        assert detect_content_type("hello world") == "text"

    def test_json_dict(self):
        assert detect_content_type({"a": 1}) == "json"

    def test_json_string(self):
        assert detect_content_type('{"a": 1}') == "json"

    def test_markdown_heading(self):
        assert detect_content_type("# Title\nbody") == "markdown"

    def test_pdf_magic_bytes(self):
        assert detect_content_type(b"%PDF-1.4\nstuff") == "pdf"

    def test_base64_pdf(self):
        raw = b"%PDF-1.4 test"
        b64 = base64.b64encode(raw).decode()
        assert detect_content_type(b64, "base64") == "pdf"

    def test_docx_magic_bytes(self):
        assert detect_content_type(b"PK\x03\x04stuff") == "docx"

    def test_none(self):
        assert detect_content_type(None) == "text"


class TestExtractText:
    def test_text_passthrough(self):
        assert extract_text("hello") == "hello"

    def test_markdown_strips_syntax(self):
        md = "# Title\n\n**bold** and *italic* and `code`"
        text = extract_text(md, "markdown")
        assert "Title" in text
        assert "**" not in text
        assert "*" not in text
        assert "`" not in text

    def test_json_pretty_print(self):
        result = extract_text({"a": 1}, "json")
        assert '"a": 1' in result

    def test_json_string(self):
        result = extract_text('{"b": 2}', "json")
        assert '"b": 2' in result

    def test_none_returns_empty(self):
        assert extract_text(None) == ""

    def test_pdf_skips_without_pypdf(self):
        raw = b"%PDF-1.4\n1 0 obj<<>>endobj\nxref\n0 1\n0000000000 65535 f \ntrailer<<>>\nstartxref\n0\n%%EOF"
        try:
            import pypdf  # noqa: F401
            pytest.skip("pypdf installed; skip-cleanly test is for missing lib")
        except ImportError:
            with pytest.raises(_DocUnavailable):
                extract_text(raw, "pdf")

    def test_docx_skips_without_docx(self):
        raw = b"PK\x03\x04" + b"\x00" * 100
        try:
            import docx  # noqa: F401
            pytest.skip("python-docx installed; skip-cleanly test is for missing lib")
        except ImportError:
            with pytest.raises(_DocUnavailable):
                extract_text(raw, "docx")


class TestParseMarkdownSections:
    def test_split_by_headings(self):
        md = "# Title\n\nbody1\n\n## Sub\n\nbody2"
        sections = parse_markdown_sections(md)
        assert "Title" in sections
        assert "Sub" in sections
        assert "body1" in sections["Title"]
        assert "body2" in sections["Sub"]

    def test_no_headings(self):
        sections = parse_markdown_sections("just text")
        assert sections == {}


class TestParseHeadings:
    def test_markdown_headings(self):
        text = "# A\n## B\n### C\nbody"
        headings = parse_headings(text, "markdown")
        assert len(headings) == 3

    def test_plain_text_headings(self):
        text = "Introduction\nThis is some body text.\nConclusion"
        headings = parse_headings(text, "text")
        assert len(headings) >= 1
