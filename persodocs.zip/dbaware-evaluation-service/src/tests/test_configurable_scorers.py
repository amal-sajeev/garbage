"""Tests for the config-driven scorers (scorers/configurable.py)."""

from __future__ import annotations

import pytest

from models import GoldenCase, MetricSpec, Observation
from scorers.base import MetricSkipped, get_scorer


def _obs(output, metadata=None):
    return Observation(
        target_id="test",
        output=output,
        metadata=metadata or {},
        tool_calls=[],
        latency_ms=100,
    )


def _case(**kw):
    defaults = {"id": "test", "input": {}}
    defaults.update(kw)
    return GoldenCase(**defaults)


def _spec(scorer_name, config=None):
    return MetricSpec(name="m", type="deterministic", scorer=scorer_name, config=config or {})


class TestContains:
    def test_all_present(self):
        obs = _obs("The quick brown fox jumps over the lazy dog")
        case = _case()
        spec = _spec("contains", {"terms": ["quick", "fox", "dog"]})
        fn = get_scorer("contains")
        score = fn(observation=obs, case=case, spec=spec)[0]
        assert score == 1.0

    def test_some_missing(self):
        obs = _obs("The quick brown fox")
        case = _case()
        spec = _spec("contains", {"terms": ["quick", "cat", "dog"]})
        fn = get_scorer("contains")
        score = fn(observation=obs, case=case, spec=spec)[0]
        assert score == pytest.approx(1 / 3)

    def test_min_count(self):
        obs = _obs("ha ha ha ha")
        case = _case()
        spec = _spec("contains", {"terms": ["ha"], "min_count": 3})
        fn = get_scorer("contains")
        score, _, _ = fn(observation=obs, case=case, spec=spec)
        assert score == 1.0

    def test_case_insensitive(self):
        obs = _obs("Hello World")
        case = _case()
        spec = _spec("contains", {"terms": ["hello"], "case_sensitive": False})
        fn = get_scorer("contains")
        score, _, _ = fn(observation=obs, case=case, spec=spec)
        assert score == 1.0

    def test_op_not_empty_nonempty(self):
        obs = _obs("hello")
        spec = _spec("contains", {"op": "not_empty", "substring": ""})
        fn = get_scorer("contains")
        assert fn(observation=obs, case=_case(), spec=spec)[0] == 1.0

    def test_op_not_empty_blank_fails(self):
        obs = _obs("   ")
        spec = _spec("contains", {"op": "not_empty", "substring": ""})
        fn = get_scorer("contains")
        assert fn(observation=obs, case=_case(), spec=spec)[0] == 0.0

    def test_empty_terms_without_op_still_passes(self):
        obs = _obs("hello")
        spec = _spec("contains", {})
        fn = get_scorer("contains")
        assert fn(observation=obs, case=_case(), spec=spec)[0] == 1.0


class TestNotEmpty:
    def test_text(self):
        fn = get_scorer("not_empty")
        assert fn(observation=_obs("hello"), case=_case())[0] == 1.0

    def test_whitespace_fails(self):
        fn = get_scorer("not_empty")
        assert fn(observation=_obs("  \n"), case=_case())[0] == 0.0

    def test_none_fails(self):
        fn = get_scorer("not_empty")
        assert fn(observation=_obs(None), case=_case())[0] == 0.0

    def test_empty_object_fails(self):
        fn = get_scorer("not_empty")
        assert fn(observation=_obs({}), case=_case())[0] == 0.0

    def test_empty_list_fails(self):
        fn = get_scorer("not_empty")
        assert fn(observation=_obs([]), case=_case())[0] == 0.0


class TestNotContains:
    def test_all_absent(self):
        spec = _spec("not_contains", {"terms": ["guaranteed return", "ignore previous"]})
        fn = get_scorer("not_contains")
        score, _, _ = fn(observation=_obs("Coverage includes medical and dental."), case=_case(), spec=spec)
        assert score == 1.0

    def test_some_present(self):
        spec = _spec("not_contains", {"forbidden": ["secret", "password"]})
        fn = get_scorer("not_contains")
        score, _, _ = fn(observation=_obs("The secret code is 1"), case=_case(), spec=spec)
        assert score == pytest.approx(0.5)


class TestRegexMatch:
    def test_match(self):
        obs = _obs("Invoice #INV-2025-001")
        case = _case()
        spec = _spec("regex_match", {"patterns": [{"pattern": r"INV-\d{4}-\d{3}"}]})
        fn = get_scorer("regex_match")
        score, _, _ = fn(observation=obs, case=case, spec=spec)
        assert score == 1.0

    def test_no_match(self):
        obs = _obs("Hello World")
        case = _case()
        spec = _spec("regex_match", {"patterns": [{"pattern": r"INV-\d+"}]})
        fn = get_scorer("regex_match")
        score, _, _ = fn(observation=obs, case=case, spec=spec)
        assert score == 0.0

    def test_optional_pattern(self):
        obs = _obs("Hello")
        case = _case()
        spec = _spec("regex_match", {"patterns": [{"pattern": r"Hello", "required": True}, {"pattern": r"World", "required": False}]})
        fn = get_scorer("regex_match")
        score, _, _ = fn(observation=obs, case=case, spec=spec)
        assert score == 1.0


class TestLengthRange:
    def test_within_range(self):
        obs = _obs("one two three four five")
        case = _case()
        spec = _spec("length_range", {"min": 3, "max": 10, "unit": "words"})
        fn = get_scorer("length_range")
        score = fn(observation=obs, case=case, spec=spec)[0]
        assert score == 1.0

    def test_below_min(self):
        obs = _obs("one two")
        case = _case()
        spec = _spec("length_range", {"min": 5, "unit": "words"})
        fn = get_scorer("length_range")
        score, _, _, _ = fn(observation=obs, case=case, spec=spec)
        assert score < 1.0

    def test_above_max(self):
        obs = _obs(" ".join(["word"] * 100))
        case = _case()
        spec = _spec("length_range", {"min": 1, "max": 10, "unit": "words"})
        fn = get_scorer("length_range")
        score, _, _, _ = fn(observation=obs, case=case, spec=spec)
        assert score < 1.0


class TestKeywordCount:
    def test_count(self):
        obs = _obs("error error error warning info")
        case = _case()
        spec = _spec("keyword_count", {"terms": ["error", "warning"]})
        fn = get_scorer("keyword_count")
        extras = fn(observation=obs, case=case, spec=spec)[3]
        assert extras["raw_value"] == 4.0  # 3 "error" + 1 "warning"


class TestJsonPath:
    def test_equals(self):
        obs = _obs({"total": 8000})
        case = _case()
        spec = _spec("json_path", {"path": "total", "op": "equals", "value": 8000})
        fn = get_scorer("json_path")
        score, _, _ = fn(observation=obs, case=case, spec=spec)
        assert score == 1.0

    def test_not_equal(self):
        obs = _obs({"total": 5000})
        case = _case()
        spec = _spec("json_path", {"path": "total", "op": "equals", "value": 8000})
        fn = get_scorer("json_path")
        score, _, _ = fn(observation=obs, case=case, spec=spec)
        assert score == 0.0

    def test_exists(self):
        obs = _obs({"vendor": "Acme"})
        case = _case()
        spec = _spec("json_path", {"path": "vendor", "op": "exists"})
        fn = get_scorer("json_path")
        score, _, _ = fn(observation=obs, case=case, spec=spec)
        assert score == 1.0

    def test_missing_path(self):
        obs = _obs({"a": 1})
        case = _case()
        spec = _spec("json_path", {"path": "b.c", "op": "exists"})
        fn = get_scorer("json_path")
        score, _, _ = fn(observation=obs, case=case, spec=spec)
        assert score == 0.0

    def test_nested_path(self):
        obs = _obs({"data": {"items": [{"id": 42}]}})
        case = _case()
        spec = _spec("json_path", {"path": "data.items.0.id", "op": "equals", "value": 42})
        fn = get_scorer("json_path")
        score, _, _ = fn(observation=obs, case=case, spec=spec)
        assert score == 1.0

    def test_bracket_index(self):
        obs = _obs({"data": {"items": [{"id": 42}]}})
        spec = _spec("json_path", {"path": "data.items[0].id", "op": "equals", "value": 42})
        fn = get_scorer("json_path")
        score, _, _ = fn(observation=obs, case=_case(), spec=spec)
        assert score == 1.0

    def test_not_json(self):
        obs = _obs("plain text")
        case = _case()
        spec = _spec("json_path", {"path": "a", "op": "exists"})
        fn = get_scorer("json_path")
        score, _, _ = fn(observation=obs, case=case, spec=spec)
        assert score == 0.0


class TestFieldMatch:
    def test_all_fields_present(self):
        obs = _obs({"vendor": "Acme", "total": 100, "currency": "USD"})
        case = _case()
        spec = _spec("field_match", {"fields": [
            {"name": "vendor", "op": "exists"},
            {"name": "total", "op": "type", "value": "number"},
            {"name": "currency", "op": "==", "value": "USD"},
        ]})
        fn = get_scorer("field_match")
        score, _, _ = fn(observation=obs, case=case, spec=spec)
        assert score == 1.0

    def test_missing_field(self):
        obs = _obs({"vendor": "Acme"})
        case = _case()
        spec = _spec("field_match", {"fields": [
            {"name": "vendor", "op": "exists"},
            {"name": "total", "op": "exists"},
        ]})
        fn = get_scorer("field_match")
        score, _, _ = fn(observation=obs, case=case, spec=spec)
        assert score == 0.5

    def test_contains_op(self):
        obs = _obs({"items": ["apple", "banana", "cherry"]})
        case = _case()
        spec = _spec("field_match", {"fields": [
            {"name": "items", "op": "contains", "value": "banana"},
        ]})
        fn = get_scorer("field_match")
        score, _, _ = fn(observation=obs, case=case, spec=spec)
        assert score == 1.0

    def test_optional_field_does_not_dilute_score(self):
        obs = _obs({"vendor": "Acme"})
        spec = _spec("field_match", {"fields": [
            {"name": "vendor", "op": "exists", "required": True},
            {"name": "discount", "op": "exists", "required": False},
        ]})
        fn = get_scorer("field_match")
        score, _, _ = fn(observation=obs, case=_case(), spec=spec)
        assert score == 1.0

    def test_nested_field_path(self):
        obs = _obs({"line_items": [{"amount": 100}]})
        spec = _spec("field_match", {"fields": [
            {"name": "line_items[0].amount", "op": "==", "value": 100},
        ]})
        fn = get_scorer("field_match")
        score, _, _ = fn(observation=obs, case=_case(), spec=spec)
        assert score == 1.0


class TestJsonSchemaValid:
    def test_valid_schema(self):
        obs = _obs({"vendor": "Acme", "total": 100, "items": []})
        case = _case()
        spec = _spec("json_schema_valid", {"schema": {
            "type": "object",
            "required": ["vendor", "total"],
            "properties": {
                "vendor": {"type": "string"},
                "total": {"type": "number"},
                "items": {"type": "array"},
            },
        }})
        fn = get_scorer("json_schema_valid")
        score, _, _ = fn(observation=obs, case=case, spec=spec)
        assert score == 1.0

    def test_missing_required(self):
        obs = _obs({"vendor": "Acme"})
        case = _case()
        spec = _spec("json_schema_valid", {"schema": {
            "type": "object",
            "required": ["vendor", "total"],
        }})
        fn = get_scorer("json_schema_valid")
        score, _, _ = fn(observation=obs, case=case, spec=spec)
        assert score == 0.0

    def test_shortcut_required_types(self):
        obs = _obs({"vendor": "Acme", "total": 100})
        case = _case()
        spec = _spec("json_schema_valid", {"required": ["vendor", "total"], "types": {"total": "number"}})
        fn = get_scorer("json_schema_valid")
        score, _, _ = fn(observation=obs, case=case, spec=spec)
        assert score == 1.0


class TestSectionPresent:
    def test_markdown_sections(self):
        obs = _obs("# Report\n\n## Executive Summary\nbody\n\n## Key Findings\nbody", {"content_type": "markdown"})
        case = _case()
        spec = _spec("section_present", {"sections": ["Executive Summary", "Key Findings"]})
        fn = get_scorer("section_present")
        score, _, _ = fn(observation=obs, case=case, spec=spec)
        assert score == 1.0

    def test_missing_section(self):
        obs = _obs("# Report\n\n## Only One\nbody", {"content_type": "markdown"})
        case = _case()
        spec = _spec("section_present", {"sections": ["Executive Summary", "Key Findings"]})
        fn = get_scorer("section_present")
        score, _, _ = fn(observation=obs, case=case, spec=spec)
        assert score == 0.0


class TestHeadingCount:
    def test_within_range(self):
        obs = _obs("# A\n## B\n## C\nbody", {"content_type": "markdown"})
        case = _case()
        spec = _spec("heading_count", {"min": 2, "max": 10})
        fn = get_scorer("heading_count")
        score, _, _, extras = fn(observation=obs, case=case, spec=spec)
        assert score == 1.0
        assert extras["raw_value"] == 3.0

    def test_below_min(self):
        obs = _obs("# A\nbody", {"content_type": "markdown"})
        case = _case()
        spec = _spec("heading_count", {"min": 5})
        fn = get_scorer("heading_count")
        score, _, _, _ = fn(observation=obs, case=case, spec=spec)
        assert score < 1.0


class TestRubricScorer:
    def test_skips_without_config_rubric(self):
        obs = _obs("some output")
        case = _case()
        spec = _spec("rubric", {})
        fn = get_scorer("rubric")
        with pytest.raises(MetricSkipped):
            fn(observation=obs, case=case, spec=spec, judge_repetitions=1)

    def test_skips_offline(self):
        obs = _obs("some output")
        case = _case()
        spec = _spec("rubric", {"rubric": "test criterion"})
        fn = get_scorer("rubric")
        with pytest.raises(MetricSkipped):
            fn(observation=obs, case=case, spec=spec, judge_repetitions=1)
