"""Walkthrough query agent config: document seeding + golden-set shape."""

from __future__ import annotations

import json
from pathlib import Path

import httpx
import pytest

from models import GoldenCase, TargetSpec, ResponseMapping
from registry import Registry
from scorers import all_scorers, get_scorer
from adapters.http_adapter import get_registered_adapter

_AGENT_DIR = Path(__file__).resolve().parents[1] / "agents" / "walkthrough_query_agent"


def test_source_document_is_plan_20588_report():
    doc = json.loads((_AGENT_DIR / "source_document.json").read_text(encoding="utf-8"))
    assert doc["plan_number"] == "20588"
    assert "Swap Dealer" in doc["plan_name"]
    assert doc["document_title"] == "Consolidated Research Report"
    assert "4437" in doc["past_review_analysis"]
    assert "IRC-CD-1000141" in doc["policy_and_regulatory_analysis"]
    assert "R021" in doc["broad_scope_direction"]


def test_metrics_stub_covers_every_case():
    dataset = json.loads((_AGENT_DIR / "dataset.json").read_text(encoding="utf-8"))
    stub = json.loads((_AGENT_DIR / "metrics_stub.json").read_text(encoding="utf-8"))
    case_ids = {c["id"] for c in dataset["cases"]}
    stub_ids = set(stub["cases"])
    assert case_ids == stub_ids


def test_research_report_pdf_is_present():
    assert (_AGENT_DIR / "research_report.pdf").is_file()
    reg = Registry(_AGENT_DIR.parent).load()
    agent = reg.get("walkthrough_query_agent")
    assert agent.dataset.target.adapter == "walkthrough_http"
    assert agent.dataset.target.endpoint == "/qna/chat"
    assert len(agent.dataset.cases) == 8
    for metric in agent.dataset.metrics:
        assert metric.scorer in all_scorers()
    for case in agent.dataset.cases:
        assert case.input.get("question")
        assert case.input.get("planNumber", "").startswith("eval-20588-")
        assert case.golden_output
        # Inline document is injected by the adapter — cases must not rely on
        # a UI-generated plan id like PLAN-2025-001.
        assert "PLAN-2025" not in json.dumps(case.input)


def test_walkthrough_http_adapter_registered():
    Registry(_AGENT_DIR.parent).load()
    cls = get_registered_adapter("walkthrough_http")
    assert cls is not None


@pytest.mark.asyncio
async def test_adapter_uploads_then_chats_with_document():
    Registry(_AGENT_DIR.parent).load()
    cls = get_registered_adapter("walkthrough_http")
    target = TargetSpec(
        adapter="walkthrough_http",
        endpoint="/qna/chat",
        response=ResponseMapping(output_path="answer"),
        timeout=5,
        trust_env=False,
    )
    adapter = cls("http://walkthrough.test", "/qna/chat", target)

    captured = {}

    async def mock_handler(request: httpx.Request) -> httpx.Response:
        captured.setdefault("paths", []).append(request.url.path)
        if request.url.path.endswith("/qna/upload"):
            captured["upload"] = True
            return httpx.Response(
                201,
                json={
                    "gcs_blob_path": "eval/walkthrough_query_agent/source_document.json",
                    "gcs_uri": "gs://test-bucket/eval/walkthrough_query_agent/source_document.json",
                    "message": "ok",
                },
            )
        captured["chat_body"] = json.loads(request.content.decode("utf-8"))
        return httpx.Response(
            200,
            json={
                "session_id": "eval-20588-identity",
                "answer": "Plan Number 20588, Plan Name 2025 Swap Dealer (CFTC).",
                "history_length": 2,
            },
        )

    transport = httpx.MockTransport(mock_handler)
    original_init = httpx.AsyncClient.__init__

    def patched_init(self, **kwargs):
        kwargs["transport"] = transport
        original_init(self, **kwargs)

    httpx.AsyncClient.__init__ = patched_init
    try:
        case = GoldenCase(
            id="plan_identity_20588",
            input={
                "question": "What is the plan number and name?",
                "planNumber": "eval-20588-identity",
                "planName": "2025 Swap Dealer (CFTC)",
                "contextType": "Preliminary Research Walkthrough",
            },
            golden_output="20588",
        )
        obs = await adapter.run_case(case)
    finally:
        httpx.AsyncClient.__init__ = original_init

    assert captured.get("upload") is True
    body = captured["chat_body"]
    assert body["question"] == "What is the plan number and name?"
    assert body["researchSections"]["plan_number"] == "20588"
    assert body["researchSections"]["document_title"] == "Consolidated Research Report"
    assert body["contextGcsUri"].startswith("gs://test-bucket/")
    assert obs.output.startswith("Plan Number 20588")
    assert obs.source_context["plan_number"] == "20588"
    assert obs.error is None


def test_spot_checks_pass_on_extractive_plan_20588_answer():
    from models import Observation, MetricSpec

    fn = get_scorer("assertions")
    obs = Observation(
        target_id="plan_identity_20588",
        output="Plan Number 20588, Plan Name 2025 Swap Dealer (CFTC). Highly similar past review is 4437.",
    )
    case = GoldenCase(
        id="plan_identity_20588",
        input={"question": "plan identity"},
        expected={
            "spot_checks": [
                {"id": "plan_number", "expect": "present", "all_of": ["20588"]},
                {"id": "plan_name", "expect": "present", "all_of": ["swap dealer", "cftc"]},
                {"id": "highly_similar", "expect": "present", "all_of": ["4437"]},
            ]
        },
    )
    score, _, _ = fn(observation=obs, case=case, spec=MetricSpec(name="spot_checks", type="deterministic", scorer="assertions"))
    assert score == 1.0


def test_refusal_template_is_detected():
    from models import Observation

    fn = get_scorer("refusal_appropriate")
    obs = Observation(
        target_id="r",
        output="I cannot confirm this from walkthrough documentation",
    )
    case = GoldenCase(id="r", input={"question": "copay?"}, expected={"must_refuse": True})
    score, _, _ = fn(observation=obs, case=case)
    assert score == 1.0
