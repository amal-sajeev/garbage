"""Unit tests for aggregation: gate, critical veto, normalisation, RunStats."""

from __future__ import annotations

import pytest

import aggregation
from models import CaseResult, MetricSpec, Observation, Score


def _score(metric, score, *, threshold=0.8, weight=1.0, critical=False, baseline=None):
    return Score(
        metric=metric, score=score, passed=score >= threshold, threshold=threshold,
        weight=weight, critical=critical, baseline=baseline,
        delta=(score - baseline) if baseline is not None else None,
    )


def test_weighted_score_and_delta():
    scores = [_score("a", 0.8, weight=1.0, baseline=0.6),
              _score("b", 1.0, weight=3.0, baseline=0.9)]
    assert aggregation.weighted_score(scores) == pytest.approx((0.8 + 3.0) / 4.0)
    # delta = ((0.8-0.6)*1 + (1.0-0.9)*3) / 4 = (0.2 + 0.3)/4
    assert aggregation.weighted_delta(scores) == pytest.approx(0.5 / 4.0)


def test_critical_failure_vetoes_run():
    """A failing critical metric fails the case even with a high weighted score."""
    scores = [_score("quality", 1.0, weight=5.0),
              _score("no_pii_leakage", 0.0, threshold=1.0, weight=1.0, critical=True)]
    passed, s, _d = aggregation.gate(scores, dataset_threshold=0.5, regression_tolerance=0.05)
    assert s > 0.5  # weighted score is high
    assert passed is False  # but the critical veto fails it


def test_gate_passes_when_all_conditions_met():
    scores = [_score("a", 0.9, weight=1.0, baseline=0.9),
              _score("b", 0.95, weight=2.0, baseline=0.9)]
    passed, _s, _d = aggregation.gate(scores, dataset_threshold=0.8, regression_tolerance=0.05)
    assert passed is True


def test_gate_fails_on_regression_beyond_tolerance():
    scores = [_score("a", 0.5, threshold=0.4, weight=1.0, baseline=0.95)]
    passed, _s, d = aggregation.gate(scores, dataset_threshold=0.4, regression_tolerance=0.05)
    assert d < -0.05 and passed is False


def test_normalise_lower_is_better_inverts():
    spec = MetricSpec(name="latency_slo", type="operational", scorer="latency_slo",
                      direction="lower_is_better", norm_min=0, norm_max=8000)
    assert aggregation.normalise(0, spec) == pytest.approx(1.0)
    assert aggregation.normalise(8000, spec) == pytest.approx(0.0)
    assert aggregation.normalise(4000, spec) == pytest.approx(0.5)


def _case(cid, wscore, wdelta, passed):
    return CaseResult(case_id=cid, scores=[], weighted_score=wscore,
                      weighted_delta=wdelta, passed=passed,
                      observation=Observation(target_id="t"))


def test_run_statistics_pass_rate_and_ci():
    cases = [_case("c1", 0.9, 0.0, True), _case("c2", 0.7, -0.1, False),
             _case("c3", 0.8, 0.05, True)]
    stats = aggregation.run_statistics(cases, labels={})
    assert stats.n_cases == 3
    assert stats.pass_rate == pytest.approx(2 / 3)
    assert stats.ci95_low <= stats.mean_score <= stats.ci95_high


def test_run_statistics_calibration_with_labels():
    """Gate pass/fail vs human labels → precision/recall/F1/κ populated."""
    cases = [_case("c1", 0.9, 0.0, True), _case("c2", 0.6, 0.0, False),
             _case("c3", 0.85, 0.0, True), _case("c4", 0.5, 0.0, False)]
    labels = {"c1": "pass", "c2": "fail", "c3": "fail", "c4": "fail"}
    stats = aggregation.run_statistics(cases, labels=labels)
    assert stats.labeled_cases == 4
    # tp=1 (c1), fp=1 (c3 predicted pass, labeled fail), fn=0, tn=2
    assert stats.precision == pytest.approx(0.5)
    assert stats.recall == pytest.approx(1.0)


def test_classification_stats_perfect_agreement():
    cls = aggregation.classification_stats([True, False, True], [True, False, True])
    assert cls["f1"] == pytest.approx(1.0)
    assert cls["cohens_kappa"] == pytest.approx(1.0)


def test_drift_significance_flags_real_regression():
    md, p, sig = aggregation.drift_significance([-0.2, -0.25, -0.22, -0.3, -0.18])
    assert md < 0 and p is not None and p < 0.05 and sig is True


def test_drift_significance_ignores_noise():
    _md, _p, sig = aggregation.drift_significance([0.1, -0.1, 0.05, -0.05])
    assert sig is False
