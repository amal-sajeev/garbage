"""Unit tests for the LLM-as-a-judge scorers (offline, Vertex mocked)."""

from __future__ import annotations

import pytest

from scorers import get_scorer
from scorers.base import MetricSkipped


def _run(name, observation, case, **kw):
    return get_scorer(name)(observation=observation, case=case, metrics={}, **kw)


def test_judge_skips_when_vertex_unavailable(patch_judge_unavailable, observation, case):
    """No ADC/Vertex → MetricSkipped (not an error), so offline runs stay green."""
    with pytest.raises(MetricSkipped):
        _run("faithfulness", observation, case)


def test_rubric_dimensions_skip_offline(patch_judge_unavailable, observation, case):
    for dim in ("relevance", "completeness", "coherence", "conciseness", "instruction_following"):
        with pytest.raises(MetricSkipped):
            _run(dim, observation, case)


def test_faithfulness_returns_score_rationale_evidence(patch_judge, make_judge, observation, case):
    patch_judge(make_judge([0.9]))
    score, rationale, evidence, extras = _run("faithfulness", observation, case)
    assert score == pytest.approx(0.9)
    assert rationale == "looks good"
    assert "ev-1" in evidence
    assert extras["variance"] == pytest.approx(0.0)


def test_self_consistency_mean_and_variance(patch_judge, make_judge, observation, case, monkeypatch):
    """Multiple samples → mean score + recorded sample variance (pvariance)."""
    from config import Config
    monkeypatch.setattr(Config, "JUDGE_SWAP_ORDER", False)
    patch_judge(make_judge([0.6, 1.0]))  # mean 0.8, pvariance 0.04
    score, _rationale, evidence, extras = _run(
        "faithfulness", observation, case, judge_repetitions=2
    )
    assert score == pytest.approx(0.8)
    assert extras["variance"] == pytest.approx(0.04)
    # The samples summary is appended as an evidence line for auditability.
    assert any("samples=" in e for e in evidence)


def test_samples_capped_at_five():
    from scorers import llm_judge
    assert llm_judge._samples(99) == 5
    assert llm_judge._samples(1) == llm_judge.Config.JUDGE_SAMPLES
    assert llm_judge._samples(3) == 3
