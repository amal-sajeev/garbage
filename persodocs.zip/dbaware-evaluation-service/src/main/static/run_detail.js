// Standalone run detail page. Reads ?run=<uuid> and renders the full run:
// header tiles, statistics, judge/human calibration, per-case metrics, a
// stylized collapsed golden-vs-agent output diff for human review, and the
// human-label form. Kept dependency-free (vanilla JS).

const runId = new URLSearchParams(location.search).get("run");

const $ = (s) => document.querySelector(s);

function pill(text, cls) {
  const p = $("#run-pill");
  p.textContent = text;
  p.className = "pill " + (cls || "");
}
function pct(x) { return (x * 100).toFixed(1) + "%"; }
function num(x, d = 3) { return x === null || x === undefined ? "–" : Number(x).toFixed(d); }
function fmtDelta(d) {
  if (d === null || d === undefined) return "";
  const cls = d >= 0 ? "delta-pos" : "delta-neg";
  const sign = d >= 0 ? "+" : "";
  return `<span class="${cls}">${sign}${Number(d).toFixed(3)}</span>`;
}
function escapeHtml(s) {
  return String(s).replace(/[&<>"']/g, (ch) =>
    ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[ch]));
}

// Render any agent output (string or structured bundle) to readable prose so it
// lines up with the golden reference for the word diff. The scoping agent
// returns { <report>: { report_title, paragraphs: [{ content, ... }] } }; we
// flatten that into "Title:\n\ncontent\n\ncontent" per report. Falls back to
// pretty JSON for shapes we don't recognise.
function toText(v) {
  if (v === null || v === undefined) return "";
  if (typeof v === "string") return v;
  const prose = reportBundleToProse(v);
  if (prose) return prose;
  try { return JSON.stringify(v, null, 2); } catch (_) { return String(v); }
}

// --- Minimal Markdown → HTML (no deps) -------------------------------------
function markdownToHtml(md) {
  const lines = escapeHtml(md).split("\n");
  const html = [];
  let inList = false;
  let inCode = false;
  for (let line of lines) {
    if (line.trim().startsWith("```")) { inCode = !inCode; continue; }
    if (inCode) { html.push(`<pre class="code-block">${line}</pre>`); continue; }
    let m;
    if ((m = line.match(/^(#{1,6})\s+(.+)$/))) {
      if (inList) { html.push("</ul>"); inList = false; }
      html.push(`<h${m[1].length}>${m[2]}</h${m[1].length}>`);
    } else if ((m = line.match(/^[-*+]\s+(.+)$/))) {
      if (!inList) { html.push("<ul>"); inList = true; }
      html.push(`<li>${m[1]}</li>`);
    } else if ((m = line.match(/^\d+\.\s+(.+)$/))) {
      if (!inList) { html.push("<ol>"); inList = true; }
      html.push(`<li>${m[1]}</li>`);
    } else if (line.trim() === "") {
      if (inList) { html.push(inList ? "</ul>" : "</ol>"); inList = false; }
      html.push("");
    } else {
      if (inList) { html.push("</ul>"); inList = false; }
      let processed = line
        .replace(/\*\*([^*]+)\*\*/g, "<strong>$1</strong>")
        .replace(/\*([^*]+)\*/g, "<em>$1</em>")
        .replace(/`([^`]+)`/g, "<code>$1</code>")
        .replace(/\[([^\]]+)\]\(([^)]+)\)/g, '<a href="$2" target="_blank">$1</a>');
      html.push(`<p>${processed}</p>`);
    }
  }
  if (inList) html.push("</ul>");
  return html.join("\n");
}

// --- Document preview: detect content type and render accordingly -----------
function previewBlock(c) {
  const obs = c.observation;
  if (!obs || !obs.output) return "";
  const meta = obs.metadata || {};
  const ctype = meta.content_type || "text";
  const output = obs.output;
  let preview = "";

  if (ctype === "markdown" && typeof output === "string") {
    preview = `<div class="doc-preview markdown-body">${markdownToHtml(output)}</div>`;
  } else if (ctype === "json" || typeof output === "object") {
    try {
      const json = typeof output === "string" ? JSON.stringify(JSON.parse(output), null, 2) : JSON.stringify(output, null, 2);
      preview = `<pre class="json-preview">${escapeHtml(json)}</pre>`;
    } catch (_) {
      preview = `<pre class="text-preview">${escapeHtml(String(output))}</pre>`;
    }
  } else if (meta.extracted_text) {
    preview = `<div class="doc-preview"><div class="doc-type-badge">${ctype.toUpperCase()} (extracted text)</div><pre class="text-preview">${escapeHtml(meta.extracted_text)}</pre></div>`;
  } else {
    preview = `<pre class="text-preview">${escapeHtml(toText(output))}</pre>`;
  }
  return `<details class="preview">
    <summary>Output preview (${escapeHtml(ctype)})</summary>
    ${preview}
  </details>`;
}

// Return prose for a report bundle (or a single report), else "" if it isn't
// one so callers can fall back to JSON.
function reportBundleToProse(v) {
  if (!v || typeof v !== "object") return "";

  const paragraphText = (rep) => {
    const paras = rep && rep.paragraphs;
    if (!Array.isArray(paras)) return null;
    return paras
      .map((p) => (p && (p.content ?? p.text ?? p.paragraph)) || "")
      .filter((s) => String(s).trim().length)
      .join("\n\n");
  };

  // Single report object: { report_title, paragraphs: [...] }.
  if (Array.isArray(v.paragraphs)) {
    const body = paragraphText(v);
    if (body === null) return "";
    const title = v.report_title || "";
    return (title ? `${title}\n\n` : "") + body;
  }

  // Bundle: { <key>: { report_title, paragraphs } , ... }.
  const sections = [];
  for (const [key, rep] of Object.entries(v)) {
    if (rep && typeof rep === "object" && Array.isArray(rep.paragraphs)) {
      const body = paragraphText(rep);
      if (body === null) continue;
      const title = rep.report_title || key;
      sections.push(`${title}\n\n${body}`);
    }
  }
  return sections.length ? sections.join("\n\n\n") : "";
}

// --- Word-level diff (LCS) for the golden-vs-agent comparison ---------------
function tokenize(s) {
  // Keep whitespace as tokens so reflowed text renders naturally.
  return s.split(/(\s+)/).filter((t) => t.length);
}

function diffTokens(a, b) {
  const n = a.length, m = b.length;
  // LCS length table.
  const dp = Array.from({ length: n + 1 }, () => new Int32Array(m + 1));
  for (let i = n - 1; i >= 0; i--)
    for (let j = m - 1; j >= 0; j--)
      dp[i][j] = a[i] === b[j] ? dp[i + 1][j + 1] + 1 : Math.max(dp[i + 1][j], dp[i][j + 1]);
  const ops = [];
  let i = 0, j = 0;
  while (i < n && j < m) {
    if (a[i] === b[j]) { ops.push(["=", a[i]]); i++; j++; }
    else if (dp[i + 1][j] >= dp[i][j + 1]) { ops.push(["-", a[i]]); i++; }
    else { ops.push(["+", b[j]]); j++; }
  }
  while (i < n) { ops.push(["-", a[i]]); i++; }
  while (j < m) { ops.push(["+", b[j]]); j++; }
  return ops;
}

// Build two side-by-side HTML columns: golden (removals highlighted) and agent
// (additions highlighted). Unchanged tokens render plain in both.
function renderDiffColumns(goldenText, agentText) {
  const ops = diffTokens(tokenize(goldenText), tokenize(agentText));
  let gold = "", agent = "";
  for (const [op, tok] of ops) {
    const safe = escapeHtml(tok);
    if (op === "=") { gold += safe; agent += safe; }
    else if (op === "-") { gold += `<span class="d-del">${safe}</span>`; }
    else { agent += `<span class="d-add">${safe}</span>`; }
  }
  return { gold, agent };
}

function diffBlock(c) {
  const golden = toText(c.golden_output);
  const agent = toText(c.observation && c.observation.output);
  if (!golden && !agent) return "";
  const identical = golden && agent && golden.trim() === agent.trim();
  let goldHtml, agentHtml;
  if (golden && agent) {
    const cols = renderDiffColumns(golden, agent);
    goldHtml = cols.gold; agentHtml = cols.agent;
  } else {
    goldHtml = escapeHtml(golden || "(no golden reference)");
    agentHtml = escapeHtml(agent || "(no agent output)");
  }
  const note = identical
    ? `<span class="chip ok-chip">exact match</span>`
    : (golden && agent ? `<span class="chip">word diff · <span class="d-del">golden-only</span> / <span class="d-add">agent-only</span></span>` : "");
  return `
    <details class="diff">
      <summary>Golden vs agent output ${note}</summary>
      <div class="diff-grid">
        <div class="diff-col">
          <div class="diff-head">Golden (ideal)</div>
          <div class="diff-body">${goldHtml || "<span class='muted'>—</span>"}</div>
        </div>
        <div class="diff-col">
          <div class="diff-head">Agent output</div>
          <div class="diff-body">${agentHtml || "<span class='muted'>—</span>"}</div>
        </div>
      </div>
    </details>`;
}

// --- Stats / calibration -----------------------------------------------------
function renderStats(s) {
  const el = $("#stats");
  if (!s) { el.innerHTML = `<div class="stat muted">No statistics for this run.</div>`; return; }
  const drift = s.drift_significant
    ? `<span class="fail">significant regression</span>` : `stable`;
  const cal = s.labeled_cases ? ""
    : `<div class="stat muted">No human labels yet — add verdicts below to compute precision/recall/F1/κ.</div>`;
  el.innerHTML = `
    <div class="stat"><span>Cases</span> ${s.n_cases} · pass rate ${pct(s.pass_rate)}</div>
    <div class="stat"><span>Mean score</span> ${num(s.mean_score)} (95% CI ${num(s.ci95_low)}–${num(s.ci95_high)}, σ ${num(s.score_stdev)})</div>
    <div class="stat"><span>Drift</span> Δ ${num(s.mean_delta)} · p ${num(s.drift_p_value, 4)} · ${drift}</div>
    ${cal}`;
}

function renderCalibration(s) {
  const el = $("#calibration");
  if (!s || !s.labeled_cases) { el.innerHTML = ""; return; }
  el.innerHTML =
    `<div class="calibration">
       <strong>Judge vs human calibration</strong>
       <span class="chip">precision ${num(s.precision)}</span>
       <span class="chip">recall ${num(s.recall)}</span>
       <span class="chip">F1 ${num(s.f1)}</span>
       <span class="chip">κ ${num(s.cohens_kappa)}</span>
       <span class="muted">(${s.labeled_cases} labeled cases)</span>
     </div>`;
}

// --- Cases + metrics ---------------------------------------------------------
const JUDGE_METRICS = new Set([
  "faithfulness", "relevance", "completeness", "coherence",
  "conciseness", "instruction_following", "pairwise_vs_golden", "groundedness",
  "rubric", "rubric_multi",
]);

function metricRow(sc) {
  const status = sc.passed ? `<span class="pass">✓</span>` : `<span class="fail">✗</span>`;
  const badges = [];
  if (sc.critical) badges.push(`<span class="badge badge-critical">critical</span>`);
  if (JUDGE_METRICS.has(sc.metric)) badges.push(`<span class="badge badge-judge">judge</span>`);
  if (sc.unstable) badges.push(`<span class="badge badge-warn">unstable</span>`);
  const delta = fmtDelta(sc.delta);
  const variance = sc.variance === null || sc.variance === undefined ? "" : `var ${num(sc.variance, 4)}`;
  const raw = sc.raw_value === null || sc.raw_value === undefined ? "" : `raw ${num(sc.raw_value)} ${sc.unit || ""}`;
  const hasReasoning = sc.rationale || (sc.evidence && sc.evidence.length);
  const detail = hasReasoning
    ? `<tr class="metric-detail"><td colspan="7">
         <details class="reasoning">
           <summary>Evaluator reasoning</summary>
           ${sc.rationale ? `<div class="rationale">${escapeHtml(sc.rationale)}</div>` : ""}
           ${(sc.evidence || []).map((e) => `<div class="evidence">• ${escapeHtml(e)}</div>`).join("")}
         </details>
       </td></tr>`
    : "";
  const pctScore = Math.max(0, Math.min(1, Number(sc.score) || 0)) * 100;
  const meter = `<span class="meter"><span style="width:${pctScore}%"></span></span>`;
  return `<tr class="metric-row">
      <td>${sc.metric} ${badges.join(" ")}</td>
      <td>${meter}${num(sc.score)}</td><td>${num(sc.threshold)}</td>
      <td>${status}</td><td>${sc.weight}</td><td>${delta}</td>
      <td class="muted">${[raw, variance].filter(Boolean).join(" · ")}</td>
    </tr>${detail}`;
}

function renderCases(run) {
  const el = $("#cases");
  el.innerHTML = (run.case_results || []).map((c) => `
    <details class="case" ${c.passed ? "" : "open"}>
      <summary>
        <span class="${c.passed ? "pass" : "fail"}">${c.passed ? "PASS" : "FAIL"}</span>
        <strong>${escapeHtml(c.case_id)}</strong>
        <span class="muted">score ${num(c.weighted_score)} · Δ ${num(c.weighted_delta)}</span>
      </summary>
      ${previewBlock(c)}
      ${diffBlock(c)}
      <table class="metrics">
        <thead><tr><th>Metric</th><th>Score</th><th>Thr</th><th>Gate</th><th>Wt</th><th>Δ</th><th>Audit</th></tr></thead>
        <tbody>${c.scores.map(metricRow).join("")}</tbody>
      </table>
    </details>`).join("");
}

function populateLabelCases(run) {
  $("#label-case").innerHTML = (run.case_results || [])
    .map((c) => `<option value="${escapeHtml(c.case_id)}">${escapeHtml(c.case_id)} (${c.passed ? "PASS" : "FAIL"})</option>`)
    .join("");
}

async function submitLabel() {
  const status = $("#label-status");
  const body = {
    case_id: $("#label-case").value,
    verdict: $("#label-verdict").value,
    labeler: $("#label-by").value || "anonymous",
    run_id: runId,
  };
  try {
    const res = await fetch("api/labels", {
      method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body),
    });
    if (!res.ok) throw new Error((await res.json()).detail || "failed");
    status.textContent = "saved — re-run to update calibration stats";
  } catch (e) { status.textContent = `error: ${e.message}`; }
}

async function load() {
  if (!runId) { pill("no run id", "bad"); $("#stats").innerHTML = `<div class="stat fail">No ?run=&lt;id&gt; in the URL.</div>`; return; }
  let run;
  try {
    const res = await fetch(`api/runs/${encodeURIComponent(runId)}`);
    if (!res.ok) { pill("not found", "bad"); $("#stats").innerHTML = `<div class="stat fail">Run '${escapeHtml(runId)}' not found.</div>`; return; }
    run = await res.json();
  } catch (e) { pill("unreachable", "bad"); return; }

  pill(run.passed ? "PASS" : "FAIL", run.passed ? "ok" : "bad");
  $("#m-agent").textContent = run.agent_id;
  $("#m-dataset").textContent = `${run.dataset_id} · v${run.dataset_version}`;
  $("#m-runid").textContent = run.run_id;
  $("#m-score").textContent = num(run.weighted_score);
  $("#m-delta").innerHTML = fmtDelta(run.weighted_delta);
  $("#m-when").textContent = new Date(run.created_at).toLocaleString();

  renderStats(run.stats);
  renderCalibration(run.stats);
  renderCases(run);
  populateLabelCases(run);
  $("#detail").textContent = JSON.stringify(run, null, 2);
  $("#label-submit").addEventListener("click", submitLabel);
}

load();
