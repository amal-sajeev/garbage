import sys
import os
from pathlib import Path
import uvicorn

sys.path.insert(0, str(Path(__file__).resolve().parent))

from main import app
from config import Config

if __name__ == "__main__":
    root_path = os.getenv("ROOT_PATH", "")
    uvicorn.run(app, host="0.0.0.0", port=Config.PORT, root_path=root_path)