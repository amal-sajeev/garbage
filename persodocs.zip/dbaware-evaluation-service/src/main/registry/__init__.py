"""Agent registry: auto-discovers src/agents/<agent_id>/ folders.

Each agent folder holds:
  agent.yaml          - AgentConfig
  dataset.json        - the golden set (Dataset)
  metrics_stub.json   - stubbed metrics API response
  custom_tests.py     - optional bespoke scorers (imported => self-registers)

Adding an agent requires no core code changes.
"""

from __future__ import annotations

import importlib.util
import json
from pathlib import Path

import yaml

from config import Config
from models import AgentConfig, Dataset


class RegisteredAgent:
    def __init__(self, folder: Path, config: AgentConfig, dataset: Dataset):
        self.folder = folder
        self.config = config
        self.dataset = dataset

    @property
    def metrics_stub_path(self) -> Path:
        return self.folder / self.config.metrics_stub_file


class Registry:
    def __init__(self, agents_dir: Path | None = None):
        self._dir = agents_dir or Config.AGENTS_DIR
        self._agents: dict[str, RegisteredAgent] = {}

    def load(self) -> "Registry":
        self._agents.clear()
        if not self._dir.exists():
            return self
        for folder in sorted(p for p in self._dir.iterdir() if p.is_dir()):
            cfg_file = folder / "agent.yaml"
            if not cfg_file.exists():
                continue
            config = AgentConfig.model_validate(yaml.safe_load(cfg_file.read_text("utf-8-sig")))
            dataset = Dataset.model_validate(
                json.loads((folder / config.dataset_file).read_text("utf-8-sig"))
            )
            self._import_custom_tests(folder)
            self._agents[config.agent_id] = RegisteredAgent(folder, config, dataset)
        self.validate()
        return self

    def validate(self) -> None:
        """Pre-flight: verify every metric's scorer is registered.

        Catches config typos (e.g. misspelled scorer name) at startup instead of
        at the first evaluation run. Runs AFTER all custom_tests.py are imported
        so custom scorers are included in the registry.
        """
        from scorers import all_scorers  # lazy: avoid circular import

        known = all_scorers()
        errors: list[str] = []
        for agent_id, agent in self._agents.items():
            for metric in agent.dataset.metrics:
                if metric.scorer not in known:
                    errors.append(
                        f"  agent '{agent_id}' metric '{metric.name}': "
                        f"unknown scorer '{metric.scorer}'"
                    )
            if not agent.dataset.cases:
                errors.append(
                    f"  agent '{agent_id}': dataset has no cases"
                )
        if errors:
            msg = "Dataset validation failed:\n" + "\n".join(errors)
            raise ValueError(msg)

    def _import_custom_tests(self, folder: Path) -> None:
        custom = folder / "custom_tests.py"
        if not custom.exists():
            return
        spec = importlib.util.spec_from_file_location(
            f"custom_tests_{folder.name}", custom
        )
        if spec and spec.loader:
            module = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(module)  # decorators self-register scorers

    def get(self, agent_id: str) -> RegisteredAgent:
        if agent_id not in self._agents:
            raise KeyError(f"Unknown agent '{agent_id}'. Known: {sorted(self._agents)}")
        return self._agents[agent_id]

    def list(self) -> list[dict]:
        return [
            {
                "agent_id": a.config.agent_id,
                "name": a.config.name,
                "dataset_id": a.dataset.dataset_id,
                "dataset_version": a.dataset.version,
                "cases": len(a.dataset.cases),
                "metrics": [m.name for m in a.dataset.metrics],
            }
            for a in self._agents.values()
        ]
