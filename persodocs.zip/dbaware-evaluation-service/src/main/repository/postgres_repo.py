"""CloudSQL (Postgres) implementation of EvaluationRepository.

Mirrors the SQLite backend's surface but talks to Google Cloud SQL via SQLAlchemy
and the pg8000 driver. Two transports are supported:

* **Cloud SQL Python Connector** (default) - IAM/ADC auth, used in GKE with
  Workload Identity Federation.
* **TCP via the Cloud SQL Auth Proxy** (set ``DB_HOST``) - for local dev behind a
  corporate HTTP proxy, where the in-process Connector cannot reach the SQL
  Admin API or the instance's :3307 socket. The Auth Proxy runs as a separate
  local process and the app connects to its 127.0.0.1 listener.

Authentication for the Connector path is IAM/ADC - the same credential chain as
the Vertex judge (see
docs/VERTEX_INTEGRATION.md): `gcloud auth application-default login` locally,
Workload Identity Federation in GKE. **No passwords are stored in the repo**;
they are read from env or Google Secret Manager at runtime.

Two roles are supported (banking least-privilege):
- OWNER (`DB_OWNER_USER`) runs the one-time DDL in `init_schema()`.
- USER  (`DB_USER`) is the least-privilege runtime account for reads/writes.

SQL is portable: DDL uses `CREATE TABLE IF NOT EXISTS` and writes use Postgres
`INSERT ... ON CONFLICT ... DO UPDATE` (the equivalent of SQLite's
`INSERT OR REPLACE`).
"""

from __future__ import annotations

from datetime import datetime, timedelta, UTC

from config import Config
from models import HumanLabel, RunRecord
from .base import EvaluationRepository


class CloudSqlRepository(EvaluationRepository):
    """Postgres-backed repository using the Cloud SQL Python Connector."""

    def __init__(self) -> None:
        from sqlalchemy import create_engine

        if not Config.DB_NAME:
            raise RuntimeError(
                "CloudSQL requires DB_NAME. Set it in the environment (see .env.example)."
            )

        self._use_tcp = bool(Config.DB_HOST)
        self._connector = None

        if self._use_tcp:
            self._require_instance = False
        else:
            import google.auth
            from google.cloud.sql.connector import Connector, IPTypes

            if not Config.DB_INSTANCE_CONNECTION_NAME:
                raise RuntimeError(
                    "CloudSQL Connector mode requires DB_INSTANCE_CONNECTION_NAME. "
                    "Set it, or set DB_HOST to use the Cloud SQL Auth Proxy instead."
                )
            try:
                google.auth.default()
            except Exception as exc:
                raise RuntimeError(
                    "No Application Default Credentials available for CloudSQL. "
                    "Locally run: gcloud auth application-default login. In GKE, "
                    "ensure the Workload Identity Federation credential config is "
                    "mounted and GOOGLE_APPLICATION_CREDENTIALS points at it."
                ) from exc

            self._ip_type = (
                IPTypes.PRIVATE if Config.DB_IP_TYPE.upper() == "PRIVATE" else IPTypes.PUBLIC
            )
            self._connector = Connector(ip_type=self._ip_type)

        self._user_password = Config.resolve_secret(
            Config.DB_PASSWORD, Config.DB_PASSWORD_SECRET
        )
        self._owner_password = Config.resolve_secret(
            Config.DB_OWNER_PASSWORD, Config.DB_OWNER_PASSWORD_SECRET
        )
        if not self._user_password:
            raise RuntimeError(
                "No DB_PASSWORD (or DB_PASSWORD_SECRET) provided for the runtime "
                "CloudSQL user. Passwords must come from env/GSM, never the repo."
            )

        self._engine = create_engine(
            "postgresql+pg8000://",
            creator=lambda: self._connect(Config.DB_USER, self._user_password),
            pool_pre_ping=True,
        )

    def _connect(self, user: str, password: str):
        """Open one pg8000 connection, via the Cloud SQL Auth Proxy (TCP mode) or
        the Cloud SQL Python Connector (Connector mode)."""
        if self._use_tcp:
            import pg8000.dbapi

            return pg8000.dbapi.connect(
                host=Config.DB_HOST,
                port=Config.DB_PORT,
                user=user,
                password=password,
                database=Config.DB_NAME,
            )
        return self._connector.connect(
            Config.DB_INSTANCE_CONNECTION_NAME,
            "pg8000",
            user=user,
            password=password,
            db=Config.DB_NAME,
        )

    def init_schema(self) -> None:
        """Verify the Postgres schema exists — it is now owned by Liquibase.
        """
        from sqlalchemy import text

        try:
            with self._engine.begin() as conn:
                self._set_search_path(conn)
                missing = [
                    tbl
                    for tbl in ("runs", "baselines", "labels")
                    if conn.execute(
                        text("SELECT to_regclass(:qualified)"),
                        {
                            "qualified": (
                                f'"{Config.DB_SCHEMA}".{tbl}'
                                if Config.DB_SCHEMA and Config.DB_SCHEMA != "public"
                                else tbl
                            )
                        },
                    ).scalar()
                    is None
                ]
        except Exception as exc:
            raise RuntimeError(
                "Could not verify the CloudSQL schema. Ensure the Cloud SQL Auth "
                "Proxy is running and the Liquibase migration has been applied "
                "(see dbaware-evaluation-service-liquibase/). Original error: "
                f"{type(exc).__name__}: {exc}"
            ) from exc

        if missing:
            raise RuntimeError(
                "CloudSQL schema is missing tables "
                f"{missing} in schema '{Config.DB_SCHEMA}'. The schema is managed "
                "by Liquibase — apply it before starting the service:\n"
                "  cd dbaware-monitoring-liquibase\n"
                "  mvn -s settings.xml org.liquibase:liquibase-maven-plugin:update "
                "(contexts=DBAWARE_MONITORING; see env_config/ and the CICD workflow)"
            )

    def save_run(self, run: RunRecord) -> None:
        from sqlalchemy import text

        with self._engine.begin() as conn:
            self._set_search_path(conn)
            conn.execute(
                text(
                    """INSERT INTO runs
                       (run_id, agent_id, dataset_id, dataset_version,
                        weighted_score, weighted_delta, passed, created_at, detail_json)
                       VALUES (:run_id, :agent_id, :dataset_id, :dataset_version,
                               :weighted_score, :weighted_delta, :passed, :created_at, :detail_json)
                       ON CONFLICT (run_id) DO UPDATE SET
                           agent_id = EXCLUDED.agent_id,
                           dataset_id = EXCLUDED.dataset_id,
                           dataset_version = EXCLUDED.dataset_version,
                           weighted_score = EXCLUDED.weighted_score,
                           weighted_delta = EXCLUDED.weighted_delta,
                           passed = EXCLUDED.passed,
                           created_at = EXCLUDED.created_at,
                           detail_json = EXCLUDED.detail_json"""
                ),
                {
                    "run_id": run.run_id, "agent_id": run.agent_id,
                    "dataset_id": run.dataset_id, "dataset_version": run.dataset_version,
                    "weighted_score": run.weighted_score, "weighted_delta": run.weighted_delta,
                    "passed": run.passed, "created_at": run.created_at,
                    "detail_json": run.model_dump_json(),
                },
            )

    def get_run(self, run_id: str) -> RunRecord | None:
        from sqlalchemy import text

        with self._engine.begin() as conn:
            self._set_search_path(conn)
            row = conn.execute(
                text("SELECT detail_json FROM runs WHERE run_id = :run_id"),
                {"run_id": run_id},
            ).fetchone()
        if not row:
            return None
        detail = row[0]
        if isinstance(detail, str):
            return RunRecord.model_validate_json(detail)
        return RunRecord.model_validate(detail)

    def list_runs(self, agent_id: str | None = None, limit: int = 50, before: str | None = None) -> list[dict]:
        from sqlalchemy import text

        query = (
            "SELECT run_id, agent_id, dataset_id, dataset_version, weighted_score, "
            "weighted_delta, passed, created_at FROM runs"
        )
        params: dict = {"limit": limit}
        conditions: list[str] = []
        if agent_id:
            conditions.append("agent_id = :agent_id")
            params["agent_id"] = agent_id
        if before:
            conditions.append("created_at < :before")
            params["before"] = before
        if conditions:
            query += " WHERE " + " AND ".join(conditions)
        query += " ORDER BY created_at DESC LIMIT :limit"
        with self._engine.begin() as conn:
            self._set_search_path(conn)
            rows = conn.execute(text(query), params).mappings().all()
        return [dict(r) for r in rows]

    def get_baseline(self, agent_id: str, dataset_version: str, metric: str) -> float | None:
        from sqlalchemy import text

        with self._engine.begin() as conn:
            self._set_search_path(conn)
            row = conn.execute(
                text(
                    "SELECT baseline_value FROM baselines "
                    "WHERE agent_id=:a AND dataset_version=:v AND metric=:m"
                ),
                {"a": agent_id, "v": dataset_version, "m": metric},
            ).fetchone()
        return float(row[0]) if row else None

    def set_baseline(self, agent_id: str, dataset_version: str, metric: str, value: float) -> None:
        from sqlalchemy import text

        with self._engine.begin() as conn:
            self._set_search_path(conn)
            conn.execute(
                text(
                    """INSERT INTO baselines (agent_id, dataset_version, metric, baseline_value)
                       VALUES (:a, :v, :m, :val)
                       ON CONFLICT (agent_id, dataset_version, metric)
                       DO UPDATE SET baseline_value = EXCLUDED.baseline_value"""
                ),
                {"a": agent_id, "v": dataset_version, "m": metric, "val": value},
            )

    def save_label(self, label: HumanLabel) -> None:
        from sqlalchemy import text

        with self._engine.begin() as conn:
            self._set_search_path(conn)
            conn.execute(
                text(
                    """INSERT INTO labels
                       (case_id, verdict, score, labeler, note, run_id, created_at)
                       VALUES (:case_id, :verdict, :score, :labeler, :note, :run_id, :created_at)
                       ON CONFLICT (case_id) DO UPDATE SET
                           verdict = EXCLUDED.verdict,
                           score = EXCLUDED.score,
                           labeler = EXCLUDED.labeler,
                           note = EXCLUDED.note,
                           run_id = EXCLUDED.run_id,
                           created_at = EXCLUDED.created_at"""
                ),
                label.model_dump(),
            )

    def list_labels(self) -> list[HumanLabel]:
        from sqlalchemy import text

        with self._engine.begin() as conn:
            self._set_search_path(conn)
            rows = conn.execute(
                text(
                    "SELECT case_id, verdict, score, labeler, note, run_id, created_at "
                    "FROM labels ORDER BY created_at DESC"
                )
            ).mappings().all()
        return [HumanLabel(**dict(r)) for r in rows]

    def _set_search_path(self, conn) -> None:
        from sqlalchemy import text

        if Config.DB_SCHEMA and Config.DB_SCHEMA != "public":
            conn.execute(text(f'SET search_path TO "{Config.DB_SCHEMA}"'))

    def delete_old_runs(self, days: int) -> int:
        from sqlalchemy import text

        if days <= 0:
            return 0
        cutoff = (datetime.now(UTC) - timedelta(days=days)).isoformat()
        with self._engine.begin() as conn:
            self._set_search_path(conn)
            result = conn.execute(
                text("DELETE FROM runs WHERE created_at < :cutoff"),
                {"cutoff": cutoff},
            )
            return result.rowcount
