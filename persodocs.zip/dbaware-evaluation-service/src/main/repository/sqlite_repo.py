"""SQLite implementation of EvaluationRepository (WAL-enabled).

Parses the `EVAL_DB_URL` (sqlite:///path). A CloudSQL implementation would live
alongside this file and be selected by `build_repository` on a postgres:// URL.
"""

from __future__ import annotations

import sqlite3
from datetime import datetime, timedelta, UTC
from pathlib import Path

from models import HumanLabel, RunRecord
from .base import EvaluationRepository

_SCHEMA = """
CREATE TABLE IF NOT EXISTS runs (
    run_id TEXT PRIMARY KEY,
    agent_id TEXT NOT NULL,
    dataset_id TEXT NOT NULL,
    dataset_version TEXT NOT NULL,
    weighted_score REAL NOT NULL,
    weighted_delta REAL NOT NULL,
    passed INTEGER NOT NULL,
    created_at TEXT NOT NULL,
    detail_json TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS baselines (
    agent_id TEXT NOT NULL,
    dataset_version TEXT NOT NULL,
    metric TEXT NOT NULL,
    baseline_value REAL NOT NULL,
    PRIMARY KEY (agent_id, dataset_version, metric)
);
CREATE TABLE IF NOT EXISTS labels (
    case_id TEXT PRIMARY KEY,
    verdict TEXT NOT NULL,
    score REAL,
    labeler TEXT,
    note TEXT,
    run_id TEXT,
    created_at TEXT NOT NULL
);
"""


class SqliteRepository(EvaluationRepository):
    def __init__(self, db_path: str):
        self._path = db_path
        Path(db_path).parent.mkdir(parents=True, exist_ok=True)

    def _connect(self) -> sqlite3.Connection:
        conn = sqlite3.connect(self._path)
        conn.execute("PRAGMA journal_mode=WAL;")
        conn.row_factory = sqlite3.Row
        return conn

    def init_schema(self) -> None:
        with self._connect() as conn:
            conn.executescript(_SCHEMA)

    def save_run(self, run: RunRecord) -> None:
        with self._connect() as conn:
            conn.execute(
                """INSERT OR REPLACE INTO runs
                   (run_id, agent_id, dataset_id, dataset_version,
                    weighted_score, weighted_delta, passed, created_at, detail_json)
                   VALUES (?,?,?,?,?,?,?,?,?)""",
                (
                    run.run_id, run.agent_id, run.dataset_id, run.dataset_version,
                    run.weighted_score, run.weighted_delta, int(run.passed),
                    run.created_at, run.model_dump_json(),
                ),
            )

    def get_run(self, run_id: str) -> RunRecord | None:
        with self._connect() as conn:
            row = conn.execute(
                "SELECT detail_json FROM runs WHERE run_id = ?", (run_id,)
            ).fetchone()
        return RunRecord.model_validate_json(row["detail_json"]) if row else None

    def list_runs(self, agent_id: str | None = None, limit: int = 50, before: str | None = None) -> list[dict]:
        query = (
            "SELECT run_id, agent_id, dataset_id, dataset_version, weighted_score, "
            "weighted_delta, passed, created_at FROM runs"
        )
        params: list = []
        conditions: list[str] = []
        if agent_id:
            conditions.append("agent_id = ?")
            params.append(agent_id)
        if before:
            conditions.append("created_at < ?")
            params.append(before)
        if conditions:
            query += " WHERE " + " AND ".join(conditions)
        query += " ORDER BY created_at DESC LIMIT ?"
        params.append(limit)
        with self._connect() as conn:
            rows = conn.execute(query, params).fetchall()
        return [dict(r) for r in rows]

    def get_baseline(self, agent_id: str, dataset_version: str, metric: str) -> float | None:
        with self._connect() as conn:
            row = conn.execute(
                "SELECT baseline_value FROM baselines "
                "WHERE agent_id=? AND dataset_version=? AND metric=?",
                (agent_id, dataset_version, metric),
            ).fetchone()
        return float(row["baseline_value"]) if row else None

    def set_baseline(self, agent_id: str, dataset_version: str, metric: str, value: float) -> None:
        with self._connect() as conn:
            conn.execute(
                "INSERT OR REPLACE INTO baselines "
                "(agent_id, dataset_version, metric, baseline_value) VALUES (?,?,?,?)",
                (agent_id, dataset_version, metric, value),
            )

    def save_label(self, label: HumanLabel) -> None:
        with self._connect() as conn:
            conn.execute(
                """INSERT OR REPLACE INTO labels
                   (case_id, verdict, score, labeler, note, run_id, created_at)
                   VALUES (?,?,?,?,?,?,?)""",
                (
                    label.case_id, label.verdict, label.score, label.labeler,
                    label.note, label.run_id, label.created_at,
                ),
            )

    def list_labels(self) -> list[HumanLabel]:
        with self._connect() as conn:
            rows = conn.execute(
                "SELECT case_id, verdict, score, labeler, note, run_id, created_at "
                "FROM labels ORDER BY created_at DESC"
            ).fetchall()
        return [HumanLabel(**dict(r)) for r in rows]

    def delete_old_runs(self, days: int) -> int:
        if days <= 0:
            return 0
        cutoff = (datetime.now(UTC) - timedelta(days=days)).isoformat()
        with self._connect() as conn:
            cursor = conn.execute("DELETE FROM runs WHERE created_at < ?", (cutoff,))
            return cursor.rowcount
