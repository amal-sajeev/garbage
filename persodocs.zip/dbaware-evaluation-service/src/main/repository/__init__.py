"""Persistence layer for the CTNA Evaluation Service.

`EvaluationRepository` is the swappable interface. `SqliteRepository` is the
local-dev/offline implementation; `CloudSqlRepository` is the CloudSQL (Postgres)
implementation. `build_repository()` selects one from `EVAL_DB_URL` without the
runner or scorers ever knowing which backend is active.
"""

from config import Config
from .base import EvaluationRepository
from .sqlite_repo import SqliteRepository

__all__ = [
    "EvaluationRepository",
    "SqliteRepository",
    "build_repository",
]


def build_repository() -> EvaluationRepository:
    """Factory: choose a persistence backend from EVAL_DB_URL.

    - `sqlite:///path`         -> local SQLite (default, fully offline)
    - `postgresql[...]://...`  -> CloudSQL Postgres via the Cloud SQL Connector

    The Postgres deps and ADC are only touched on the postgres branch, so the
    offline path never needs them.
    """
    url = Config.DB_URL
    if url.startswith("sqlite:///"):
        repo: EvaluationRepository = SqliteRepository(url[len("sqlite:///"):])
        repo.init_schema()
        return repo
    if url.startswith("postgres"):  # postgresql:// or postgres://
        from .postgres_repo import CloudSqlRepository  # lazy: avoid pg deps offline

        repo = CloudSqlRepository()
        repo.init_schema()
        return repo
    raise NotImplementedError(
        f"Unsupported EVAL_DB_URL '{url}'. Use sqlite:/// for local/offline or "
        "postgresql:// for CloudSQL."
    )
