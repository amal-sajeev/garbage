"""Aggregation & Gate: weighted score, weighted delta, and the pass/fail gate.

  weighted score  S = sum(s_i * w_i) / sum(w_i)
  weighted delta  D = sum((s_i - b_i) * w_i) / sum(w_i)     (drift vs baseline)
  gate: no critical metric fails
        AND all metrics >= threshold
        AND S >= dataset_threshold
        AND D >= -tolerance

Banking-grade additions:
  * critical metrics (e.g. safety/compliance) act as hard vetoes.
  * lower-is-better / unbounded metrics (latency, cost, error rate) are
    normalised to a 0..1 quality score before they enter the weighted mean.
"""

from __future__ import annotations

import math
from statistics import NormalDist, mean, pstdev, stdev

from config import Config
from models import CaseResult, MetricSpec, RunStats, Score


def normalise(value: float, spec: MetricSpec) -> float:
    """Map a raw metric measurement to a 0..1 quality score.

    - higher_is_better ratios pass through (clamped to [0,1]).
    - lower_is_better / unbounded metrics use [norm_min, norm_max] bounds:
      value ≤ norm_min → 1.0 (best), value ≥ norm_max → 0.0 (worst), linear
      in between. This lets latency/cost compose into the weighted score.
    """
    if spec.direction == "lower_is_better":
        lo = spec.norm_min if spec.norm_min is not None else 0.0
        hi = spec.norm_max if spec.norm_max is not None else max(lo + 1e-9, value)
        if hi <= lo:
            return 1.0 if value <= lo else 0.0
        q = (hi - value) / (hi - lo)
        return max(0.0, min(1.0, q))
    # higher_is_better
    if spec.norm_min is not None and spec.norm_max is not None and spec.norm_max > spec.norm_min:
        q = (value - spec.norm_min) / (spec.norm_max - spec.norm_min)
        return max(0.0, min(1.0, q))
    return max(0.0, min(1.0, value)) if 0.0 <= value <= 1.0 else value


def weighted_score(scores: list[Score]) -> float:
    total_w = sum(s.weight for s in scores)
    if total_w == 0:
        return 0.0
    return sum(s.score * s.weight for s in scores) / total_w


def weighted_delta(scores: list[Score]) -> float:
    """Sum((score - baseline) * wt) / sum(wt); metrics with no baseline contribute 0 delta."""
    total_w = sum(s.weight for s in scores)
    if total_w == 0:
        return 0.0
    acc = 0.0
    for s in scores:
        if s.baseline is not None:
            acc += (s.score - s.baseline) * s.weight
    return acc / total_w


def critical_failures(scores: list[Score]) -> list[str]:
    """Names of critical metrics that did not pass — these veto the run."""
    return [s.metric for s in scores if s.critical and not s.passed]


def gate(
    scores: list[Score],
    *,
    dataset_threshold: float = Config.DATASET_THRESHOLD,
    regression_tolerance: float = Config.REGRESSION_TOLERANCE,
) -> tuple[bool, float, float]:
    """Return (passed, weighted_score, weighted_delta).

    A single failing critical metric fails the case regardless of the weighted
    score — the banking-grade veto.
    """
    s = weighted_score(scores)
    d = weighted_delta(scores)
    no_critical_failures = not critical_failures(scores)
    all_thresholds_met = all(sc.passed for sc in scores)
    passed = (
        no_critical_failures
        and all_thresholds_met
        and s >= dataset_threshold
        and d >= -regression_tolerance
    )
    return passed, s, d


# --- Dataset-level statistics (rigor across all cases in a run) ---------------

_Z95 = 1.959963984540054  # standard-normal quantile for a two-sided 95% CI


def mean_confidence_interval(values: list[float], z: float = _Z95) -> tuple[float, float, float, float]:
    """Return (mean, stdev, ci_low, ci_high) for the sample mean (z-approx).

    Uses the sample standard deviation and the standard error mean/√n. For a
    single observation the interval collapses to the point estimate.
    """
    n = len(values)
    if n == 0:
        return 0.0, 0.0, 0.0, 0.0
    m = mean(values)
    if n == 1:
        return m, 0.0, m, m
    sd = stdev(values)
    se = sd / math.sqrt(n)
    return m, sd, m - z * se, m + z * se


def drift_significance(deltas: list[float]) -> tuple[float, float | None, bool]:
    """Two-sided z-test that the mean per-case delta differs from zero.

    Returns (mean_delta, p_value, significant_regression). `significant` is True
    only for a real *drop* (mean_delta < 0 and p < 0.05) — noise-free evidence of
    a regression, the signal a banking gate should escalate on.
    """
    n = len(deltas)
    if n == 0:
        return 0.0, None, False
    md = mean(deltas)
    if n < 2:
        return md, None, False
    sd = pstdev(deltas)
    if sd == 0.0:
        # No variance: any non-zero mean is a deterministic shift.
        p = 0.0 if md != 0.0 else 1.0
    else:
        z = md / (sd / math.sqrt(n))
        p = 2.0 * (1.0 - NormalDist().cdf(abs(z)))
    return md, p, (md < 0.0 and p < 0.05)


def classification_stats(
    predictions: list[bool], truths: list[bool]
) -> dict[str, float]:
    """Confusion-derived precision/recall/F1 + Cohen's κ for gate-vs-human.

    prediction = the automated gate's pass decision; truth = the human label.
    """
    tp = sum(1 for p, t in zip(predictions, truths, strict=False) if p and t)
    fp = sum(1 for p, t in zip(predictions, truths, strict=False) if p and not t)
    fn = sum(1 for p, t in zip(predictions, truths, strict=False) if not p and t)
    tn = sum(1 for p, t in zip(predictions, truths, strict=False) if not p and not t)
    n = tp + fp + fn + tn
    precision = tp / (tp + fp) if (tp + fp) else 0.0
    recall = tp / (tp + fn) if (tp + fn) else 0.0
    f1 = (2 * precision * recall / (precision + recall)) if (precision + recall) else 0.0
    # Cohen's kappa: agreement corrected for chance.
    po = (tp + tn) / n if n else 0.0
    p_pred_pos = (tp + fp) / n if n else 0.0
    p_true_pos = (tp + fn) / n if n else 0.0
    pe = p_pred_pos * p_true_pos + (1 - p_pred_pos) * (1 - p_true_pos)
    kappa = (po - pe) / (1 - pe) if (1 - pe) else 1.0
    return {"precision": precision, "recall": recall, "f1": f1, "cohens_kappa": kappa}


def run_statistics(
    case_results: list[CaseResult],
    labels: dict[str, str] | None = None,
) -> RunStats:
    """Compute dataset-level statistics for a completed run.

    `labels` maps case_id -> 'pass'/'fail' expert ground truth; when present the
    judge-vs-human calibration fields (precision/recall/F1/κ) are populated.
    """
    n = len(case_results)
    if n == 0:
        return RunStats()

    scores = [c.weighted_score for c in case_results]
    deltas = [c.weighted_delta for c in case_results]
    m, sd, lo, hi = mean_confidence_interval(scores)
    md, p, significant = drift_significance(deltas)
    pass_rate = sum(1 for c in case_results if c.passed) / n

    stats = RunStats(
        n_cases=n,
        pass_rate=pass_rate,
        mean_score=m,
        score_stdev=sd,
        ci95_low=lo,
        ci95_high=hi,
        mean_delta=md,
        drift_p_value=p,
        drift_significant=significant,
    )

    labels = labels or {}
    matched = [(c.passed, labels[c.case_id] == "pass")
               for c in case_results if c.case_id in labels]
    if matched:
        preds = [p for p, _ in matched]
        truths = [t for _, t in matched]
        cls = classification_stats(preds, truths)
        stats.labeled_cases = len(matched)
        stats.precision = cls["precision"]
        stats.recall = cls["recall"]
        stats.f1 = cls["f1"]
        stats.cohens_kappa = cls["cohens_kappa"]
    return stats
