"""Human-in-the-loop label store (in-memory, schema-independent).

Experts post a pass/fail verdict per case; the runner uses these as ground
truth to calibrate the automated gate/judge (precision/recall/F1, Cohen's κ in
`aggregation.run_statistics`). Kept in memory so it works fully offline and does
not depend on the CloudSQL schema; a persistent backend can replace this later
without touching callers.
"""

from __future__ import annotations

from datetime import datetime, UTC

from models import HumanLabel


class LabelStore:
    def __init__(self) -> None:
        # case_id -> latest HumanLabel (the most recent verdict wins).
        self._by_case: dict[str, HumanLabel] = {}

    def add(self, label: HumanLabel) -> HumanLabel:
        if not label.created_at:
            label.created_at = datetime.now(UTC).isoformat()
        self._by_case[label.case_id] = label
        return label

    def get(self, case_id: str) -> HumanLabel | None:
        return self._by_case.get(case_id)

    def all(self) -> list[HumanLabel]:
        return sorted(self._by_case.values(), key=lambda x: x.created_at, reverse=True)

    def verdict_map(self) -> dict[str, str]:
        """case_id -> 'pass'/'fail' for use as ground truth in statistics."""
        return {cid: lbl.verdict for cid, lbl in self._by_case.items()}


# Module-level singleton (mirrors the capture_store pattern).
label_store = LabelStore()
