"""Vertex AI judge model factory.

Reuses the single Vertex pattern from docs/VERTEX_INTEGRATION.md:
`ChatGoogleGenerativeAI(project=...)` selects Vertex; auth is ADC/WIF, no API
key. A fail-fast guard runs before the client is built to avoid the misleading
`'BaseApiClient' object has no attribute '_async_httpx_client'` error.
"""

from __future__ import annotations

import threading

import google.auth
from langchain_google_genai import ChatGoogleGenerativeAI
from pydantic import BaseModel, Field

from config import Config


class JudgeVerdict(BaseModel):
    """Typed judge output. `passed` is re-applied in code, never trusted here."""
    score: float = Field(ge=0.0, le=1.0)
    passed: bool = False
    rationale: str = ""
    evidence: list[str] = Field(default_factory=list)


class PairwiseVerdict(BaseModel):
    """Typed A/B comparison output. `winner` is 'A', 'B', or 'tie'.

    `score` is the preference strength for the AGENT answer (candidate A): 1.0 =
    A clearly better, 0.5 = tie, 0.0 = B (baseline) clearly better.
    """
    winner: str = Field(default="tie", description="'A' | 'B' | 'tie'")
    score: float = Field(default=0.5, ge=0.0, le=1.0)
    rationale: str = ""
    evidence: list[str] = Field(default_factory=list)


class RubricCriterionScore(BaseModel):
    """One criterion's score in a multi-criteria rubric verdict."""
    criterion: str
    score: float = Field(ge=0.0, le=1.0)
    rationale: str = ""


class MultiRubricVerdict(BaseModel):
    """Typed multi-criteria judge output. Each criterion gets its own score."""
    scores: list[RubricCriterionScore] = Field(default_factory=list)
    overall_rationale: str = ""


def require_vertex_credentials() -> str:
    """Guard + return the resolved ADC credential class name (for /api/health)."""
    if not Config.PROJECT_NAME:
        raise RuntimeError(
            "PROJECT_NAME is not set; the evaluation judge requires Vertex AI. "
            "Set it in .env to your Google Cloud project id."
        )
    try:
        creds, _ = google.auth.default()
    except Exception as exc:
        raise RuntimeError(
            "No Application Default Credentials available for Vertex AI. "
            "Locally, run: gcloud auth application-default login. "
            "In GKE, check the Workload Identity Federation credential config is "
            f"mounted and GOOGLE_APPLICATION_CREDENTIALS points at it. ({exc})"
        ) from exc
    return type(creds).__name__


def build_judge():
    """Return a ChatGoogleGenerativeAI bound to structured JudgeVerdict output."""
    return build_judge_for(JudgeVerdict)


# Judge clients are expensive to construct (ADC resolution + client wiring) and
# are safe to share across threads. Under the runner's concurrent per-metric
# dispatch many scorers request a client for the same schema at once, so memoise
# one client per structured-output schema behind a lock. `require_vertex_credentials`
# still runs on every request as the fail-fast guard, but the heavy client build
# happens once.
_JUDGE_CACHE: dict[object, object] = {}
_JUDGE_CACHE_LOCK = threading.Lock()


def build_judge_for(schema):
    """Return a Vertex judge bound to an arbitrary structured-output schema."""
    require_vertex_credentials()
    with _JUDGE_CACHE_LOCK:
        client = _JUDGE_CACHE.get(schema)
        if client is None:
            client = ChatGoogleGenerativeAI(
                model=Config.JUDGE_MODEL,
                project=Config.PROJECT_NAME,       # project= is the switch → Vertex
                location=Config.PROJECT_LOCATION,
                temperature=Config.JUDGE_TEMPERATURE,
                max_retries=Config.JUDGE_MAX_RETRIES,
            ).with_structured_output(schema)
            _JUDGE_CACHE[schema] = client
        return client


def embed_texts(texts: list[str]) -> list[list[float]]:
    """Embed texts through Vertex (same ADC path as the judge).

    Raises RuntimeError when credentials/model are unavailable so callers can
    convert it to a MetricSkipped and keep offline runs green.
    """
    require_vertex_credentials()
    try:
        from langchain_google_genai import GoogleGenerativeAIEmbeddings

        embedder = GoogleGenerativeAIEmbeddings(
            model=Config.EMBEDDING_MODEL,
            project=Config.PROJECT_NAME,
            location=Config.PROJECT_LOCATION,
        )
        return embedder.embed_documents(texts)
    except Exception as exc:
        raise RuntimeError(f"embedding model unavailable: {exc}") from exc
