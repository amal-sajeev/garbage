"""CTNA Evaluation Service — FastAPI application.

Serves the REST API (used by both the human dashboard and the CI/CD gate) and
the static HTML dashboard.
"""

from __future__ import annotations

import asyncio
import contextlib
import csv
import io
import json
import subprocess
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

import httpx
from fastapi import FastAPI, HTTPException
from fastapi.responses import FileResponse, Response, StreamingResponse
from fastapi.staticfiles import StaticFiles

from config import Config
from models import (
    ABCompareRequest, AsyncEvaluateRequest, EvaluateRequest,
    HumanLabel, LabelRequest,
)
from adapters import capture_store
from labels import label_store
from structured_logging import get_logger
from registry import Registry
from repository import build_repository
from run_manager import DONE, LiveRun, run_manager
from runner import Runner
from scorers.vertex import require_vertex_credentials

_log = get_logger("eval_service.main")


def _load_static_text(filename: str) -> str:
    path = Config.STATIC_DIR / filename
    try:
        return path.read_text(encoding="utf-8")
    except PermissionError:
        repo_root = Path(__file__).resolve().parents[3]
        result = subprocess.run(
            ["git", "show", f"HEAD:dbaware-evaluation-service/src/main/static/{filename}"],
            cwd=str(repo_root),
            check=True,
            capture_output=True,
            text=True,
            encoding="utf-8",
        )
        return result.stdout


def _prefix_safe_dashboard_js(src: str) -> str:
    """Convert root-absolute dashboard URLs to relative URLs.

    This keeps the static UI working when the service is mounted behind an
    ingress path prefix (e.g. /eval/) instead of at domain root.
    """
    return (
        src
        .replace('fetch("/api/', 'fetch("api/')
        .replace('fetch(`/api/', 'fetch(`api/')
        .replace(
            'location.href = `/run_detail.html?run=${encodeURIComponent(tr.dataset.id)}`;',
            'location.href = `run_detail.html?run=${encodeURIComponent(tr.dataset.id)}`;',
        )
        .replace(
            'location.href = `/run.html?agent=${encodeURIComponent(agent)}&reps=${reps}`;',
            'location.href = `run.html?agent=${encodeURIComponent(agent)}&reps=${reps}`;',
        )
        .replace(
            'if (id) location.href = `/run_detail.html?run=${encodeURIComponent(id)}`;',
            'if (id) location.href = `run_detail.html?run=${encodeURIComponent(id)}`;',
        )
    )


_APP_JS = _prefix_safe_dashboard_js(_load_static_text("app.js"))

app = FastAPI(title="CTNA Evaluation Service", version="0.2.0")

_registry = Registry().load()
_repo = build_repository()
_runner = Runner(_registry, _repo)

try:
    for _lbl in _repo.list_labels():
        label_store.add(_lbl)
except Exception:
    _log.warning("failed_to_load_labels", extra={"error_type": "loading"})

# Run retention: delete old runs on startup.
if Config.RUN_RETENTION_DAYS > 0:
    try:
        deleted = _repo.delete_old_runs(Config.RUN_RETENTION_DAYS)
        if deleted:
            _log.info("run_retention_cleanup", extra={"deleted": deleted, "days": Config.RUN_RETENTION_DAYS})
    except Exception:
        _log.warning("run_retention_failed", extra={"error_type": "retention"})


@app.get("/api/health")
def health():
    """Config + ADC probe; reports the resolved credential class name."""
    result = {"status": "ok", "project_name": Config.PROJECT_NAME or None,
              "project_location": Config.PROJECT_LOCATION, "agents": len(_registry.list())}
    if not Config.PROJECT_NAME:
        result.update(status="degraded",
                      vertex="PROJECT_NAME unset — judge would fall back to the Developer API")
        return result
    try:
        result["credential_class"] = require_vertex_credentials()
        result["vertex"] = "ok"
    except Exception as exc:
        result.update(status="degraded", vertex=f"{type(exc).__name__}: {exc}")
    return result


@app.get("/api/agents")
def list_agents():
    return {"agents": _registry.list()}


@app.post("/api/evaluate")
async def evaluate(request: EvaluateRequest):
    try:
        run = await _runner.evaluate(
            request.agent_id, request.dataset_version, request.judge_repetitions
        )
    except KeyError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    except Exception as exc:
        raise HTTPException(status_code=502, detail=f"{type(exc).__name__}: {exc}") from exc
    return run.model_dump()


async def _drive_run(live: LiveRun, agent_id: str,
                     dataset_version: str | None, judge_repetitions: int) -> None:
    """Execute one evaluation, publishing progress to the LiveRun buffer.

    Runs as a background task tied to the app event loop (not to any browser
    connection), so a client disconnecting never cancels the run.
    """
    async def progress(event: dict) -> None:
        live.publish(event)

    try:
        await _runner.evaluate(agent_id, dataset_version, judge_repetitions, progress)
    except KeyError as exc:
        live.publish({"type": "error", "status": 404, "detail": str(exc),
                      "error_type": type(exc).__name__})
    except ValueError as exc:
        live.publish({"type": "error", "status": 400, "detail": str(exc),
                      "error_type": type(exc).__name__})
    except Exception as exc:
        import traceback
        live.publish({"type": "error", "status": 502,
                      "detail": f"{type(exc).__name__}: {exc}",
                      "error_type": type(exc).__name__,
                      "traceback": traceback.format_exc()})
    finally:
        live.finish()


@app.post("/api/evaluate/start")
async def evaluate_start(request: EvaluateRequest):
    """Start an evaluation as a background run and return a stream id.

    The run keeps going even if the browser tab is closed; reconnect to
    `/api/evaluate/stream/{stream_id}` to replay + tail its progress.
    """
    if request.agent_id not in {a["agent_id"] for a in _registry.list()}:
        raise HTTPException(status_code=404, detail=f"Unknown agent '{request.agent_id}'")
    reps = max(1, min(int(request.judge_repetitions), 5))
    live = run_manager.create(request.agent_id)
    live.task = asyncio.create_task(
        _drive_run(live, request.agent_id, request.dataset_version, reps)
    )
    return {"stream_id": live.stream_id, "agent_id": request.agent_id}


@app.get("/api/evaluate/stream/{stream_id}")
async def evaluate_stream(stream_id: str):
    """Attach to a running (or finished) evaluation and stream its progress as SSE.

    Replays the full buffered event history first, then tails live events. The
    underlying run is NOT tied to this connection: closing the tab leaves the run
    running and it still persists; reconnecting replays everything so far.
    """
    live = run_manager.get(stream_id)
    if live is None:
        raise HTTPException(status_code=404, detail=f"Run stream '{stream_id}' not found")

    async def event_source():
        queue = live.subscribe()
        try:
            while True:
                event = await queue.get()
                if event is DONE:
                    break
                yield f"data: {json.dumps(event, default=str)}\n\n"
        finally:
            live.unsubscribe(queue)

    return StreamingResponse(
        event_source(),
        media_type="text/event-stream",
        headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no",
                 "Connection": "keep-alive"},
    )


@app.get("/api/runs")
def list_runs(agent_id: str | None = None, limit: int = 50, before: str | None = None):
    """List run summaries, newest first.

    ``before`` is a cursor: pass the ``created_at`` of the last run in the page
    to get the next page. The response includes ``next_cursor`` for pagination.
    """
    runs = _repo.list_runs(agent_id, limit, before)
    next_cursor = runs[-1]["created_at"] if len(runs) == limit else None
    return {"runs": runs, "next_cursor": next_cursor}


@app.get("/api/runs/compare")
def compare_runs(a: str, b: str):
    """Compare two runs side-by-side: per-case scores, deltas, and pass/fail."""
    run_a = _repo.get_run(a)
    run_b = _repo.get_run(b)
    if not run_a:
        raise HTTPException(status_code=404, detail=f"Run '{a}' not found")
    if not run_b:
        raise HTTPException(status_code=404, detail=f"Run '{b}' not found")

    cases_a = {c.case_id: c for c in run_a.case_results}
    cases_b = {c.case_id: c for c in run_b.case_results}
    all_case_ids = sorted(set(cases_a) | set(cases_b))
    case_comparison = []
    for cid in all_case_ids:
        ca = cases_a.get(cid)
        cb = cases_b.get(cid)
        row = {"case_id": cid}
        if ca and cb:
            row["a"] = {"score": ca.weighted_score, "passed": ca.passed, "delta": ca.weighted_delta}
            row["b"] = {"score": cb.weighted_score, "passed": cb.passed, "delta": cb.weighted_delta}
            row["improved"] = cb.weighted_score > ca.weighted_score
        elif ca:
            row["a"] = {"score": ca.weighted_score, "passed": ca.passed}
            row["b"] = None
        else:
            row["a"] = None
            row["b"] = {"score": cb.weighted_score, "passed": cb.passed}
        case_comparison.append(row)
    return {
        "a": {"run_id": run_a.run_id, "agent_id": run_a.agent_id,
              "score": run_a.weighted_score, "delta": run_a.weighted_delta, "passed": run_a.passed},
        "b": {"run_id": run_b.run_id, "agent_id": run_b.agent_id,
              "score": run_b.weighted_score, "delta": run_b.weighted_delta, "passed": run_b.passed},
        "score_diff": run_b.weighted_score - run_a.weighted_score,
        "cases": case_comparison,
    }


@app.get("/api/runs/{run_id}")
def get_run(run_id: str):
    run = _repo.get_run(run_id)
    if not run:
        raise HTTPException(status_code=404, detail=f"Run '{run_id}' not found")
    return run.model_dump()


@app.get("/api/runs/{run_id}/export")
def export_run(run_id: str, format: str = "csv"):
    """Export a run's full detail as CSV or PDF."""
    run = _repo.get_run(run_id)
    if not run:
        raise HTTPException(status_code=404, detail=f"Run '{run_id}' not found")

    if format == "csv":
        buf = io.StringIO()
        writer = csv.writer(buf)
        writer.writerow(["case_id", "passed", "weighted_score", "weighted_delta",
                         "metric", "score", "threshold", "passed_metric", "critical",
                         "rationale"])
        for case in run.case_results:
            if not case.scores:
                writer.writerow([case.case_id, case.passed, case.weighted_score,
                                 case.weighted_delta, "", "", "", "", "", ""])
            for s in case.scores:
                writer.writerow([case.case_id, case.passed, case.weighted_score,
                                 case.weighted_delta, s.metric, s.score, s.threshold,
                                 s.passed, s.critical, s.rationale])
        return Response(
            content=buf.getvalue(),
            media_type="text/csv",
            headers={"Content-Disposition": f"attachment; filename=run_{run_id[:8]}.csv"},
        )

    if format == "pdf":
        lines = [
            f"Evaluation Run Export: {run.run_id[:8]}",
            f"Agent: {run.agent_id}  Dataset: {run.dataset_id} v{run.dataset_version}",
            f"Score: {run.weighted_score:.3f}  Delta: {run.weighted_delta:+.3f}  Passed: {run.passed}",
            f"Created: {run.created_at}",
            "",
        ]
        for case in run.case_results:
            lines.append(f"  {'PASS' if case.passed else 'FAIL'} {case.case_id} "
                         f"(score={case.weighted_score:.3f})")
            for s in case.scores:
                lines.append(f"    {'✓' if s.passed else '✗'} {s.metric}={s.score:.2f} "
                             f"(threshold={s.threshold}) {s.rationale[:80]}")
            lines.append("")
        pdf_bytes = _build_text_pdf(lines)
        return Response(
            content=pdf_bytes,
            media_type="application/pdf",
            headers={"Content-Disposition": f"attachment; filename=run_{run_id[:8]}.pdf"},
        )

    raise HTTPException(status_code=400, detail=f"Unsupported format '{format}'. Use csv or pdf.")


def _build_text_pdf(text_lines: list[str]) -> bytes:
    """Build a minimal valid PDF with text (stdlib only)."""
    content_parts = ["BT", "/F1 10 Tf", "72 750 Td"]
    for i, line in enumerate(text_lines):
        if i > 0:
            content_parts.append("0 -14 Td")
        escaped = line.replace("(", r"\(").replace(")", r"\)")[:200]
        content_parts.append(f"({escaped}) Tj")
    content_parts.append("ET")
    content = "\n".join(content_parts).encode("latin-1", errors="replace")
    objects = [
        b"<< /Type /Catalog /Pages 2 0 R >>",
        b"<< /Type /Pages /Kids [3 0 R] /Count 1 >>",
        b"<< /Type /Page /MediaBox [0 0 612 792] /Parent 2 0 R /Resources << /Font << /F1 4 0 R >> >> /Contents 5 0 R >>",
        b"<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>",
        f"<< /Length {len(content)} >>".encode("latin-1") + b"\nstream\n" + content + b"\nendstream",
    ]
    pdf = b"%PDF-1.4\n"
    offsets = []
    for i, obj in enumerate(objects, 1):
        offsets.append(len(pdf))
        pdf += f"{i} 0 obj\n".encode("latin-1") + obj + b"\nendobj\n"
    xref_offset = len(pdf)
    pdf += f"xref\n0 {len(objects) + 1}\n".encode("latin-1")
    pdf += b"0000000000 65535 f \n"
    for offset in offsets:
        pdf += f"{offset:010d} 00000 n \n".encode("latin-1")
    pdf += (f"trailer\n<< /Size {len(objects) + 1} /Root 1 0 R >>\n"
            f"startxref\n{xref_offset}\n%%EOF").encode("latin-1")
    return pdf


@app.post("/api/baselines/promote/{run_id}")
def promote_baselines(run_id: str):
    """Promote a run's per-metric mean scores as the new baseline.

    For each metric in the run, the mean score across all cases becomes the
    blessed baseline — used for delta tracking and drift detection on future runs.
    """
    run = _repo.get_run(run_id)
    if not run:
        raise HTTPException(status_code=404, detail=f"Run '{run_id}' not found")

    promoted: list[dict] = []
    # Collect per-metric scores across all cases.
    metric_scores: dict[str, list[float]] = {}
    for case in run.case_results:
        for s in case.scores:
            metric_scores.setdefault(s.metric, []).append(s.score)
    for metric, scores in metric_scores.items():
        mean = sum(scores) / len(scores)
        _repo.set_baseline(run.agent_id, run.dataset_version, metric, mean)
        promoted.append({"metric": metric, "baseline": round(mean, 4), "samples": len(scores)})
    _log.info("baselines_promoted", extra={
        "run_id": run_id, "agent_id": run.agent_id, "metrics": len(promoted)})
    return {
        "run_id": run_id,
        "agent_id": run.agent_id,
        "dataset_version": run.dataset_version,
        "promoted": promoted,
    }


@app.post("/api/evaluate/async")
async def evaluate_async(request: AsyncEvaluateRequest):
    """Start an evaluation in the background; return immediately.

    If ``webhook_url`` is provided, the service POSTs the completed run record
    to that URL when the run finishes. The client can also poll
    ``GET /api/runs/{run_id}`` or attach to the SSE stream.
    """
    if request.agent_id not in {a["agent_id"] for a in _registry.list()}:
        raise HTTPException(status_code=404, detail=f"Unknown agent '{request.agent_id}'")
    reps = max(1, min(int(request.judge_repetitions), 5))
    live = run_manager.create(request.agent_id)
    live.task = asyncio.create_task(
        _drive_run_with_webhook(
            live, request.agent_id, request.dataset_version, reps, request.webhook_url
        )
    )
    return {"stream_id": live.stream_id, "agent_id": request.agent_id, "webhook_url": request.webhook_url}


async def _drive_run_with_webhook(
    live: LiveRun, agent_id: str, dataset_version: str | None,
    judge_repetitions: int, webhook_url: str | None,
) -> None:
    """Run an evaluation, publish progress, and fire the webhook on completion."""
    async def progress(event: dict) -> None:
        live.publish(event)

    run = None
    try:
        run = await _runner.evaluate(agent_id, dataset_version, judge_repetitions, progress)
    except KeyError as exc:
        live.publish({"type": "error", "status": 404, "detail": str(exc),
                      "error_type": type(exc).__name__})
    except ValueError as exc:
        live.publish({"type": "error", "status": 400, "detail": str(exc),
                      "error_type": type(exc).__name__})
    except Exception as exc:
        import traceback
        live.publish({"type": "error", "status": 502,
                      "detail": f"{type(exc).__name__}: {exc}",
                      "error_type": type(exc).__name__,
                      "traceback": traceback.format_exc()})
    finally:
        live.finish()

    if run and webhook_url:
        try:
            async with httpx.AsyncClient(timeout=Config.WEBHOOK_TIMEOUT) as client:
                await client.post(webhook_url, json=run.model_dump())
            _log.info("webhook_delivered", extra={
                "run_id": run.run_id, "webhook_url": webhook_url})
        except Exception as exc:
            _log.warning("webhook_failed", extra={
                "run_id": run.run_id if run else None,
                "webhook_url": webhook_url, "error": str(exc)})


@app.post("/api/evaluate/ab")
async def evaluate_ab(request: ABCompareRequest):
    """Run two agents against the same dataset and return a comparison.

    Both agents must be registered. The comparison includes per-case score
    differences and an overall winner.
    """
    agent_ids = {a["agent_id"] for a in _registry.list()}
    for aid in (request.agent_a, request.agent_b):
        if aid not in agent_ids:
            raise HTTPException(status_code=404, detail=f"Unknown agent '{aid}'")

    reps = max(1, min(int(request.judge_repetitions), 5))
    run_a, run_b = await asyncio.gather(
        _runner.evaluate(request.agent_a, request.dataset_version, reps),
        _runner.evaluate(request.agent_b, request.dataset_version, reps),
    )

    cases_a = {c.case_id: c for c in run_a.case_results}
    cases_b = {c.case_id: c for c in run_b.case_results}
    all_case_ids = sorted(set(cases_a) | set(cases_b))
    case_comparison = []
    for cid in all_case_ids:
        ca = cases_a.get(cid)
        cb = cases_b.get(cid)
        row = {"case_id": cid}
        if ca and cb:
            row["a"] = {"score": ca.weighted_score, "passed": ca.passed}
            row["b"] = {"score": cb.weighted_score, "passed": cb.passed}
            row["winner"] = "b" if cb.weighted_score > ca.weighted_score else ("a" if ca.weighted_score > cb.weighted_score else "tie")
        elif ca:
            row["a"] = {"score": ca.weighted_score, "passed": ca.passed}
        else:
            row["b"] = {"score": cb.weighted_score, "passed": cb.passed}
        case_comparison.append(row)
    return {
        "a": {"run_id": run_a.run_id, "agent_id": run_a.agent_id,
              "score": run_a.weighted_score, "passed": run_a.passed},
        "b": {"run_id": run_b.run_id, "agent_id": run_b.agent_id,
              "score": run_b.weighted_score, "passed": run_b.passed},
        "winner": "b" if run_b.weighted_score > run_a.weighted_score else ("a" if run_a.weighted_score > run_b.weighted_score else "tie"),
        "score_diff": run_b.weighted_score - run_a.weighted_score,
        "cases": case_comparison,
    }


@app.get("/api/captures")
def list_captures():
    """Latest CTA_ACTION captured per case by the live capture service (in-memory)."""
    return {"source": Config.METRICS_SOURCE, "captures": capture_store.latest()}


@app.get("/api/captures/{case_id}")
def get_capture(case_id: str):
    action = capture_store.get(case_id)
    if not action:
        raise HTTPException(status_code=404, detail=f"No capture for case '{case_id}'")
    return action


@app.get("/api/labels")
def list_labels():
    """Expert pass/fail verdicts used to calibrate the gate/judge (in-memory)."""
    return {"labels": [lbl.model_dump() for lbl in label_store.all()]}


@app.get("/api/labels/{case_id}")
def get_label(case_id: str):
    label = label_store.get(case_id)
    if not label:
        raise HTTPException(status_code=404, detail=f"No label for case '{case_id}'")
    return label.model_dump()


@app.post("/api/labels")
def add_label(request: LabelRequest):
    """Record a human verdict; feeds precision/recall/F1/κ on the next run."""
    label = label_store.add(HumanLabel(**request.model_dump()))
    with contextlib.suppress(Exception):
        _repo.save_label(label)  # durable ground truth (SQLite/CloudSQL)
    return label.model_dump()


@app.get("/")
def index():
    return FileResponse(Config.STATIC_DIR / "index.html")


@app.get("/app.js", include_in_schema=False)
def app_js():
    return Response(
        content=_APP_JS.encode("utf-8"),
        media_type="application/javascript; charset=utf-8",
    )


app.mount("/", StaticFiles(directory=str(Config.STATIC_DIR)), name="static")
