#!/usr/bin/env python3
"""
Validation script for walkthrough_query_agent config.
Tests that all required fields are present and properly structured.
"""

import json
import sys
from pathlib import Path

def validate_config():
    """Validate the walkthrough_query_agent configuration files."""
    agent_dir = Path(__file__).parent.resolve()
    
    errors = []
    warnings = []
    dataset = {}
    agent_cfg = {}
    
    # 1. Check agent.yaml exists and has required fields
    agent_yaml = agent_dir / "agent.yaml"
    if not agent_yaml.exists():
        errors.append("agent.yaml not found")
    else:
        import yaml
        try:
            with open(agent_yaml) as f:
                agent_cfg = yaml.safe_load(f)
            required_fields = ["agent_id", "name", "base_url", "dataset_file"]
            for field in required_fields:
                if field not in agent_cfg:
                    errors.append(f"agent.yaml missing required field: {field}")
            if agent_cfg.get("agent_id") != "walkthrough_query_agent":
                errors.append(f"agent.yaml agent_id mismatch: {agent_cfg.get('agent_id')}")
        except Exception as e:
            errors.append(f"agent.yaml parse error: {e}")
    
    # 2. Check dataset.json exists and is valid JSON with required structure
    dataset_json = agent_dir / "dataset.json"
    if not dataset_json.exists():
        errors.append("dataset.json not found")
    else:
        try:
            with open(dataset_json) as f:
                dataset = json.load(f)
            
            # Check required top-level fields
            required_fields = ["dataset_id", "version", "target", "metrics", "cases"]
            for field in required_fields:
                if field not in dataset:
                    errors.append(f"dataset.json missing required field: {field}")
            
            # Validate target config
            if "target" in dataset:
                target = dataset["target"]
                if target.get("endpoint") != "/qna/chat":
                    errors.append(f"target.endpoint should be '/qna/chat', got: {target.get('endpoint')}")
                if target.get("adapter") not in ("http", "walkthrough_http"):
                    errors.append(f"target.adapter should be http or walkthrough_http, got: {target.get('adapter')}")
            
            # Validate metrics
            if "metrics" in dataset:
                metrics = dataset["metrics"]
                if not isinstance(metrics, list):
                    errors.append("metrics must be a list")
                elif len(metrics) == 0:
                    errors.append("metrics list is empty")
                else:
                    # Check each metric has required fields
                    for i, metric in enumerate(metrics):
                        required_metric_fields = ["name", "type", "scorer", "weight", "threshold"]
                        for field in required_metric_fields:
                            if field not in metric:
                                errors.append(f"metric[{i}] ({metric.get('name', 'unknown')}) missing field: {field}")
                    print(f"✓ {len(metrics)} metrics defined")
            
            # Validate cases
            if "cases" in dataset:
                cases = dataset["cases"]
                if not isinstance(cases, list):
                    errors.append("cases must be a list")
                elif len(cases) == 0:
                    errors.append("cases list is empty")
                else:
                    # Check each case has required fields
                    for i, case in enumerate(cases):
                        required_case_fields = ["id", "input", "golden_output", "baseline_metrics"]
                        for field in required_case_fields:
                            if field not in case:
                                errors.append(f"case[{i}] ({case.get('id', 'unknown')}) missing field: {field}")
                    print(f"✓ {len(cases)} golden test cases defined")
        
        except json.JSONDecodeError as e:
            errors.append(f"dataset.json JSON parse error: {e}")
        except Exception as e:
            errors.append(f"dataset.json validation error: {e}")
    
    # 3. Check metrics_stub.json exists and is valid JSON
    metrics_stub = agent_dir / "metrics_stub.json"
    if metrics_stub.exists():
        try:
            with open(metrics_stub) as f:
                stub = json.load(f)
            if "cases" in stub:
                print(f"✓ metrics_stub.json has {len(stub['cases'])} case stubs")
        except json.JSONDecodeError as e:
            errors.append(f"metrics_stub.json JSON parse error: {e}")
    else:
        warnings.append("metrics_stub.json not found (optional)")
    
    # Print results
    print("\n" + "="*60)
    print("Configuration Validation Results")
    print("="*60)
    
    if errors:
        print(f"\n❌ ERRORS ({len(errors)}):")
        for error in errors:
            print(f"  - {error}")
        return False
    else:
        print("\n✅ All validations passed!")
    
    if warnings:
        print(f"\n⚠️  WARNINGS ({len(warnings)}):")
        for warning in warnings:
            print(f"  - {warning}")
    
    print("\nConfiguration Summary:")
    print(f"  Agent ID: {agent_cfg.get('agent_id', 'walkthrough_query_agent')}")
    print(f"  Endpoint: {dataset.get('target', {}).get('endpoint', '/qna/chat')} (POST)")
    print(f"  Adapter: {dataset.get('target', {}).get('adapter')}")
    print(f"  Golden Cases: {len(dataset.get('cases', []))}")
    print(f"  Metrics: {len(dataset.get('metrics', []))}")
    
    return True

if __name__ == "__main__":
    success = validate_config()
    sys.exit(0 if success else 1)
