"""Walkthrough Q&A adapter: seed the hosted agent with the eval document.

The production `/qna/chat` API loads context from GCS (or an in-memory session
warmed by another UI panel). Eval cases therefore:

1. Upload ``source_document.json`` once via ``POST /qna/upload``.
2. Send every chat request with that ``contextGcsUri`` *and* the document as
   ``researchSections`` (newer agents seed the session inline; older ones
   autoload from the URI).
3. Attach the document as ``observation.source_context`` so groundedness
   judges the answer against the same walkthrough, not an empty context.
"""

from __future__ import annotations

import json
from pathlib import Path

import httpx

from adapters.http_adapter import HttpAdapter, register_adapter
from models import GoldenCase, Observation

_DOC_PATH = Path(__file__).resolve().parent / "source_document.json"
_UPLOAD_BLOB = "eval/walkthrough_query_agent/source_document.json"


def _load_source_document() -> dict:
    return json.loads(_DOC_PATH.read_text(encoding="utf-8"))


@register_adapter("walkthrough_http")
class WalkthroughHttpAdapter(HttpAdapter):
    """HTTP adapter that publishes the walkthrough document before chatting."""

    adapter_id = "walkthrough_http"

    def __init__(self, base_url, endpoint, target=None):
        super().__init__(base_url, endpoint, target)
        self._doc = _load_source_document()
        self._gcs_uri: str | None = None

    async def _ensure_document_uri(self) -> str | None:
        if self._gcs_uri:
            return self._gcs_uri
        timeout = (self._target.timeout if self._target else None) or 180.0
        trust_env = self._target.trust_env if self._target else False
        url = f"{self._base_url}/qna/upload"
        files = {
            "file": (
                "source_document.json",
                json.dumps(self._doc, ensure_ascii=False).encode("utf-8"),
                "application/json",
            )
        }
        data = {"dest_blob_path": _UPLOAD_BLOB}
        async with httpx.AsyncClient(timeout=timeout, trust_env=trust_env) as client:
            resp = await client.post(url, files=files, data=data)
            resp.raise_for_status()
            body = resp.json() if resp.content else {}
        self._gcs_uri = body.get("gcs_uri") or body.get("gcs_blob_path") or _UPLOAD_BLOB
        return self._gcs_uri

    def _chat_input(self, case: GoldenCase, gcs_uri: str | None) -> dict:
        inp = dict(case.input or {})
        inp["researchSections"] = inp.get("researchSections") or self._doc
        if gcs_uri:
            inp["contextGcsUri"] = gcs_uri
        else:
            inp.pop("contextGcsUri", None)
        return inp

    async def run_case(self, case: GoldenCase) -> Observation:
        gcs_uri = None
        upload_error = None
        try:
            gcs_uri = await self._ensure_document_uri()
        except Exception as exc:
            upload_error = f"{type(exc).__name__}: {exc}"

        patched = case.model_copy(deep=True)
        patched.input = self._chat_input(case, gcs_uri)
        observation = await super().run_case(patched)
        if not observation.source_context:
            observation.source_context = self._doc
        if observation.error and upload_error:
            observation.error = (
                f"{observation.error} (document upload also failed: {upload_error})"
            )
        return observation
