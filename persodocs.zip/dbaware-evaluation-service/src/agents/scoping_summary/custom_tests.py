"""Agent-specific (custom) scorers for the scoping_summary agent.

Auto-imported by the registry at startup; each @scorer self-registers under a
name that dataset.json references. These encode the structural, traceability and
grounding contract that the Scoping Analytics agent must satisfy — things the
generic judges/reference scorers can't check deterministically.

The agent returns an `analysis_report` bundle of three reports, each a
`ScopingReport = {report_title, paragraphs:[{paragraph_id, content,
supporting_chunk_ids[], rationale, metadata:{is_section_start,
section_confidence_score}}]}`. Over HTTP (FastAPI) each report is a JSON dict;
the persisted GCS copy stringifies the pydantic repr. The helpers below normalise
BOTH shapes so the same scorers work live and against stored samples.
"""

from __future__ import annotations

import json
import re
from typing import Any

from scorers.base import scorer

# The three reports the bundle must contain, each keyed by its exact title.
_REQUIRED_REPORTS = (
    "Past Review Analysis",
    "Policy and Regulatory Analysis",
    "Broad Scope Direction",
)

# A bare section heading paragraph (e.g. "Section 3: ...") legitimately carries
# no citations; used to avoid penalising headings in citation_grounding.
_HEADING_RE = re.compile(r"^\s*(section\s+\d+|broad scope direction)\b", re.I)


# --------------------------------------------------------------------------- #
# Normalisation: turn either a dict report or its repr-string into paragraphs.
# --------------------------------------------------------------------------- #

def _reports_bundle(observation) -> dict[str, Any]:
    """Return {report_name: report_value} from observation.output.

    output may be the analysis_report dict, or a JSON string of it. report_value
    is either a dict {report_title, paragraphs} or a repr string.
    """
    out = observation.output
    if isinstance(out, str):
        try:
            out = json.loads(out)
        except Exception:
            return {}
    if isinstance(out, dict):
        # Either already the bundle, or wrapped as {analysis_report: {...}}.
        if "analysis_report" in out and isinstance(out["analysis_report"], dict):
            return out["analysis_report"]
        return out
    return {}


def _title_of(report_value: Any) -> str:
    if isinstance(report_value, dict):
        return str(report_value.get("report_title", ""))
    if isinstance(report_value, str):
        m = re.search(r"report_title=['\"](.*?)['\"]", report_value)
        return m.group(1) if m else ""
    return ""


def _paragraphs_of(report_value: Any) -> list[dict]:
    """Normalise a report into a list of paragraph dicts with keys:
    content:str, chunk_ids:list[int], rationale:str, is_section_start:bool,
    confidence:int|None.
    """
    paras: list[dict] = []

    if isinstance(report_value, dict):
        for p in report_value.get("paragraphs", []) or []:
            if not isinstance(p, dict):
                continue
            meta = p.get("metadata") or {}
            paras.append({
                "content": str(p.get("content", "")),
                "chunk_ids": _coerce_ids(p.get("supporting_chunk_ids", [])),
                "rationale": str(p.get("rationale", "") or ""),
                "is_section_start": bool(meta.get("is_section_start", False)),
                "confidence": meta.get("section_confidence_score", None),
            })
        return paras

    if isinstance(report_value, str):
        return _parse_repr_paragraphs(report_value)

    return paras


def _coerce_ids(ids: Any) -> list[int]:
    out: list[int] = []
    if isinstance(ids, (list, tuple)):
        for v in ids:
            try:
                out.append(int(str(v).strip().strip("'\"")))
            except (TypeError, ValueError):
                continue
    return out


def _parse_repr_paragraphs(text: str) -> list[dict]:
    """Best-effort parse of the persisted `ParagraphCitation(...)` repr string.

    Segments on each `paragraph_id=` and regex-extracts the fields. Robust enough
    for validation against stored GCS samples; the live path uses dicts.
    """
    paras: list[dict] = []
    starts = [m.start() for m in re.finditer(r"paragraph_id=", text)]
    for i, s in enumerate(starts):
        seg = text[s: starts[i + 1] if i + 1 < len(starts) else len(text)]
        content_m = re.search(r"content=(['\"])(.*?)\1,\s*supporting_chunk_ids", seg, re.S)
        ids_m = re.search(r"supporting_chunk_ids=\[([^\]]*)\]", seg)
        rat_m = re.search(r"rationale=(['\"])(.*?)\1,\s*metadata", seg, re.S)
        start_m = re.search(r"is_section_start=(True|False)", seg)
        conf_m = re.search(r"section_confidence_score=(\d+|None)", seg)
        ids = []
        if ids_m:
            ids = [int(x) for x in re.findall(r"\d+", ids_m.group(1))]
        conf: Any = None
        if conf_m and conf_m.group(1) != "None":
            conf = int(conf_m.group(1))
        paras.append({
            "content": content_m.group(2) if content_m else "",
            "chunk_ids": ids,
            "rationale": rat_m.group(2) if rat_m else "",
            "is_section_start": bool(start_m and start_m.group(1) == "True"),
            "confidence": conf,
        })
    return paras


def _all_paragraphs(observation) -> list[dict]:
    bundle = _reports_bundle(observation)
    paras: list[dict] = []
    for value in bundle.values():
        paras.extend(_paragraphs_of(value))
    return paras


def _bundle_text(observation) -> str:
    """Flat lowercase text of all report content, for substring assertions."""
    return " ".join(p["content"] for p in _all_paragraphs(observation)).lower()


def _is_heading_only(p: dict) -> bool:
    c = (p["content"] or "").strip()
    return bool(_HEADING_RE.match(c)) and len(c) <= 80


# --------------------------------------------------------------------------- #
# Scorers
# --------------------------------------------------------------------------- #

@scorer("scoping_reports_present")
def scoping_reports_present(*, observation, case, **_):
    """All three required reports must be present in the bundle."""
    required = (case.expected or {}).get("required_reports", list(_REQUIRED_REPORTS))
    bundle = _reports_bundle(observation)
    present = [r for r in required if r in bundle and _paragraphs_of(bundle[r])]
    evidence = [f"{'✓' if r in bundle else '✗'} {r}" for r in required]
    score = len(present) / len(required) if required else 1.0
    return score, f"{len(present)}/{len(required)} required reports present", evidence


@scorer("scoping_titles_exact")
def scoping_titles_exact(*, observation, case, **_):
    """Each report's report_title must equal its required title verbatim."""
    required = (case.expected or {}).get("required_reports", list(_REQUIRED_REPORTS))
    bundle = _reports_bundle(observation)
    ok, evidence = 0, []
    for name in required:
        title = _title_of(bundle.get(name)) if name in bundle else ""
        good = title == name
        ok += 1 if good else 0
        evidence.append(f"{'✓' if good else '✗'} {name!r} -> {title!r}")
    score = ok / len(required) if required else 1.0
    return score, f"{ok}/{len(required)} titles exact", evidence


@scorer("scoping_sections_present")
def scoping_sections_present(*, observation, case, **_):
    """Every required section heading must appear in its report's content.

    case.expected.required_sections = {report_name: [heading substrings...]}.
    """
    required = (case.expected or {}).get("required_sections", {})
    if not required:
        return 1.0, "no required_sections configured", []
    bundle = _reports_bundle(observation)
    total, found, evidence = 0, 0, []
    for report_name, headings in required.items():
        text = " ".join(
            p["content"] for p in _paragraphs_of(bundle.get(report_name))
        ).lower()
        for h in headings:
            total += 1
            hit = h.lower() in text
            found += 1 if hit else 0
            if not hit:
                evidence.append(f"✗ {report_name}: missing '{h}'")
    score = found / total if total else 1.0
    rationale = f"{found}/{total} required sections present"
    return score, rationale, evidence or [rationale]


@scorer("citation_grounding")
def citation_grounding(*, observation, case, **_):
    """Traceability: substantive paragraphs cite valid source chunk_ids.

    - Every cited id must be within 1..max_chunk_id (no hallucinated citations).
    - Every substantive (non-heading) paragraph must cite at least one chunk.
    Score = 1 - violations / paragraphs.
    case.expected.max_chunk_id bounds the valid citation universe.
    """
    max_id = int((case.expected or {}).get("max_chunk_id", 0))
    paras = _all_paragraphs(observation)
    if not paras:
        return 0.0, "no paragraphs found in output", []
    violations, evidence = 0, []
    for p in paras:
        ids = p["chunk_ids"]
        bad = [i for i in ids if i < 1 or (max_id and i > max_id)]
        if bad:
            violations += 1
            evidence.append(f"✗ out-of-range chunk_ids {bad} (max {max_id})")
            continue
        if not ids and not _is_heading_only(p):
            violations += 1
            snippet = (p["content"][:50] + "…") if p["content"] else "(empty)"
            evidence.append(f"✗ uncited claim: {snippet}")
    score = max(0.0, 1.0 - violations / len(paras))
    rationale = f"{len(paras) - violations}/{len(paras)} paragraphs properly grounded"
    return score, rationale, evidence or [rationale]


@scorer("rationale_coverage")
def rationale_coverage(*, observation, case, **_):
    """Every paragraph must carry a non-empty generation rationale."""
    paras = _all_paragraphs(observation)
    if not paras:
        return 0.0, "no paragraphs found in output", []
    with_rat = sum(1 for p in paras if p["rationale"].strip())
    score = with_rat / len(paras)
    return score, f"{with_rat}/{len(paras)} paragraphs have a rationale", []


@scorer("confidence_score_valid")
def confidence_score_valid(*, observation, case, **_):
    """Section-start paragraphs must carry a 0..100 confidence; others must not.

    Enforces the output-format contract: section_confidence_score is required
    exactly when is_section_start is true, and omitted/null otherwise.
    """
    paras = _all_paragraphs(observation)
    if not paras:
        return 0.0, "no paragraphs found in output", []
    ok, evidence = 0, []
    for p in paras:
        conf = p["confidence"]
        if p["is_section_start"]:
            good = isinstance(conf, (int, float)) and 0 <= conf <= 100
            if not good:
                evidence.append(f"✗ section-start missing valid confidence: {conf}")
        else:
            good = conf is None
            if not good:
                evidence.append(f"✗ non-section paragraph has confidence {conf}")
        ok += 1 if good else 0
    score = ok / len(paras)
    return score, f"{ok}/{len(paras)} paragraphs obey the confidence rule", evidence


@scorer("scope_entities_present")
def scope_entities_present(*, observation, case, **_):
    """Key plan identifiers/entities must appear verbatim in the report text.

    case.expected.expected_values = ["20588", "R137", "IRC-CD-1000141", …].
    All-or-nothing per identifier; score = fraction present.
    """
    expected_values = (case.expected or {}).get("expected_values", [])
    if not expected_values:
        return 1.0, "no expected_values to check", []
    text = _bundle_text(observation)
    present = [v for v in expected_values if str(v).lower() in text]
    missing = [v for v in expected_values if v not in present]
    evidence = [f"{'✓' if v in present else '✗ missing'} {v}" for v in expected_values]
    score = len(present) / len(expected_values)
    rationale = "all key entities present" if not missing else f"missing: {missing}"
    return score, rationale, evidence
