# Starts the CTNA Evaluation Service on EVAL_SERVICE_PORT (default 4002).
# Run from the module root (dbaware-evaluation-service). The .venv may live in
# this module or one level up at the scope-eval repo root.
$ErrorActionPreference = "Stop"
$root = Split-Path -Parent $PSScriptRoot
$repoRoot = Split-Path -Parent $root
$py = Join-Path $root ".venv\Scripts\python.exe"
if (-not (Test-Path $py)) { $py = Join-Path $repoRoot ".venv\Scripts\python.exe" }
if (-not (Test-Path $py)) { $py = "python" }

# Local WIF convenience defaults (can be overridden by caller/.env values).
$defaultWifCreds = "C:\Users\sanjama\dev\wif\dbgarda\wif-file-based.json"
$defaultWifCa = "C:\Users\sanjama\dev\wif\cacert.crt"

if (-not $env:GOOGLE_APPLICATION_CREDENTIALS -and (Test-Path $defaultWifCreds)) {
	$env:GOOGLE_APPLICATION_CREDENTIALS = $defaultWifCreds
}
if (-not $env:SSL_CERT_FILE -and (Test-Path $defaultWifCa)) {
	$env:SSL_CERT_FILE = $defaultWifCa
}
if (-not $env:REQUESTS_CA_BUNDLE -and (Test-Path $defaultWifCa)) {
	$env:REQUESTS_CA_BUNDLE = $defaultWifCa
}

if (-not $env:HTTPS_PROXY) { $env:HTTPS_PROXY = "http://sdod3-proxy.intranet.db.com:8080" }
if (-not $env:HTTP_PROXY) { $env:HTTP_PROXY = $env:HTTPS_PROXY }
if (-not $env:NO_PROXY) { $env:NO_PROXY = "*.db.com,localhost,127.0.0.1,10.*" }
if (-not $env:no_proxy) { $env:no_proxy = $env:NO_PROXY }

# Default the offline target + metrics source so a fresh shell targets the local
# sample agent (scripts/run_sample_agent.ps1 on :4010) instead of the unrunning
# real agent-service on :4000. Override either to point at a hosted deployment.
if (-not $env:AGENT_SERVICE_BASE_URL) { $env:AGENT_SERVICE_BASE_URL = "http://127.0.0.1:4010" }
if (-not $env:METRICS_SOURCE) { $env:METRICS_SOURCE = "capture" }

$env:PYTHONPATH = Join-Path $root "src\main"
& $py (Join-Path $root "src\main\app.py")
