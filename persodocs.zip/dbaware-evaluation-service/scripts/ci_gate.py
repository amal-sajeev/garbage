#!/usr/bin/env python3
"""
Evaluation gate for CI/CD pipelines.

Starts an agent evaluation run against the golden set, waits for completion,
and returns 0 (pass) or 1 (fail) based on quality gates.

Usage:
    python ci_gate.py <agent_id> [--eval-url URL] [--timeout SECONDS] [--score MIN] [--delta MAX]

Environment Variables:
    EVAL_SERVICE_URL        Base URL of eval service (default: http://localhost:4002)
    AGENT_ID                Agent to evaluate (overrides positional arg)
    EVAL_TIMEOUT_SECONDS    Polling timeout (default: 1500s = 25min)
    EVAL_MIN_SCORE          Minimum weighted_score threshold (default: 0.0, ignored)
    EVAL_MAX_DELTA_REGRESS  Maximum allowed delta regression (default: -0.1)
    EVAL_MIN_PASS_RATE      Minimum pass_rate (default: 0.0, ignored)
    EVAL_JUDGE_REPS         Judge repetitions 1-5 (default: 1)

Example:
    python ci_gate.py scope_extraction --timeout 1200 --score 0.85 --delta -0.05
    
    # With environment config:
    export EVAL_SERVICE_URL=https://eval-service.example.com
    export EVAL_MIN_SCORE=0.85
    python ci_gate.py my_agent
"""

import sys
import time
import json
import argparse
import os
from typing import Optional

try:
    import requests
except ImportError:
    print("ERROR: 'requests' module not found. Install with: pip install requests")
    sys.exit(2)


class EvalGate:
    """Manages evaluation runs and gate checks."""
    
    def __init__(
        self,
        eval_url: str = "http://localhost:4002",
        timeout: int = 1500,
        poll_interval: int = 5,
        min_score: float = 0.0,
        max_delta_regress: float = -0.1,
        min_pass_rate: float = 0.0,
        judge_reps: int = 1,
        verbose: bool = False,
    ):
        self.eval_url = eval_url.rstrip("/")
        self.timeout = timeout
        self.poll_interval = poll_interval
        self.min_score = min_score
        self.max_delta_regress = max_delta_regress
        self.min_pass_rate = min_pass_rate
        self.judge_reps = judge_reps
        self.verbose = verbose
    
    def log(self, msg: str, level: str = "INFO"):
        """Print log message."""
        if self.verbose or level in ("ERROR", "WARN"):
            print(f"[{level}] {msg}")
    
    def check_health(self) -> bool:
        """Verify eval service is reachable."""
        try:
            resp = requests.get(f"{self.eval_url}/api/health", timeout=5)
            resp.raise_for_status()
            self.log(f"✅ Eval service healthy: {self.eval_url}")
            return True
        except Exception as e:
            self.log(f"❌ Eval service unreachable: {e}", "ERROR")
            return False
    
    def start_evaluation(self, agent_id: str) -> Optional[str]:
        """Start evaluation and return run_id."""
        try:
            self.log(f"Starting evaluation for agent '{agent_id}'...")
            resp = requests.post(
                f"{self.eval_url}/api/evaluate/start",
                json={
                    "agent_id": agent_id,
                    "judge_repetitions": self.judge_reps,
                },
                timeout=10,
            )
            resp.raise_for_status()
            data = resp.json()
            run_id = data.get("stream_id")
            self.log(f"✅ Evaluation started: run_id={run_id}")
            return run_id
        except Exception as e:
            self.log(f"❌ Failed to start evaluation: {e}", "ERROR")
            return None
    
    def wait_for_completion(self, run_id: str) -> Optional[dict]:
        """Poll until evaluation completes."""
        start_time = time.time()
        poll_count = 0
        
        while time.time() - start_time < self.timeout:
            try:
                resp = requests.get(f"{self.eval_url}/api/runs/{run_id}", timeout=10)
                resp.raise_for_status()
                result = resp.json()
                
                # Check if complete (has case_results and passed status)
                if "case_results" in result and result.get("passed") is not None:
                    elapsed = int(time.time() - start_time)
                    self.log(f"✅ Evaluation completed in {elapsed}s")
                    return result
                
                poll_count += 1
                elapsed = int(time.time() - start_time)
                self.log(f"Poll #{poll_count} [{elapsed}s]: Evaluation in progress...")
                time.sleep(self.poll_interval)
            
            except requests.exceptions.RequestException as e:
                self.log(f"⚠️  Poll error (retrying): {e}")
                time.sleep(self.poll_interval)
        
        self.log(f"❌ Evaluation timeout after {self.timeout}s", "ERROR")
        return None
    
    def check_gates(self, result: dict) -> bool:
        """Determine if result passes all gates."""
        self.log("\n=== Checking Gates ===")
        all_pass = True
        
        # Gate 1: Primary gate (must pass)
        passed = result.get("passed")
        if passed:
            self.log("✅ Primary gate: passed=true")
        else:
            self.log(f"❌ PRIMARY GATE FAILED: passed={passed}", "ERROR")
            all_pass = False
        
        # Gate 2: Score threshold (optional)
        score = result.get("weighted_score", 0)
        if self.min_score > 0:
            if score >= self.min_score:
                self.log(f"✅ Score gate: {score:.3f} >= {self.min_score:.3f}")
            else:
                self.log(f"❌ SCORE GATE FAILED: {score:.3f} < {self.min_score:.3f}", "ERROR")
                all_pass = False
        else:
            self.log(f"ℹ️  Score: {score:.3f} (no threshold)")
        
        # Gate 3: Regression gate (optional)
        delta = result.get("weighted_delta", 0)
        if delta < self.max_delta_regress:
            self.log(
                f"❌ REGRESSION GATE FAILED: delta={delta:.3f} < {self.max_delta_regress:.3f}",
                "ERROR"
            )
            all_pass = False
        elif delta < 0:
            self.log(f"⚠️  Minor regression: delta={delta:.3f}", "WARN")
        else:
            self.log(f"✅ Improvement: delta={delta:+.3f}")
        
        # Gate 4: Pass rate (optional)
        stats = result.get("stats", {})
        pass_rate = stats.get("pass_rate", 1)
        if self.min_pass_rate > 0:
            if pass_rate >= self.min_pass_rate:
                self.log(f"✅ Pass rate: {pass_rate:.1%} >= {self.min_pass_rate:.1%}")
            else:
                self.log(
                    f"❌ PASS RATE GATE FAILED: {pass_rate:.1%} < {self.min_pass_rate:.1%}",
                    "ERROR"
                )
                all_pass = False
        else:
            self.log(f"ℹ️  Pass rate: {pass_rate:.1%}")
        
        # Summary
        self.log("")
        if all_pass:
            self.log("✅ ✅ ✅ ALL GATES PASSED ✅ ✅ ✅")
            return True
        else:
            self.log("❌ ❌ ❌ GATES FAILED ❌ ❌ ❌", "ERROR")
            return False
    
    def export_results(self, result: dict, output_file: Optional[str] = None) -> bool:
        """Save results to JSON file."""
        try:
            summary = {
                "run_id": result.get("run_id"),
                "agent_id": result.get("agent_id"),
                "dataset_id": result.get("dataset_id"),
                "dataset_version": result.get("dataset_version"),
                "created_at": result.get("created_at"),
                "passed": result.get("passed"),
                "weighted_score": result.get("weighted_score"),
                "weighted_delta": result.get("weighted_delta"),
                "stats": result.get("stats"),
            }
            
            if output_file:
                with open(output_file, "w") as f:
                    json.dump(summary, f, indent=2)
                self.log(f"✅ Results exported to {output_file}")
                return True
            else:
                print("\n=== Evaluation Results ===")
                print(json.dumps(summary, indent=2))
                return True
        except Exception as e:
            self.log(f"⚠️  Failed to export results: {e}", "WARN")
            return False
    
    def run(self, agent_id: str, output_file: Optional[str] = None) -> int:
        """Execute full evaluation gate."""
        print(f"\n{'='*60}")
        print(f"Evaluation Gate for Agent: {agent_id}")
        print(f"Eval Service URL: {self.eval_url}")
        print(f"{'='*60}\n")
        
        # Step 1: Health check
        if not self.check_health():
            return 2
        
        # Step 2: Start evaluation
        run_id = self.start_evaluation(agent_id)
        if not run_id:
            return 2
        
        # Step 3: Wait for completion
        result = self.wait_for_completion(run_id)
        if not result:
            return 2
        
        # Step 4: Check gates
        gates_passed = self.check_gates(result)
        
        # Step 5: Export results
        self.export_results(result, output_file)
        
        # Return status
        return 0 if gates_passed else 1


def main():
    """Parse arguments and run gate."""
    parser = argparse.ArgumentParser(
        description=__doc__,
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    
    parser.add_argument(
        "agent_id",
        nargs="?",
        help="Agent ID to evaluate (or set AGENT_ID env var)",
    )
    parser.add_argument(
        "--eval-url",
        default=os.getenv("EVAL_SERVICE_URL", "http://localhost:4002"),
        help="Base URL of eval service (default: http://localhost:4002)",
    )
    parser.add_argument(
        "--timeout",
        type=int,
        default=int(os.getenv("EVAL_TIMEOUT_SECONDS", "1500")),
        help="Polling timeout in seconds (default: 1500)",
    )
    parser.add_argument(
        "--poll-interval",
        type=int,
        default=5,
        help="Polling interval in seconds (default: 5)",
    )
    parser.add_argument(
        "--score",
        type=float,
        default=float(os.getenv("EVAL_MIN_SCORE", "0")),
        help="Minimum weighted_score threshold (default: 0, no check)",
    )
    parser.add_argument(
        "--delta",
        type=float,
        default=float(os.getenv("EVAL_MAX_DELTA_REGRESS", "-0.1")),
        help="Maximum allowed delta regression (default: -0.1)",
    )
    parser.add_argument(
        "--pass-rate",
        type=float,
        default=float(os.getenv("EVAL_MIN_PASS_RATE", "0")),
        help="Minimum pass_rate threshold (default: 0, no check)",
    )
    parser.add_argument(
        "--judge-reps",
        type=int,
        default=int(os.getenv("EVAL_JUDGE_REPS", "1")),
        help="Judge repetitions 1-5 (default: 1)",
    )
    parser.add_argument(
        "--output",
        help="Export results to JSON file",
    )
    parser.add_argument(
        "-v", "--verbose",
        action="store_true",
        help="Verbose logging",
    )
    
    args = parser.parse_args()
    
    # Get agent_id from arg or env
    agent_id = args.agent_id or os.getenv("AGENT_ID")
    if not agent_id:
        parser.print_help()
        print("\nERROR: agent_id required (positional arg or AGENT_ID env var)")
        return 2
    
    # Clamp judge_reps to valid range
    judge_reps = max(1, min(5, args.judge_reps))
    
    # Run gate
    gate = EvalGate(
        eval_url=args.eval_url,
        timeout=args.timeout,
        poll_interval=args.poll_interval,
        min_score=args.score,
        max_delta_regress=args.delta,
        min_pass_rate=args.pass_rate,
        judge_reps=judge_reps,
        verbose=args.verbose,
    )
    
    return gate.run(agent_id, args.output)


if __name__ == "__main__":
    sys.exit(main())
