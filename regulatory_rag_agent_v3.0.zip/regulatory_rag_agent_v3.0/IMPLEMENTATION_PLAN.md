# Regulatory RAG Agent v3 implementation

## Objective

Upgrade the v2.1 regulatory acquisition workflow into a genuinely agentic controller while preserving the strict legal-content safety boundary and the corporate no-search-SaaS requirement.

## Implemented

### 1. Explicit objective
Added `--goal` and carried the acquisition objective through controller state and manifests.

### 2. Agent action model
Added a structured `AgentDecision` with a closed action vocabulary: discover, fetch, extract, validate, retry, expand, reconsider, and finish.

### 3. Dynamic LangGraph loop
Replaced the fixed stage sequence with `agent_decide -> execute_action -> agent_decide`, bounded by `MAX_AGENT_STEPS` and a deterministic completion gate.

### 4. Evidence-driven action selection
The decision prompt includes frontier, candidates, fetched-source metadata, extracted documents, validation outcomes, errors, action history, current strategy, memory, and completion evidence.

### 5. Deterministic action authorization
Every action target is checked against known state. Expansion is limited to fetched HTML. Extraction requires a fetched source. Validation requires an extracted source. Arbitrary URLs cannot be supplied by the model.

### 6. Failure memory
Added persistent `agent_memory.json` with bounded failure records and successful/failed strategy summaries.

### 7. Persistent checkpoints
Added per-action checkpoints containing the controller state and fetched bytes. Added `load_checkpoint()` and CLI `--resume`.

### 8. Strategy reconsideration
Added an explicit action for strategy changes so recovery is represented in state and history rather than being hidden in exception handling.

### 9. Deterministic completion
Added `CompletionAssessment`. The controller cannot stop simply because the model emits `finish`; persistence records the evidence and blockers.

### 10. Existing v2.1 safeguards retained
Allowlisting, redirect validation, robots enforcement, bounded retrieval, browser/OCR fallbacks, authority gating, source-preserving Markdown, fidelity checks, review queue, version registry, snapshots, structured logging, local storage, and GCS storage remain part of the system.

## Deliberate exclusions

- No Tavily or other generic search SaaS.
- No LLM-generated legal text.
- No arbitrary model-selected URL fetching.
- No unbounded autonomous loop.

## Next production work

The next high-value additions are regulator-specific parsing policies, legal golden-set evaluation, human approval tooling for review candidates, and external scheduling/orchestration. These are integration/evaluation layers rather than placeholders in the v3 controller.
