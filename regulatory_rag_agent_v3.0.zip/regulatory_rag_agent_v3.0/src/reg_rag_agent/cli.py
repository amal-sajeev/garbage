from __future__ import annotations

import argparse
import json
import os

from .graph import build_graph, load_checkpoint
from .observability import configure_logging


def main():
    p = argparse.ArgumentParser(description="Agentic regulatory RAG acquisition agent")
    sub = p.add_subparsers(dest="command", required=True)
    ingest = sub.add_parser("ingest", help="Run bounded autonomous discovery, acquisition, validation and persistence")
    ingest.add_argument("--url", action="append", required=True)
    ingest.add_argument("--goal", default=None, help="Acquisition objective")
    ingest.add_argument("--output-dir", default=None)
    ingest.add_argument("--allowlist", default=None)
    ingest.add_argument("--browser", action="store_true")
    ingest.add_argument("--ocr", action="store_true")
    ingest.add_argument("--resume", default=None, help="Resume a persisted checkpoint by run ID")
    args = p.parse_args(); configure_logging()
    if args.command == "ingest":
        if args.output_dir: os.environ["OUTPUT_DIR"] = args.output_dir
        if args.allowlist: os.environ["SOURCE_ALLOWLIST"] = args.allowlist
        if args.browser: os.environ["ENABLE_BROWSER_RENDERING"] = "true"
        if args.ocr: os.environ["ENABLE_OCR"] = "true"
        if args.resume:
            result = build_graph().invoke(load_checkpoint(args.resume))
        else:
            result = build_graph().invoke({"seeds": args.url, "objective": args.goal or "Acquire authoritative regulatory instruments relevant to the supplied seeds and preserve their source text exactly."})
        print(json.dumps({"run_id": result.get("run_id"), "outputs": result.get("outputs", []), "completion": result.get("completion"), "errors": result.get("errors", [])}, indent=2, default=str))
