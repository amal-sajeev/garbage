from __future__ import annotations

import base64
import json
import os
from datetime import datetime, timezone
from typing import TypedDict

try:
    from langchain_google_genai import ChatGoogleGenerativeAI
    from langgraph.graph import END, START, StateGraph
except ImportError:
    ChatGoogleGenerativeAI = None
    END = START = StateGraph = None

from .models import AgentDecision, AgentMemory, CompletionAssessment, DocumentIdentity, FailureMemory, Plan, ValidationResult
from .observability import configure_logging, event, timed
from .prompts import AGENT, CLASSIFIER, PLANNER, QA
from .settings import Settings
from .storage import make_storage
from .tools import (
    authority_assessment, bounded_fetch, browser_extract, canonicalize, deterministic_quality,
    discover_links, extract_html, extract_pdf, sha256_text, slugify,
)

class State(TypedDict, total=False):
    objective: str
    seeds: list[str]
    plan: dict
    frontier: list[dict]
    candidates: list[dict]
    fetched: list[dict]
    documents: list[dict]
    outputs: list[dict]
    errors: list[str]
    review_candidates: list[dict]
    memory: dict
    decision: dict
    step: int
    run_id: str
    done: bool
    completion: dict
    history: list[dict]
    strategy: str
    repair_attempts: dict[str, int]


def _require_graph_dependencies() -> None:
    if ChatGoogleGenerativeAI is None or StateGraph is None:
        raise RuntimeError("LangChain/LangGraph dependencies are not installed; run pip install -e .")


def llm(settings: Settings, reasoning=False):
    _require_graph_dependencies()
    settings.require_llm_config()
    if settings.google_application_credentials:
        os.environ.setdefault("GOOGLE_APPLICATION_CREDENTIALS", settings.google_application_credentials)
    return ChatGoogleGenerativeAI(
        model=settings.gemini_reasoning_model if reasoning else settings.gemini_model,
        project=settings.google_cloud_project,
        location=settings.google_cloud_location,
        vertexai=settings.google_genai_use_vertexai,
        temperature=0,
        max_retries=settings.max_retries,
    )


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _load_registry(storage) -> dict:
    raw = storage.read("registry.json")
    if not raw:
        return {"documents": {}}
    try:
        parsed = json.loads(raw)
        return parsed if isinstance(parsed, dict) else {"documents": {}}
    except (json.JSONDecodeError, TypeError):
        return {"documents": {}}


def _load_memory(storage) -> AgentMemory:
    raw = storage.read("agent_memory.json")
    if not raw:
        return AgentMemory()
    try:
        return AgentMemory.model_validate(json.loads(raw))
    except Exception:
        return AgentMemory()


def _json_safe(value):
    if isinstance(value, bytes):
        return {"__bytes__": base64.b64encode(value).decode("ascii")}
    if isinstance(value, dict):
        return {k: _json_safe(v) for k, v in value.items()}
    if isinstance(value, list):
        return [_json_safe(v) for v in value]
    return value


def _json_restore(value):
    if isinstance(value, dict):
        if set(value) == {"__bytes__"}:
            return base64.b64decode(value["__bytes__"])
        return {k: _json_restore(v) for k, v in value.items()}
    if isinstance(value, list):
        return [_json_restore(v) for v in value]
    return value


def _save_checkpoint(state: State, settings: Settings) -> None:
    if not settings.checkpoint_every_step:
        return
    storage = make_storage(settings)
    payload = _json_safe(dict(state))
    storage.write(f"checkpoints/{state['run_id']}.json", json.dumps(payload, indent=2, ensure_ascii=False, default=str))


def load_checkpoint(run_id: str, settings: Settings | None = None) -> State:
    settings = settings or Settings()
    raw = make_storage(settings).read(f"checkpoints/{run_id}.json")
    if not raw:
        raise FileNotFoundError(f"Checkpoint not found: {run_id}")
    data = _json_restore(json.loads(raw))
    if not isinstance(data, dict):
        raise ValueError("Checkpoint is not a state object")
    data["resume"] = True
    return data


def plan_node(state: State) -> State:
    settings = Settings(); configure_logging(); settings.require_source_allowlist()
    if state.get("resume") and state.get("plan"):
        return state
    objective = state.get("objective") or "Acquire authoritative regulatory instruments relevant to the supplied seeds and preserve their source text exactly."
    prompt = PLANNER + f"\nOBJECTIVE:\n{objective}\nSEEDS:\n" + "\n".join(state["seeds"])
    with timed("plan"):
        plan = llm(settings, True).with_structured_output(Plan).invoke(prompt)
    return {"plan": plan.model_dump(), "strategy": plan.strategy, "memory": _load_memory(make_storage(settings)).model_dump(), "history": [], "step": 0, "done": False}


def _candidate_score(c: dict) -> float:
    return float(c.get("relevance", 0)) + (0.20 if c.get("kind") == "pdf" else 0) + (0.15 if c.get("authoritative") else 0)


def bootstrap_node(state: State) -> State:
    settings = Settings(); settings.require_source_allowlist()
    if state.get("resume"):
        return state
    seeds = []
    for u in state.get("seeds", []):
        cu = canonicalize(u)
        if cu not in seeds:
            seeds.append(cu)
    frontier = [{"url": u, "depth": 0, "reason": "seed"} for u in seeds]
    return {
        "seeds": seeds,
        "frontier": frontier,
        "candidates": [],
        "fetched": [],
        "documents": [],
        "outputs": [],
        "errors": [],
        "review_candidates": [],
        "run_id": state.get("run_id") or datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S%fZ"),
        "history": [], "step": 0, "done": False,
        "repair_attempts": {},
    }


def _all_urls(state: State) -> set[str]:
    vals = set(state.get("seeds", []))
    for key in ("frontier", "candidates", "fetched", "documents", "outputs"):
        for x in state.get(key, []):
            u = x.get("url") or x.get("source_url") or x.get("canonical_url")
            if u: vals.add(canonicalize(str(u)))
    return vals


def _failure(state: State, action: str, target: str | None, error: str, recovery: str | None = None) -> dict:
    mem = AgentMemory.model_validate(state.get("memory", {}))
    mem.failures.append(FailureMemory(action=action, target=target, error=str(error), recovery=recovery, timestamp=_now()))
    mem.failures = mem.failures[-100:]
    if recovery:
        mem.failed_strategies.append(recovery)
        mem.failed_strategies = list(dict.fromkeys(mem.failed_strategies))[-30:]
    return {"memory": mem.model_dump(), "errors": [*state.get("errors", []), f"{action} {target or ''}: {error}".strip()]}


def _frontier_item(state: State, url: str | None) -> dict | None:
    if not url:
        return None
    cu = canonicalize(url)
    for x in state.get("frontier", []):
        if canonicalize(x["url"]) == cu: return x
    for x in state.get("candidates", []):
        if canonicalize(x["url"]) == cu: return x
    return None


def _repair_check(state: State, action: str, target: str | None) -> dict[str, int]:
    counts = dict(state.get("repair_attempts", {}))
    if not target or action not in ("retry", "extract"):
        return counts
    cu = canonicalize(target)
    already_fetched = any(canonicalize(x.get("final_url", x.get("requested_url", ""))) == cu for x in state.get("fetched", []))
    already_extracted = any(x.get("canonical_url") == cu for x in state.get("documents", []))
    if (action == "retry" and already_fetched) or (action == "extract" and already_extracted):
        counts[cu] = counts.get(cu, 0) + 1
    return counts


def _reject_candidate(state: State, target: str) -> list[dict]:
    candidates = [dict(x) for x in state.get("candidates", [])]
    for c in candidates:
        if canonicalize(c.get("url", "")) == target:
            c["status"] = "rejected"
    return candidates


def _fetch_one(url: str, settings: Settings) -> dict:
    return bounded_fetch([url], settings)[0]


def _extract_one(item: dict, settings: Settings) -> dict:
    url = item.get("final_url", item.get("requested_url")); content = item["content"]; ct = item.get("content_type", "").lower()
    is_pdf = item.get("kind") == "pdf" or "pdf" in ct or url.lower().endswith(".pdf")
    if is_pdf:
        raw, warns, pages = extract_pdf(content, settings); fmt = "pdf"
    else:
        raw, warns = extract_html(content.decode("utf-8", errors="replace")); pages = None; fmt = "html"
        if len(raw) < settings.min_extracted_chars and settings.enable_browser_rendering:
            raw, bwarns = browser_extract(url, settings); warns.extend(bwarns)
    if len(raw) < settings.min_extracted_chars:
        raise ValueError(f"extraction too short ({len(raw)} chars)")
    ident = llm(settings, False).with_structured_output(DocumentIdentity).invoke(
        CLASSIFIER + f"\nSOURCE URL: {url}\nTITLE HINT: {item.get('title') or url}\nTEXT:\n{raw[:24000]}"
    )
    authority_score, authority_reasons = authority_assessment(url, ident.model_dump(), settings)
    low = raw[:12000].lower()
    authority_score = min(1.0, authority_score + min(.15, sum(t in low for t in ("effective date", "regulation", "rule", "section", "article", "shall", "pursuant")) * .02))
    if ident.authority_class != "instrument" or authority_score < settings.min_authority_confidence:
        raise PermissionError(f"authority gate rejected: {ident.authority_class}, confidence={authority_score:.2f}")
    return {
        "identity": ident.model_dump(), "source_url": url, "canonical_url": canonicalize(url),
        "source_format": fmt, "retrieved_at": item["retrieved_at"], "raw_text": raw,
        "raw_sha256": sha256_text(raw), "page_count": pages, "extraction_warnings": warns,
        "authority_confidence": round(authority_score, 4), "authority_reasons": authority_reasons,
    }


def render_markdown(doc: dict) -> str:
    ident = doc["identity"]
    fm = {"title": ident["title"], "publisher": ident["publisher"], "jurisdiction": ident.get("jurisdiction"), "identifier": ident.get("identifier"), "document_type": ident["document_type"], "effective_date": ident.get("effective_date"), "issue_date": ident.get("issue_date"), "source_url": doc["source_url"], "canonical_url": doc["canonical_url"], "retrieved_at": doc["retrieved_at"], "source_format": doc["source_format"], "source_sha256": doc["raw_sha256"], "authority_confidence": doc.get("authority_confidence"), "extraction_warnings": doc.get("extraction_warnings", [])}
    yaml = ["---"] + [f"{k}: {json.dumps(v, ensure_ascii=False)}" for k, v in fm.items() if v is not None] + ["---", ""]
    return "\n".join(yaml) + doc["raw_text"].strip() + "\n"


def _validate_output(out: dict, prior: dict | None, settings: Settings) -> dict:
    det = out["det_quality"]
    prompt = QA + f"\nSOURCE URL: {out['source_url']}\nIDENTITY: {json.dumps(out['identity'])}\nDETERMINISTIC QUALITY: {json.dumps(det)}\nMARKDOWN:\n{out['markdown'][:60000]}"
    try:
        qa = llm(settings, True).with_structured_output(ValidationResult).invoke(prompt)
    except Exception as exc:
        qa = ValidationResult(status="repair", score=0.0, source_fidelity_score=det["coverage"], issues=[f"LLM QA failed: {exc}"], notes="Cannot auto-accept without QA")
    score = min(qa.score, det["score"], out.get("authority_confidence", 0))
    status = qa.status
    if det["coverage"] < .85: status = "reject"
    elif det.get("missing_tail"): status = "repair"
    elif score < settings.min_quality_score: status = "repair" if status != "reject" else status
    version_kind = "new" if not prior else ("unchanged" if prior.get("source_sha256") == out["raw_sha256"] else "changed")
    qa = qa.model_copy(update={"status": status, "score": round(max(0, min(1, score)), 4), "source_fidelity_score": det["coverage"], "deterministic_checks": {**det, "authority_confidence": out.get("authority_confidence", 0), "version_kind": version_kind}})
    return {**out, "validation": qa.model_dump(), "version_kind": version_kind, "previous_version": prior}


def _completion(state: State) -> CompletionAssessment:
    accepted = [o for o in state.get("outputs", []) if o.get("validation", {}).get("status") == "accept"]
    pending = len(state.get("frontier", [])) + len([c for c in state.get("candidates", []) if c.get("status") not in {"validated", "rejected"}])
    extractable = len(state.get("documents", []))
    blockers = []
    if not accepted and not state.get("errors") and pending == 0: blockers.append("No authoritative instrument was acquired")
    if state.get("step", 0) >= Settings().max_agent_steps: blockers.append("Agent step budget exhausted")
    complete = bool(accepted) or (pending == 0 and bool(state.get("errors")))
    evidence = [f"accepted_documents={len(accepted)}", f"extracted_documents={extractable}", f"pending_targets={pending}"]
    return CompletionAssessment(complete=complete, confidence=1.0 if accepted else .75 if pending == 0 else .2, blockers=blockers, evidence=evidence)


def _decision_context(state: State) -> str:
    compact = {
        "objective": state.get("objective"), "strategy": state.get("strategy"), "plan": state.get("plan", {}),
        "step": state.get("step", 0), "max_steps": Settings().max_agent_steps,
        "frontier": state.get("frontier", [])[:20],
        "candidates": [{k: c.get(k) for k in ("url", "title", "kind", "relevance", "depth", "status", "reason")} for c in state.get("candidates", [])[:30]],
        "fetched": [{k: x.get(k) for k in ("requested_url", "final_url", "content_type", "error")} for x in state.get("fetched", [])[-20:]],
        "documents": [{k: x.get(k) for k in ("source_url", "canonical_url", "authority_confidence", "source_format")} for x in state.get("documents", [])],
        "outputs": [{"source_url": x.get("source_url"), "status": x.get("validation", {}).get("status")} for x in state.get("outputs", [])],
        "errors": state.get("errors", [])[-20:], "memory": state.get("memory", {}),
        "history": state.get("history", [])[-12:], "completion": _completion(state).model_dump(),
    }
    return AGENT + "\nSTATE:\n" + json.dumps(compact, ensure_ascii=False, default=str)


def agent_decide_node(state: State) -> State:
    settings = Settings(); settings.require_source_allowlist()
    if state.get("step", 0) >= settings.max_agent_steps:
        decision = AgentDecision(action="finish", reason="Step budget exhausted")
    else:
        completion = _completion(state)
        if completion.complete:
            decision = AgentDecision(action="finish", reason="Deterministic completion gate is satisfied", expected_evidence=completion.evidence)
        else:
            decision = llm(settings, True).with_structured_output(AgentDecision).invoke(_decision_context(state))
    return {"decision": decision.model_dump()}


def execute_action_node(state: State) -> State:
    settings = Settings(); settings.require_source_allowlist()
    d = AgentDecision.model_validate(state.get("decision", {})); action = d.action; target = canonicalize(d.target) if d.target else None
    next_state: State = {"step": state.get("step", 0) + 1}
    history = list(state.get("history", [])); history.append({"step": next_state["step"], "action": action, "target": target, "reason": d.reason})
    next_state["history"] = history[-100:]
    next_state["strategy"] = d.strategy_change or state.get("strategy", "")
    try:
        if action == "finish":
            next_state["done"] = True
            next_state["completion"] = _completion(state).model_dump()
        elif action in {"discover", "fetch", "retry"}:
            if not target or not _frontier_item(state, target):
                raise ValueError("target must be a concrete frontier/candidate URL")
            item = _frontier_item(state, target) or {"url": target}
            if action == "retry":
                counts = _repair_check(state, "retry", target)
                next_state["repair_attempts"] = counts
                if counts.get(target, 0) > settings.max_repair_attempts:
                    next_state["candidates"] = _reject_candidate(state, target)
                    raise ValueError(f"repair budget exhausted for {target} after {counts[target]} attempts")
            fetched = _fetch_one(target, settings)
            if "error" in fetched: raise RuntimeError(fetched["error"])
            fetched = {**item, **fetched, "status": "fetched"}
            fs = [x for x in state.get("fetched", []) if canonicalize(x.get("final_url", x.get("requested_url", ""))) != target]
            fs.append(fetched)
            next_state["fetched"] = fs
            candidates = [dict(x) for x in state.get("candidates", [])]
            found = False
            for c in candidates:
                if canonicalize(c["url"]) == target: c.update(fetched); c["status"] = "fetched"; found = True
            if not found: candidates.append(fetched)
            next_state["candidates"] = candidates
            frontier = [x for x in state.get("frontier", []) if canonicalize(x["url"]) != target]
            next_state["frontier"] = frontier
            if action == "discover" and fetched.get("content_type", "").lower().find("html") >= 0:
                links = discover_links(fetched["final_url"], fetched["content"].decode("utf-8", errors="replace"), settings, state.get("plan", {}).get("discovery_terms", []))
                known = _all_urls(state) | {canonicalize(x["url"]) for x in candidates}
                new_depth = int(item.get("depth", 0)) + 1
                for c in links:
                    cu = canonicalize(c["url"])
                    if cu not in known and c.get("relevance", 0) >= .10 and new_depth <= settings.max_discovery_depth:
                        frontier.append({"url": cu, "depth": new_depth, "reason": c.get("reason", "discovered"), "title": c.get("title"), "kind": c.get("kind"), "relevance": c.get("relevance", 0)})
                next_state["frontier"] = frontier[:settings.max_pages]
        elif action == "expand":
            if not target: raise ValueError("expand requires a fetched HTML URL")
            item = next((x for x in state.get("fetched", []) if canonicalize(x.get("final_url", x.get("requested_url", ""))) == target), None)
            if not item: raise ValueError("expand target is not fetched")
            if "html" not in item.get("content_type", "").lower(): raise ValueError("expand target is not HTML")
            links = discover_links(item["final_url"], item["content"].decode("utf-8", errors="replace"), settings, state.get("plan", {}).get("discovery_terms", []))
            known = _all_urls(state); frontier = list(state.get("frontier", []))
            new_depth = int(item.get("depth", 0)) + 1
            for c in links:
                cu = canonicalize(c["url"])
                if cu not in known and c.get("relevance", 0) >= .10 and new_depth <= settings.max_discovery_depth:
                    frontier.append({"url": cu, "depth": new_depth, "reason": "expanded fetched source", **{k: c.get(k) for k in ("title", "kind", "relevance")}})
                    known.add(cu)
            next_state["frontier"] = frontier[:settings.max_pages]
        elif action == "extract":
            if not target: raise ValueError("extract requires a fetched URL")
            item = next((x for x in state.get("fetched", []) if canonicalize(x.get("final_url", x.get("requested_url", ""))) == target), None)
            if not item: raise ValueError("extract target is not fetched")
            counts = _repair_check(state, "extract", target)
            next_state["repair_attempts"] = counts
            if counts.get(target, 0) > settings.max_repair_attempts:
                next_state["candidates"] = _reject_candidate(state, target)
                raise ValueError(f"repair budget exhausted for {target} after {counts[target]} attempts")
            doc = _extract_one(item, settings)
            docs = [x for x in state.get("documents", []) if x.get("canonical_url") != doc["canonical_url"]]; docs.append(doc)
            next_state["documents"] = docs
            candidates = [dict(x) for x in state.get("candidates", [])]
            for c in candidates:
                if canonicalize(c["url"]) == target: c["status"] = "extracted"
            next_state["candidates"] = candidates
        elif action == "validate":
            if not target: raise ValueError("validate requires a source URL")
            doc = next((x for x in state.get("documents", []) if canonicalize(x.get("source_url", "")) == target), None)
            if not doc: raise ValueError("validate target is not extracted")
            md = render_markdown(doc); det = deterministic_quality(doc["raw_text"], md)
            out = {**doc, "markdown": md, "markdown_sha256": sha256_text(md), "det_quality": det}
            prior = _load_registry(make_storage(settings)).get("documents", {}).get(doc["canonical_url"])
            out = _validate_output(out, prior, settings)
            outputs = [x for x in state.get("outputs", []) if x.get("canonical_url") != out["canonical_url"]]; outputs.append(out)
            next_state["outputs"] = outputs
            if out["validation"]["status"] != "accept":
                next_state["review_candidates"] = [*state.get("review_candidates", []), {"source_url": target, "stage": "validation", "status": out["validation"]["status"], "issues": out["validation"].get("issues", [])}]
        elif action == "reconsider":
            mem = AgentMemory.model_validate(state.get("memory", {})); mem.successful_strategies.append(d.strategy_change or d.reason); mem.successful_strategies = list(dict.fromkeys(mem.successful_strategies))[-30:]
            next_state["memory"] = mem.model_dump()
        else:
            raise ValueError(f"Unsupported action: {action}")
    except Exception as exc:
        next_state.update(_failure(state, action, target, exc, d.strategy_change))
    merged = dict(state); merged.update(next_state)
    if next_state.get("step", 0) > 0:
        _save_checkpoint(merged, settings)
    event("agent_action", step=next_state["step"], action=action, target=target, errors=len(merged.get("errors", [])))
    return next_state


def route_after_action(state: State) -> str:
    return "end" if state.get("done") or state.get("step", 0) >= Settings().max_agent_steps else "continue"


def persist_node(state: State) -> State:
    settings = Settings(); settings.require_source_allowlist(); storage = make_storage(settings)
    run = state.get("run_id", "run"); registry = _load_registry(storage); registry.setdefault("documents", {})
    accepted=[]; review=list(state.get("review_candidates", [])); manifest={"run_id":run,"created_at":_now(),"objective":state.get("objective"),"strategy":state.get("strategy"),"steps":state.get("step",0),"history":state.get("history",[]),"errors":state.get("errors",[]),"completion":state.get("completion") or _completion(state).model_dump(),"documents":[]}
    for out in state.get("outputs", []):
        v=out.get("validation", {}); ident=out["identity"]
        if v.get("status") != "accept":
            review.append({"source_url":out["source_url"],"stage":"validation","status":v.get("status"),"issues":v.get("issues",[]),"missing_sections":v.get("missing_sections",[]),"identity":ident}); continue
        publisher=slugify(ident.get("publisher") or "unknown"); title=slugify(ident["title"]); suffix=slugify(ident.get("identifier") or "") or out["raw_sha256"][:12]; filename=f"{title}-{suffix}.md" if suffix not in title else f"{title}.md"; key=f"{publisher}/{filename}"; path=storage.write(key,out["markdown"],if_absent=False)
        prior=registry["documents"].get(out["canonical_url"]); now=_now(); history=list((prior or {}).get("history",[]))
        if prior and prior.get("source_sha256") != out["raw_sha256"]: history.append({"source_sha256":prior.get("source_sha256"),"markdown_sha256":prior.get("markdown_sha256"),"path":prior.get("path"),"seen_at":now})
        registry["documents"][out["canonical_url"]]={"path":path,"source_url":out["source_url"],"canonical_url":out["canonical_url"],"title":ident["title"],"identifier":ident.get("identifier"),"effective_date":ident.get("effective_date"),"issue_date":ident.get("issue_date"),"source_sha256":out["raw_sha256"],"markdown_sha256":out["markdown_sha256"],"first_seen":(prior or {}).get("first_seen",now),"last_seen":now,"version_kind":out.get("version_kind","new"),"history":history}
        item={"path":path,"source_url":out["source_url"],"sha256":out["markdown_sha256"],"source_sha256":out["raw_sha256"],"version_kind":out.get("version_kind","new")}
        if settings.enable_source_snapshots: storage.write(f"snapshots/{out['raw_sha256']}.txt",out["raw_text"],if_absent=True); item["snapshot"]=f"snapshots/{out['raw_sha256']}.txt"
        accepted.append(item); manifest["documents"].append(item)
    manifest["review"]=review; storage.write("registry.json",json.dumps(registry,indent=2,ensure_ascii=False)); storage.write(f"manifests/{run}.json",json.dumps(manifest,indent=2,ensure_ascii=False)); storage.write("agent_memory.json",json.dumps(state.get("memory",{}),indent=2,ensure_ascii=False))
    if settings.require_human_review_on_rejection and review: storage.write(f"review/{run}.json",json.dumps(review,indent=2,ensure_ascii=False))
    event("persistence_complete",accepted=len(accepted),review=len(review),steps=state.get("step",0),storage=storage.__class__.__name__)
    return {"outputs":accepted,"review_candidates":review,"done":True,"completion":manifest["completion"]}


def build_graph():
    _require_graph_dependencies()
    g=StateGraph(State)
    for name,fn in [("bootstrap",bootstrap_node),("plan",plan_node),("agent_decide",agent_decide_node),("execute_action",execute_action_node),("persist",persist_node)]: g.add_node(name,fn)
    g.add_edge(START,"bootstrap"); g.add_edge("bootstrap","plan"); g.add_edge("plan","agent_decide"); g.add_edge("agent_decide","execute_action")
    g.add_conditional_edges("execute_action",route_after_action,{"continue":"agent_decide","end":"persist"}); g.add_edge("persist",END)
    return g.compile()
