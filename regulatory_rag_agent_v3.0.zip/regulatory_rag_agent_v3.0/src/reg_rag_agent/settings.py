from __future__ import annotations

from pathlib import Path
from pydantic import field_validator
from pydantic_settings import BaseSettings, SettingsConfigDict

class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", extra="ignore", case_sensitive=False)

    google_cloud_project: str | None = None
    google_cloud_location: str = "us-central1"
    google_genai_use_vertexai: bool = True
    google_application_credentials: str | None = None
    gemini_model: str = "gemini-2.5-flash"
    gemini_reasoning_model: str = "gemini-2.5-pro"
    output_dir: Path = Path("./corpus")
    source_allowlist: str = ""
    max_pages: int = 100
    max_bytes: int = 60_000_000
    max_discovery_depth: int = 2
    max_candidates_per_page: int = 100
    request_timeout_seconds: float = 45.0
    max_concurrent_fetches: int = 6
    max_retries: int = 3
    max_redirects: int = 5
    backoff_base_seconds: float = 1.0
    max_repair_attempts: int = 2
    max_agent_steps: int = 40
    checkpoint_every_step: bool = True
    min_extracted_chars: int = 300
    min_quality_score: float = 0.90
    min_authority_confidence: float = 0.80
    user_agent: str = "RegulatoryRAGAgent/3.0 (+regulatory corpus acquisition)"
    respect_robots_txt: bool = True
    enable_ocr: bool = False
    ocr_language: str = "eng"
    ocr_dpi: int = 200
    enable_browser_rendering: bool = False
    browser_timeout_seconds: float = 60.0
    enable_source_snapshots: bool = True
    require_human_review_on_rejection: bool = True
    gcs_bucket: str | None = None
    gcs_prefix: str = "corpus"

    @property
    def allowed_hosts(self) -> set[str]:
        return {h.strip().lower() for h in self.source_allowlist.split(",") if h.strip()}

    @field_validator("output_dir", mode="before")
    @classmethod
    def normalize_output_dir(cls, v):
        return Path(v).expanduser()

    def require_source_allowlist(self) -> None:
        if not self.allowed_hosts:
            raise ValueError("SOURCE_ALLOWLIST is required for acquisition")

    def require_llm_config(self) -> None:
        if not self.google_cloud_project:
            raise ValueError("GOOGLE_CLOUD_PROJECT is required for Gemini/Vertex mode")
