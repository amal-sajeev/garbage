from __future__ import annotations

from pathlib import Path, PurePosixPath
from typing import Protocol


def _safe_key(key: str) -> str:
    key = key.replace("\\", "/").lstrip("/")
    parts = PurePosixPath(key).parts
    if not key or any(part in {"", ".", ".."} for part in parts):
        raise ValueError("Storage key must be a non-empty relative path without traversal")
    return "/".join(parts)


class Storage(Protocol):
    def write(self, key: str, content: str, *, if_absent: bool = False) -> str: ...
    def read(self, key: str) -> str | None: ...
    def exists(self, key: str) -> bool: ...


class LocalStorage:
    def __init__(self, root: Path):
        self.root = Path(root).expanduser().resolve()
        self.root.mkdir(parents=True, exist_ok=True)

    def _path(self, key: str) -> Path:
        safe = _safe_key(key)
        p = (self.root / safe).resolve()
        try:
            p.relative_to(self.root)
        except ValueError as exc:
            raise ValueError("Storage key escapes output directory") from exc
        return p

    def write(self, key: str, content: str, *, if_absent: bool = False) -> str:
        p = self._path(key)
        p.parent.mkdir(parents=True, exist_ok=True)
        if if_absent and p.exists():
            return str(p)
        tmp = p.with_name(f".{p.name}.tmp-{__import__('time').time_ns()}")
        try:
            with tmp.open("w", encoding="utf-8") as fh:
                fh.write(content)
                fh.flush()
                __import__('os').fsync(fh.fileno())
            tmp.replace(p)
        finally:
            tmp.unlink(missing_ok=True)
        return str(p)

    def read(self, key: str) -> str | None:
        p = self._path(key)
        return p.read_text(encoding="utf-8") if p.exists() else None

    def exists(self, key: str) -> bool:
        return self._path(key).exists()


class GCSStorage:
    def __init__(self, bucket: str, prefix: str = ""):
        if not bucket.strip():
            raise ValueError("GCS bucket name cannot be empty")
        from google.cloud import storage
        self.client = storage.Client()
        self.bucket = self.client.bucket(bucket)
        self.prefix = prefix.strip("/")
        if self.prefix and any(part in {".", ".."} for part in PurePosixPath(self.prefix).parts):
            raise ValueError("GCS prefix cannot contain traversal segments")

    def _blob_name(self, key: str) -> str:
        safe = _safe_key(key)
        return f"{self.prefix}/{safe}" if self.prefix else safe

    def write(self, key: str, content: str, *, if_absent: bool = False) -> str:
        blob = self.bucket.blob(self._blob_name(key))
        kwargs = {"if_generation_match": 0} if if_absent else {}
        blob.upload_from_string(content, content_type="text/plain; charset=utf-8", **kwargs)
        return f"gs://{self.bucket.name}/{blob.name}"

    def read(self, key: str) -> str | None:
        blob = self.bucket.blob(self._blob_name(key))
        try:
            return blob.download_as_text()
        except Exception as exc:
            if exc.__class__.__name__ in {"NotFound", "ResourceNotFoundError"}:
                return None
            raise

    def exists(self, key: str) -> bool:
        return self.bucket.blob(self._blob_name(key)).exists()


def make_storage(settings) -> Storage:
    if settings.gcs_bucket:
        return GCSStorage(settings.gcs_bucket, settings.gcs_prefix)
    return LocalStorage(settings.output_dir)
