from __future__ import annotations

import json
import logging
import time
from contextlib import contextmanager

logger = logging.getLogger("regulatory_rag_agent")


def configure_logging():
    if not logger.handlers:
        h = logging.StreamHandler()
        h.setFormatter(logging.Formatter("%(message)s"))
        logger.addHandler(h)
        logger.setLevel(logging.INFO)


def event(name: str, **fields):
    logger.info(json.dumps({"event": name, **fields}, ensure_ascii=False, default=str))

@contextmanager
def timed(name: str, **fields):
    started = time.perf_counter()
    try:
        yield
    finally:
        event(name, duration_ms=round((time.perf_counter() - started) * 1000, 1), **fields)
