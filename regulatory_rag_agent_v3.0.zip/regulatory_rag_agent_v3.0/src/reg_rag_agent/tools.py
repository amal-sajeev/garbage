from __future__ import annotations

import hashlib
import re
import time
from collections import Counter
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timezone
from urllib import robotparser
from urllib.parse import urldefrag, urljoin, urlparse

import fitz
import httpx
try:
    import trafilatura
except ImportError:
    trafilatura = None
from bs4 import BeautifulSoup
try:
    from langchain_core.tools import tool
except ImportError:
    def tool(fn):
        return fn
from markdownify import markdownify

from .models import SourceCandidate
from .observability import timed
from .settings import Settings

_ROBOTS_CACHE: dict[str, robotparser.RobotFileParser | None] = {}


def host(url: str) -> str:
    return urlparse(url).netloc.lower().split(":", 1)[0]


def allowed(url: str, settings: Settings) -> bool:
    if urlparse(url).scheme not in {"http", "https"}:
        return False
    allow = settings.allowed_hosts
    h = host(url)
    return bool(allow) and any(h == a or h.endswith("." + a) for a in allow)


def canonicalize(url: str) -> str:
    url, _ = urldefrag(url.strip())
    p = urlparse(url)
    path = re.sub(r"/{2,}", "/", p.path or "/")
    if path != "/":
        path = path.rstrip("/")
    return p._replace(fragment="", path=path).geturl()


def robots_allowed(url: str, settings: Settings) -> bool:
    if not settings.respect_robots_txt:
        return True
    p = urlparse(url)
    root = f"{p.scheme}://{p.netloc}"
    if root not in _ROBOTS_CACHE:
        rp = robotparser.RobotFileParser()
        rp.set_url(root + "/robots.txt")
        try:
            rp.read()
            _ROBOTS_CACHE[root] = rp
        except Exception:
            # Unavailable robots.txt is treated as allow, while explicit denial is enforced.
            _ROBOTS_CACHE[root] = None
    rp = _ROBOTS_CACHE[root]
    return True if rp is None else rp.can_fetch(settings.user_agent, url)


def _request(url: str, settings: Settings) -> dict:
    requested = canonicalize(url)
    if not allowed(requested, settings):
        raise ValueError(f"Host is not allowlisted: {host(requested)}")
    if not robots_allowed(requested, settings):
        raise ValueError(f"robots.txt disallows fetch: {requested}")
    last: Exception | None = None
    for attempt in range(settings.max_retries):
        try:
            with httpx.Client(
                follow_redirects=False,
                timeout=settings.request_timeout_seconds,
                headers={"User-Agent": settings.user_agent, "Accept": "text/html,application/pdf;q=0.9,*/*;q=0.5"},
            ) as client:
                current = requested
                for _ in range(settings.max_redirects + 1):
                    if not allowed(current, settings):
                        raise ValueError(f"Redirect target is not allowlisted: {host(current)}")
                    if not robots_allowed(current, settings):
                        raise ValueError(f"robots.txt disallows redirect target: {current}")
                    with client.stream("GET", current) as r:
                        if r.status_code in {301, 302, 303, 307, 308}:
                            location = r.headers.get("location")
                            if not location:
                                raise ValueError("Redirect response has no Location header")
                            current = canonicalize(urljoin(current, location))
                            continue
                        r.raise_for_status()
                        chunks: list[bytes] = []
                        total = 0
                        for chunk in r.iter_bytes():
                            total += len(chunk)
                            if total > settings.max_bytes:
                                raise ValueError(f"Response exceeds MAX_BYTES={settings.max_bytes}")
                            chunks.append(chunk)
                        final_url = canonicalize(str(r.url))
                        return {
                            "requested_url": requested, "final_url": final_url,
                            "content_type": r.headers.get("content-type", ""),
                            "content": b"".join(chunks), "status_code": r.status_code,
                            "headers": dict(r.headers),
                            "retrieved_at": datetime.now(timezone.utc).isoformat(),
                        }
                raise ValueError(f"Too many redirects (>{settings.max_redirects})")
        except httpx.HTTPStatusError as exc:
            if exc.response.status_code not in {408, 425, 429, 500, 502, 503, 504}:
                raise
            last = exc
            if attempt < settings.max_retries - 1:
                time.sleep(settings.backoff_base_seconds * (2 ** attempt))
        except (httpx.RequestError, TimeoutError, OSError) as exc:
            last = exc
            if attempt < settings.max_retries - 1:
                time.sleep(settings.backoff_base_seconds * (2 ** attempt))
    raise last or RuntimeError("fetch failed")


def fetch(url: str, settings: Settings) -> dict:
    with timed("fetch", url=canonicalize(url)):
        return _request(url, settings)


@tool
def fetch_url(url: str) -> dict:
    """Fetch an approved HTTP(S) source and return JSON-safe metadata plus hex bytes."""
    settings = Settings()
    r = fetch(url, settings)
    return {**{k: v for k, v in r.items() if k != "content"}, "bytes_hex": r["content"].hex()}

def _regulatory_score(href: str, text: str, terms: list[str] | None = None) -> float:
    low = f"{href} {text}".lower()
    weighted = {
        "master direction": .45, "regulation": .35, "rule": .30, "statute": .35,
        "directive": .25, "code": .20, "part": .15, "article": .15,
        "download": .12, "pdf": .12, "legislation": .30, "supervision": .18,
        "reporting": .18, "disclosure": .18, "amendment": .22, "effective": .15,
    }
    if terms:
        weighted.update({t.lower(): max(weighted.get(t.lower(), 0), .20) for t in terms})
    score = sum(w for term, w in weighted.items() if term in low)
    return min(score, 1.0)


def discover_links(base_url: str, html: str, settings: Settings, terms: list[str] | None = None) -> list[dict]:
    soup = BeautifulSoup(html, "lxml")
    candidates: list[dict] = []
    for a in soup.find_all("a", href=True):
        href = canonicalize(urljoin(base_url, a["href"]))
        if not allowed(href, settings):
            continue
        text = " ".join(a.stripped_strings)
        kind = "pdf" if ("pdf" in text.lower() or href.lower().endswith(".pdf")) else "html"
        score = _regulatory_score(href, text, terms)
        candidates.append(SourceCandidate(
            url=href, title=text or None, kind=kind, relevance=score,
            reason="matched regulatory/download signals", authoritative=True,
        ).model_dump(mode="json"))
    candidates.sort(key=lambda x: (x["relevance"], bool(x["title"])), reverse=True)
    ded: dict[str, dict] = {}
    for c in candidates:
        ded.setdefault(c["url"], c)
    return list(ded.values())[:settings.max_candidates_per_page]


def extract_html(html: str) -> tuple[str, list[str]]:
    warnings: list[str] = []
    soup = BeautifulSoup(html, "lxml")
    for tag in soup(["script", "style", "noscript", "svg", "canvas", "form", "nav", "footer"]):
        tag.decompose()
    main = soup.find("main") or soup.find("article")
    if main is None:
        extracted = trafilatura.extract(html, include_links=False, include_tables=True, favor_precision=True) if trafilatura else None
        if extracted:
            return clean_markdown(extracted), warnings
        main = soup.body or soup
        warnings.append("No semantic main/article element; used body fallback")
    md = markdownify(str(main), heading_style="ATX", bullets="-")
    md = clean_markdown(md)
    if len(md) < 500:
        warnings.append("HTML extraction produced unusually little text")
    return md, warnings


def _ocr_pdf(data: bytes, settings: Settings, existing_pages: dict[int, str] | None = None) -> tuple[str, list[str], int]:
    try:
        import pytesseract
        from PIL import Image
        from io import BytesIO
    except ImportError as exc:
        raise RuntimeError("OCR requested but pytesseract/Pillow are not installed") from exc
    doc = fitz.open(stream=data, filetype="pdf")
    existing_pages = existing_pages or {}
    parts: list[str] = []
    ocr_pages = 0
    for i, page in enumerate(doc, start=1):
        text = existing_pages.get(i, "").strip()
        if not text:
            pix = page.get_pixmap(dpi=settings.ocr_dpi, alpha=False)
            image = Image.open(BytesIO(pix.tobytes("png")))
            text = pytesseract.image_to_string(image, lang=settings.ocr_language).strip()
            ocr_pages += 1
        parts.append(f"\n<!-- source-page: {i} -->\n\n{text}")
    warnings = [f"OCR applied to {ocr_pages} text-empty PDF pages"] if ocr_pages else []
    return clean_markdown("\n".join(parts)), warnings, doc.page_count


def extract_pdf(data: bytes, settings: Settings | None = None) -> tuple[str, list[str], int]:
    settings = settings or Settings()
    doc = fitz.open(stream=data, filetype="pdf")
    parts: list[str] = []
    page_text: dict[int, str] = {}
    text_pages = 0
    for i, page in enumerate(doc, start=1):
        text = page.get_text("text").strip()
        page_text[i] = text
        text_pages += bool(text)
        parts.append(f"\n<!-- source-page: {i} -->\n\n{text}")
    warnings: list[str] = []
    if doc.page_count and text_pages / doc.page_count < .8:
        warnings.append(f"Only {text_pages}/{doc.page_count} PDF pages yielded text")
        if settings.enable_ocr:
            return _ocr_pdf(data, settings, page_text)
        warnings.append("OCR is disabled; scanned pages may be incomplete")
    return clean_markdown("\n".join(parts)), warnings, doc.page_count


def browser_extract(url: str, settings: Settings) -> tuple[str, list[str]]:
    if not settings.enable_browser_rendering:
        raise RuntimeError("Browser rendering is disabled")
    if not allowed(url, settings):
        raise ValueError(f"Browser URL is not allowlisted: {host(url)}")
    if not robots_allowed(url, settings):
        raise ValueError(f"robots.txt disallows browser fetch: {url}")
    try:
        from playwright.sync_api import sync_playwright
    except ImportError as exc:
        raise RuntimeError("Browser rendering requested but playwright is not installed") from exc
    with sync_playwright() as p:
        browser = p.chromium.launch(headless=True)
        try:
            page = browser.new_page(user_agent=settings.user_agent)
            response = page.goto(url, wait_until="networkidle", timeout=int(settings.browser_timeout_seconds * 1000))
            if response is None:
                raise RuntimeError("Browser navigation returned no response")
            final_url = canonicalize(page.url)
            if not allowed(final_url, settings):
                raise ValueError(f"Browser navigation redirected to non-allowlisted host: {host(final_url)}")
            html = page.content()
        finally:
            browser.close()
    text, warnings = extract_html(html)
    warnings.append("HTML obtained using browser rendering")
    return text, warnings

def clean_markdown(text: str) -> str:
    text = re.sub(r"[ \t]+\n", "\n", text)
    text = re.sub(r"\n{4,}", "\n\n\n", text)
    return text.strip() + "\n"


def deterministic_quality(raw: str, md: str) -> dict:
    def norm(s): return re.sub(r"[^a-z0-9]+", " ", s.lower()).split()
    a, b = norm(raw), norm(md)
    if not a or not b:
        return {"score": 0.0, "coverage": 0.0, "length_ratio": 0.0, "missing_tail": True}
    ca, cb = Counter(a), Counter(b)
    overlap = sum(min(v, cb[k]) for k, v in ca.items())
    coverage = overlap / max(1, len(a))
    ratio = len(b) / len(a)
    ratio_score = max(0.0, 1.0 - min(abs(1 - ratio), .8) / .8)
    # Compare the final 5% of normalized source tokens to catch truncation.
    tail = a[max(0, int(len(a) * .95)):]
    tail_hits = sum(1 for t in tail if t in cb) / max(1, len(tail))
    missing_tail = tail_hits < .80
    score = .70 * coverage + .20 * ratio_score + .10 * tail_hits
    return {
        "score": round(score, 4), "coverage": round(coverage, 4),
        "length_ratio": round(ratio, 4), "tail_coverage": round(tail_hits, 4),
        "missing_tail": missing_tail,
    }


def authority_assessment(url: str, identity: dict, settings: Settings) -> tuple[float, list[str]]:
    reasons: list[str] = []
    h = host(url)
    score = 0.0
    if settings.allowed_hosts and h in settings.allowed_hosts:
        score += .45; reasons.append("host is explicitly allowlisted")
    elif settings.allowed_hosts and any(h.endswith("." + x) for x in settings.allowed_hosts):
        score += .40; reasons.append("host is a subdomain of an allowlisted authority")
    else:
        reasons.append("host is not allowlisted")
    publisher = (identity.get("publisher") or "").lower()
    if publisher and any(part in publisher for part in re.split(r"[\s,/()]+", h) if len(part) > 3):
        score += .20; reasons.append("publisher metadata is compatible with source host")
    else:
        score += .05
    if identity.get("authority_class") == "instrument":
        score += .25; reasons.append("classifier identified an authoritative instrument")
    elif identity.get("authority_class") == "guidance":
        score += .10; reasons.append("classified as official guidance, not an instrument")
    return round(min(score, 1.0), 4), reasons


def sha256_text(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def slugify(value: str) -> str:
    value = re.sub(r"[^a-zA-Z0-9]+", "-", value.lower()).strip("-")
    return value[:180] or "document"


def bounded_fetch(urls: list[str], settings: Settings) -> list[dict]:
    out: list[dict] = []
    with ThreadPoolExecutor(max_workers=max(1, settings.max_concurrent_fetches)) as ex:
        futures = {ex.submit(fetch, u, settings): u for u in urls}
        for fut in as_completed(futures):
            u = futures[fut]
            try:
                out.append(fut.result())
            except Exception as e:
                out.append({"requested_url": canonicalize(u), "error": str(e)})
    return out
