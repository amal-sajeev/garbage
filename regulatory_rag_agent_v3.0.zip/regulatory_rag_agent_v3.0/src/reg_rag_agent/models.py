from __future__ import annotations

from typing import Literal
from pydantic import BaseModel, Field, HttpUrl

AuthorityClass = Literal["instrument", "index", "guidance", "secondary", "irrelevant"]

class SourceCandidate(BaseModel):
    url: HttpUrl
    title: str | None = None
    kind: Literal["html", "pdf", "unknown"] = "unknown"
    relevance: float = Field(0, ge=0, le=1)
    reason: str = ""
    depth: int = 0
    authoritative: bool = True

class DocumentIdentity(BaseModel):
    authority_class: AuthorityClass = "instrument"
    title: str
    publisher: str
    jurisdiction: str | None = None
    identifier: str | None = None
    document_type: str = "regulatory instrument"
    effective_date: str | None = None
    issue_date: str | None = None

class ExtractedDocument(BaseModel):
    identity: DocumentIdentity
    source_url: str
    canonical_url: str
    source_format: Literal["html", "pdf"]
    retrieved_at: str
    raw_text: str
    raw_sha256: str
    page_count: int | None = None
    extraction_warnings: list[str] = Field(default_factory=list)
    source_title: str | None = None
    authority_confidence: float = Field(0, ge=0, le=1)
    authority_reasons: list[str] = Field(default_factory=list)

class ValidationResult(BaseModel):
    status: Literal["accept", "repair", "reject"]
    score: float = Field(ge=0, le=1)
    issues: list[str] = Field(default_factory=list)
    missing_sections: list[str] = Field(default_factory=list)
    source_fidelity_score: float = Field(ge=0, le=1)
    notes: str = ""
    deterministic_checks: dict[str, float | bool | str] = Field(default_factory=dict)

class CorpusObject(BaseModel):
    path: str
    markdown: str
    identity: DocumentIdentity
    source_url: str
    raw_sha256: str
    markdown_sha256: str
    validation: ValidationResult

class CandidateSelection(BaseModel):
    selected_urls: list[HttpUrl] = Field(default_factory=list)
    rejected_urls: list[HttpUrl] = Field(default_factory=list)
    rationale: dict[str, str] = Field(default_factory=dict)

class Plan(BaseModel):
    seed_urls: list[str]
    strategy: str
    source_priority: list[str] = Field(default_factory=list)
    discovery_terms: list[str] = Field(default_factory=list)
    notes: list[str] = Field(default_factory=list)
    success_criteria: list[str] = Field(default_factory=list)

ActionName = Literal[
    "discover", "fetch", "extract", "validate", "retry", "expand", "reconsider", "finish"
]

class AgentDecision(BaseModel):
    action: ActionName
    target: str | None = None
    reason: str
    expected_evidence: list[str] = Field(default_factory=list)
    strategy_change: str | None = None

class FailureMemory(BaseModel):
    action: str
    target: str | None = None
    error: str
    recovery: str | None = None
    timestamp: str

class AgentMemory(BaseModel):
    successful_strategies: list[str] = Field(default_factory=list)
    failed_strategies: list[str] = Field(default_factory=list)
    failures: list[FailureMemory] = Field(default_factory=list)
    completed_sources: list[str] = Field(default_factory=list)
    rejected_sources: list[str] = Field(default_factory=list)

class CompletionAssessment(BaseModel):
    complete: bool
    confidence: float = Field(ge=0, le=1)
    blockers: list[str] = Field(default_factory=list)
    evidence: list[str] = Field(default_factory=list)
