from reg_rag_agent.graph import _repair_check, execute_action_node

HTML = '<html><body><main><a href="/rules/r1.pdf">Rule 1 PDF</a></main></body></html>'


def _base_state():
    return {
        "run_id": "test",
        "step": 0,
        "seeds": ["https://example.com/start"],
        "frontier": [],
        "candidates": [{"url": "https://example.com/start", "depth": 0, "status": "fetched"}],
        "fetched": [{
            "requested_url": "https://example.com/start",
            "final_url": "https://example.com/start",
            "content_type": "text/html",
            "content": HTML.encode(),
            "status": "fetched",
            "depth": 0,
        }],
        "documents": [],
        "outputs": [],
        "errors": [],
        "review_candidates": [],
        "history": [],
        "memory": {},
        "repair_attempts": {},
        "strategy": "",
    }


def test_repair_check_counts_re_extract():
    state = {"fetched": [{"final_url": "https://example.com/r.pdf", "requested_url": "https://example.com/r.pdf"}],
             "documents": [{"canonical_url": "https://example.com/r.pdf"}], "repair_attempts": {}}
    assert _repair_check(state, "extract", "https://example.com/r.pdf") == {"https://example.com/r.pdf": 1}


def test_repair_check_ignores_first_extract():
    state = {"fetched": [{"final_url": "https://example.com/r.pdf", "requested_url": "https://example.com/r.pdf"}],
             "documents": [], "repair_attempts": {}}
    assert _repair_check(state, "extract", "https://example.com/r.pdf") == {}


def test_repair_check_counts_retry_of_fetched():
    state = {"fetched": [{"final_url": "https://example.com/r.pdf", "requested_url": "https://example.com/r.pdf"}],
             "documents": [], "repair_attempts": {}}
    assert _repair_check(state, "retry", "https://example.com/r.pdf") == {"https://example.com/r.pdf": 1}


def test_repair_check_ignores_fetch_and_discover():
    state = {"fetched": [{"final_url": "https://example.com/r.pdf", "requested_url": "https://example.com/r.pdf"}],
             "documents": [], "repair_attempts": {}}
    assert _repair_check(state, "fetch", "https://example.com/r.pdf") == {}
    assert _repair_check(state, "discover", "https://example.com/r.pdf") == {}


def test_expand_respects_max_discovery_depth(monkeypatch, tmp_path):
    monkeypatch.setenv("SOURCE_ALLOWLIST", "example.com")
    monkeypatch.setenv("OUTPUT_DIR", str(tmp_path))
    monkeypatch.setenv("MAX_DISCOVERY_DEPTH", "2")
    state = _base_state()
    state["decision"] = {"action": "expand", "target": "https://example.com/start", "reason": "expand"}
    out = execute_action_node(state)
    assert any(x["url"] == "https://example.com/rules/r1.pdf" for x in out.get("frontier", []))


def test_expand_blocks_when_depth_exhausted(monkeypatch, tmp_path):
    monkeypatch.setenv("SOURCE_ALLOWLIST", "example.com")
    monkeypatch.setenv("OUTPUT_DIR", str(tmp_path))
    monkeypatch.setenv("MAX_DISCOVERY_DEPTH", "0")
    state = _base_state()
    state["decision"] = {"action": "expand", "target": "https://example.com/start", "reason": "expand"}
    out = execute_action_node(state)
    assert not any(x["url"] == "https://example.com/rules/r1.pdf" for x in out.get("frontier", []))


def _fake_fetch(url, settings):
    return {"requested_url": url, "final_url": url, "content_type": "text/html",
            "content": HTML.encode(), "status_code": 200, "retrieved_at": "2026-01-01T00:00:00Z"}


def test_discover_respects_max_discovery_depth(monkeypatch, tmp_path):
    monkeypatch.setenv("SOURCE_ALLOWLIST", "example.com")
    monkeypatch.setenv("OUTPUT_DIR", str(tmp_path))
    monkeypatch.setenv("MAX_DISCOVERY_DEPTH", "2")
    monkeypatch.setattr("reg_rag_agent.graph._fetch_one", _fake_fetch)
    state = _base_state()
    state["frontier"] = [{"url": "https://example.com/start", "depth": 0, "reason": "seed"}]
    state["candidates"] = []
    state["decision"] = {"action": "discover", "target": "https://example.com/start", "reason": "discover"}
    out = execute_action_node(state)
    assert any(x["url"] == "https://example.com/rules/r1.pdf" for x in out.get("frontier", []))


def test_discover_blocks_when_depth_exhausted(monkeypatch, tmp_path):
    monkeypatch.setenv("SOURCE_ALLOWLIST", "example.com")
    monkeypatch.setenv("OUTPUT_DIR", str(tmp_path))
    monkeypatch.setenv("MAX_DISCOVERY_DEPTH", "0")
    monkeypatch.setattr("reg_rag_agent.graph._fetch_one", _fake_fetch)
    state = _base_state()
    state["frontier"] = [{"url": "https://example.com/start", "depth": 0, "reason": "seed"}]
    state["candidates"] = []
    state["decision"] = {"action": "discover", "target": "https://example.com/start", "reason": "discover"}
    out = execute_action_node(state)
    assert not any(x["url"] == "https://example.com/rules/r1.pdf" for x in out.get("frontier", []))


def test_retry_repair_budget_exhausted_aborts_and_records(monkeypatch, tmp_path):
    monkeypatch.setenv("SOURCE_ALLOWLIST", "example.com")
    monkeypatch.setenv("OUTPUT_DIR", str(tmp_path))
    monkeypatch.setenv("MAX_REPAIR_ATTEMPTS", "0")
    calls = {"n": 0}

    def counting_fetch(url, settings):
        calls["n"] += 1
        return _fake_fetch(url, settings)

    monkeypatch.setattr("reg_rag_agent.graph._fetch_one", counting_fetch)
    state = _base_state()
    state["decision"] = {"action": "retry", "target": "https://example.com/start", "reason": "retry"}
    out = execute_action_node(state)
    assert calls["n"] == 0
    assert out.get("errors")
    assert out["repair_attempts"]["https://example.com/start"] == 1
    assert any(c.get("url") == "https://example.com/start" and c.get("status") == "rejected"
               for c in out.get("candidates", []))
