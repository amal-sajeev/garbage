from pathlib import Path

from reg_rag_agent.settings import Settings
from reg_rag_agent.storage import LocalStorage
from reg_rag_agent.tools import authority_assessment, canonicalize, deterministic_quality, discover_links, extract_html, extract_pdf, slugify


def test_extract_html_removes_scripts_and_keeps_headings():
    html = '<html><body><script>bad</script><main><h1>Rule 1</h1><p>Text</p></main><footer>noise</footer></body></html>'
    text, warnings = extract_html(html)
    assert 'bad' not in text and '# Rule 1' in text and 'Text' in text and 'noise' not in text


def test_slugify():
    assert slugify('FINRA Rule 3110: Supervision') == 'finra-rule-3110-supervision'


def test_quality_detects_loss():
    q = deterministic_quality('alpha beta gamma delta', 'alpha beta')
    assert q['coverage'] < 0.8 and q['missing_tail']


def test_quality_accepts_lossless_markdown():
    raw = '# Section 1\n\nThis is regulatory text.'
    q = deterministic_quality(raw, raw)
    assert q['coverage'] == 1.0 and q['tail_coverage'] == 1.0 and not q['missing_tail']


def test_canonicalize_removes_fragment_and_trailing_slash():
    assert canonicalize('https://example.com/a/#x') == 'https://example.com/a'


def test_recursive_discovery_candidate_scoring():
    settings = Settings(source_allowlist='example.com')
    html = '''<main>
      <a href="/rules/3110.pdf">Rule 3110 PDF</a>
      <a href="/about">About</a>
    </main>'''
    candidates = discover_links('https://example.com/start', html, settings)
    assert candidates[0]['kind'] == 'pdf'
    assert candidates[0]['relevance'] > candidates[1]['relevance']


def test_authority_gate_requires_allowlist():
    settings = Settings(source_allowlist='finra.org')
    score, reasons = authority_assessment('https://example.com/rule.pdf', {
        'publisher': 'FINRA', 'authority_class': 'instrument'
    }, settings)
    assert score < settings.min_authority_confidence
    assert any('allowlisted' in r for r in reasons)


def test_local_storage_path_safety(tmp_path):
    store = LocalStorage(tmp_path)
    path = store.write('a/b.md', 'hello')
    assert Path(path).read_text() == 'hello'
    try:
        store.write('../escape.md', 'bad')
    except ValueError:
        pass
    else:
        raise AssertionError('path traversal should be rejected')


def test_pdf_page_markers():
    import fitz
    doc = fitz.open()
    for text in ('Page one rule text', 'Page two section text'):
        page = doc.new_page(); page.insert_text((72, 72), text)
    data = doc.tobytes(); doc.close()
    raw, warnings, pages = extract_pdf(data)
    assert pages == 2 and '<!-- source-page: 1 -->' in raw and '<!-- source-page: 2 -->' in raw


def test_allowed_requires_explicit_allowlist():
    assert not __import__("reg_rag_agent.tools", fromlist=["allowed"]).allowed("https://example.com", Settings())

def test_local_storage_rejects_prefix_collision(tmp_path):
    store = LocalStorage(tmp_path / "root")
    try:
        store.write("../root2/escape.txt", "bad")
    except ValueError:
        pass
    else:
        raise AssertionError("prefix-collision traversal should be rejected")
