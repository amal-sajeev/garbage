# Regulatory RAG Agent v3 design

## Architecture

```text
seed URLs + objective
  -> bootstrap
  -> Gemini plan
  -> persistent agent state
  -> agent_decide
  -> execute_action
  -> persistent checkpoint
  -> agent_decide ...
  -> deterministic completion gate
  -> persistence
```

The core design change from v2.1 is the controller. v2.1 had a predetermined sequence of acquisition stages. v3 exposes the acquisition process as a bounded state machine where the model chooses the next permitted action from the evidence currently available.

## State

The controller tracks:

- objective and Gemini acquisition plan
- frontier of concrete URLs still worth investigating
- candidate metadata and status
- fetched sources
- extracted documents
- validation results
- errors and action history
- current strategy
- persistent agent memory
- step budget and completion assessment

Checkpoints are written after every action when `CHECKPOINT_EVERY_STEP=true`. Fetched bytes are encoded into the checkpoint so a run can resume without silently losing an in-flight source.

## Action policy

The model may select only these actions:

| Action | Purpose | Deterministic guard |
|---|---|---|
| `discover` | Retrieve a known frontier/index URL and discover links | target must already be in frontier/candidates |
| `expand` | Reinspect an already fetched HTML page for additional links | target must be fetched HTML |
| `fetch` | Retrieve one concrete candidate | target must already be known |
| `extract` | Extract and classify one fetched source | target must be fetched |
| `validate` | Run fidelity and QA checks | target must be extracted |
| `retry` | Reattempt a known failed concrete target | target must already be known |
| `reconsider` | Record a strategy change and reorder the investigation | no URL invention is permitted |
| `finish` | Stop | completion gate or explicit budget/blocker |

The model does not receive a generic HTTP tool with arbitrary URL input. It chooses among concrete state objects, and execution revalidates every target against the allowlist and state.

## Failure and strategy memory

Failures are persisted with action, target, error, recovery, and timestamp. Strategy changes and successful approaches are retained in `agent_memory.json`. This gives later decisions evidence about what already failed instead of repeatedly trying the same path without context. Memory is bounded to avoid unbounded growth.

## Completion

An LLM cannot unilaterally declare success. The deterministic completion assessor checks accepted documents, pending targets, extracted documents, errors, and the step budget. The controller can finish when at least one validated authoritative document has been accepted, or when no pending target remains and progress is blocked by recorded errors.

## Source integrity

Gemini never generates legal body text. HTML/PDF extraction is deterministic. Markdown rendering is deterministic. Fidelity scoring compares extracted source text against rendered Markdown and checks tail coverage. Gemini QA is an independent review signal. Failed validation can cause another acquisition action, but missing legal text is never filled from model knowledge.

## Network boundary

Discovery and retrieval are limited to explicitly allowlisted regulator domains. Redirects and browser navigation are revalidated. No third-party search SaaS is used. Any future regulator-specific search adapter must call an allowlisted regulator-controlled endpoint directly.

## Persistence

Local filesystem is the default. The GCS backend is available for deployments that need object storage. The same controller state and manifest format can be persisted to either backend.
